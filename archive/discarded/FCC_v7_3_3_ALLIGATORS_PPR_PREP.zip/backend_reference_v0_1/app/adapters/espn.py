from __future__ import annotations
from datetime import datetime, timezone
import json
import httpx
from .base import ProviderAdapter
from ..config import settings
from ..models import LeagueConfig, NormalizedLeague, SourceFreshness
from ..scoring_profiles import ALLIGATORS_SCORING

BASE = 'https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons'

class EspnAdapter(ProviderAdapter):
    def __init__(self, timeout: float = 25.0):
        self.timeout = timeout

    async def fetch(self, cfg: LeagueConfig) -> NormalizedLeague:
        s = settings()
        headers = {'User-Agent':'FCC/7.x'}
        if s.FCC_ESPN_SWID and s.FCC_ESPN_S2:
            headers['Cookie'] = f'SWID={s.FCC_ESPN_SWID}; espn_s2={s.FCC_ESPN_S2}'
        views = ['mSettings','mTeam','mRoster','mStandings','mStatus','mSchedule','mDraftDetail']
        params = [('view', v) for v in views]
        url = f'{BASE}/{s.FCC_SEASON}/segments/0/leagues/{cfg.leagueId}'
        now = datetime.now(timezone.utc)
        async with httpx.AsyncClient(timeout=self.timeout, headers=headers) as client:
            r = await client.get(url, params=params)
            r.raise_for_status()
            core = r.json()
            status = core.get('status') or {}
            week = int(status.get('currentMatchupPeriod') or status.get('latestScoringPeriod') or core.get('scoringPeriodId') or 1)
            box_params = [('view','mBoxscore'),('view','mMatchupScore'),('scoringPeriodId',str(week)),('matchupPeriodId',str(week))]
            # A liga e os elencos devem sincronizar mesmo se o endpoint opcional de boxscore variar.
            try:
                bx = await client.get(url, params=box_params)
                bx.raise_for_status()
                current = bx.json()
            except (httpx.HTTPError, ValueError):
                current = {}
            free_agents = []
            if cfg.id == 'espn2':
                filter_obj = {'players': {
                    'filterStatus': {'value': ['FREEAGENT', 'WAIVERS']},
                    'limit': 500,
                    'sortPercOwned': {'sortPriority': 1, 'sortAsc': False}
                }}
                # Este endpoint ainda requer validacao ao vivo: sua falha nao derruba rosters.
                try:
                    fa = await client.get(url, params=[('view', 'kona_player_info')],
                         headers={'X-Fantasy-Filter': json.dumps(filter_obj)})
                    fa.raise_for_status()
                    free_agents = (fa.json().get('players') or [])
                except (httpx.HTTPError, ValueError, TypeError):
                    free_agents = []
        completed = max(0, week - 1)
        return NormalizedLeague(
            id=cfg.id, platform=cfg.platform, name=cfg.name, team=cfg.team, owner=cfg.owner,
            leagueId=cfg.leagueId, teamId=cfg.teamId, analysisWeek=week, completedWeeks=completed,
            source=SourceFreshness(providerUpdatedAt=now, providerStatus='OK', backendStatus='PENDING'),
            data={'core': core, 'currentWeek': current, **({'scoringProfile':ALLIGATORS_SCORING, 'freeAgents':free_agents} if cfg.id == 'espn2' else {})}
        )
