from __future__ import annotations
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_prefix='', extra='ignore')
    FCC_ENV: str = 'dev'
    FCC_ROLE: str = 'api'  # api or worker
    FCC_GCP_PROJECT: str | None = None
    FCC_FIRESTORE_DATABASE: str = '(default)'
    FCC_CLIENT_KEY: str = ''
    FCC_ENABLE_APP_CUTOVER: bool = False
    FCC_SEASON: int = 2026
    FCC_TIMEZONE: str = 'America/Sao_Paulo'
    FCC_PPR_SHEET_ID: str = '1-d2aBSrL2tsjpSuuIy3LjQPxro_acwKOKF78NTYXjqU'
    FCC_SNF_SHEET_ID: str = '1qOcny2uvcVow1U7r2oFcXyTM8WSxFlZi2SpgQBupT3g'
    FCC_ESPN_SHEET_ID: str = '1dMeAjhVJdB8uxyRrB3Zpel5sc8S1z3bTkt7H05zuK8E'
    FCC_ESPN_SWID: str = ''
    FCC_ESPN_S2: str = ''

@lru_cache
def settings() -> Settings:
    return Settings()
