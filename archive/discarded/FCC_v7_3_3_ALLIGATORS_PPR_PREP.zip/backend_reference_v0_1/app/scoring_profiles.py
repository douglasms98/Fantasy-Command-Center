"""Scoring declarado para Alligators Football, liga ESPN 286115474.

Nao presumir o valor de PA 22 a 27, nem acrescentar regras ESPN nao
informadas. Pontuacoes e projecoes calculadas pela ESPN sao autoritativas.
"""
ALLIGATORS_SCORING = {'label': 'PPR 1.0 • personalizado ESPN', 'ppr': 1, 'passing': {'yardsPerPoint': 25, 'passTd': 4, 'interception': -2}, 'rushing': {'yardsPerPoint': 10, 'rushTd': 6}, 'receiving': {'yardsPerPoint': 10, 'receptions': 1, 'receivingTd': 6}, 'kicking': {'patMade': 1, 'fgMade0to39': 3, 'fgMade40to49': 3, 'fgMade50to59': 5, 'fgMade60Plus': 5}, 'defense': {'sack': 1, 'interception': 2, 'fumbleRecovery': 2, 'safety': 2, 'pointsAllowed': {'0': 10, '1-6': 7, '7-13': 4, '14-17': 1, '18-21': 1, '22-27': None, '28-34': -1, '35-45': -4, '46+': -4}}, 'misc': {'fumbleRecoveredForTd': 6, 'fumbleLost': -2}, 'source': 'Regras informadas pelo usuario em 08/10/2026. Faixa PA 22-27 nao especificada; resultados oficiais da ESPN prevalecem.'}
