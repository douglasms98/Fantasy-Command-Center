from .config import settings
from .models import LeagueConfig

def league_configs() -> list[LeagueConfig]:
    s = settings()
    return [
        LeagueConfig(id='sleeper1', platform='Sleeper', name='Paga PPR', team='RJ Outlaws', owner='RJ Outlaws', leagueId='1398756583143477248', spreadsheetId=s.FCC_PPR_SHEET_ID),
        LeagueConfig(id='sleeper2', platform='Sleeper', name='SUNDAY NIGHT FUMBLE', team='Guarus Outlaws', owner='Guarus Outlaws', leagueId='1397017429250478080', spreadsheetId=s.FCC_SNF_SHEET_ID),
        LeagueConfig(id='espn1', platform='ESPN', name='Cartola VK Serie A', team='RJ Outlaws', owner='Douglas', leagueId='1088464775', teamId='14', spreadsheetId=s.FCC_ESPN_SHEET_ID),
        LeagueConfig(id='espn2', platform='ESPN', name='Alligators Football', team='Team ID 14', owner='Douglas', leagueId='286115474', teamId='14'),
    ]

PENDING_LEAGUES = []
