from app.scoring_profiles import ALLIGATORS_SCORING
from app.league_config import league_configs, PENDING_LEAGUES

def test_alligators_custom_ppr():
    rule = ALLIGATORS_SCORING
    assert rule['ppr'] == 1
    assert rule['receiving']['receptions'] == 1
    assert rule['passing']['passTd'] == 4
    assert rule['kicking']['fgMade40to49'] == 3
    assert rule['kicking']['fgMade50to59'] == 5
    assert rule['defense']['pointsAllowed']['18-21'] == 1
    assert rule['defense']['pointsAllowed']['22-27'] is None
    assert rule['defense']['pointsAllowed']['28-34'] == -1

def test_espn2_active_and_without_sheet():
    league = next(c for c in league_configs() if c.id == 'espn2')
    assert league.leagueId == '286115474'
    assert league.spreadsheetId == ''
    assert league.teamId == '14'
    assert not any(p['id']=='espn2' for p in PENDING_LEAGUES)
