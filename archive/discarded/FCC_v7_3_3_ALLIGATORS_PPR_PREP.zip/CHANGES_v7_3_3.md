# FCC v7.3.3: integração ESPN privada (preparação)

- Regra correta Alligators: PPR 1.0 personalizado, não Standard.
- Ligação preparada para ID da liga 286115474 e Team ID 14 já configurado.
- Ativação apenas com 10 times + elenco do próprio Team ID; erros não ativam dados incompletos.
- Grade/posições, standings, resultados semanais e pontos ESPN quando disponíveis no payload.
- BackendApiRepository busca espn2 sem derrubar as três ligas se ela ainda não existir no Cloud.
- Backend de referência v0.1 passa a suportar espn2 sem planilha, cookies por variáveis seguras;
  espn2 deixa a lista de pendentes, e a busca de agentes livres é opcional.
- Permanece a necessidade de atualizar o backend Cloud Run atual e validar respostas reais;
  nenhum acesso autenticado foi usado na geração deste pacote.
- A faixa de pontos cedidos PA 22-27 não foi fornecida: valor nulo no perfil.
