# Mudanças v7.2.2

- Restaurado o tema **Semi-dark** azul original (`#07101f / #0e1930 / #121f3b`).
- Mantido **Full Dark** AMOLED como opção separada.
- Mantido tema **Claro**.
- Restaurado o seletor visual de tema no botão do cabeçalho e no botão mobile.
- Persistência passa a gravar `full-dark`, `semi-dark` ou `light`.
- Compatibilidade: valor antigo `dark` é interpretado como `semi-dark`.
- `theme-color` do Android/WebView acompanha o tema ativo.
- A API/Sync e as demais alterações da v7.2.1 permanecem inalteradas.
