# Fantasy Command Center 2026 — v7.2.2

Baseada na v7.2.1 Live API Ready.

## Correção principal desta revisão

O seletor de aparência com **três temas** foi restaurado:

- **Full Dark** — preto verdadeiro para OLED/AMOLED;
- **Semi-dark** — tema azul original do Fantasy Command Center;
- **Claro** — fundo claro.

O Semi-dark volta a ser reconhecido como tema próprio, e não apenas como um dark genérico. A preferência é persistida no estado da interface e reaplicada ao abrir/retomar o app.

### Compatibilidade
Estados salvos por builds anteriores com `theme: "dark"` são migrados automaticamente para **Semi-dark**, evitando que usuários antigos percam o tema azul.

## Arquivo alterado

- `app/src/main/assets/fcc/index.html`

As correções da v7.2.1 foram mantidas.
