# Fantasy Command Center 2026 — v5.9

Atualização sobre o mesmo projeto Android da v5.8.x. Não desinstale o app.

## v5.9
- Home compacta e orientada a decisão.
- Cards de confronto da rodada.
- Notícias online filtradas pelos jogadores dos rosters.
- Background sync Android a cada ~3 horas (inexact, sujeito ao Android/Doze).
- Notificações locais para início/fim da rodada e ciclo de waivers por liga.
- Central Hoje no Fantasy, mudanças desde o último sync, lineup optimizer.
- Planner de 3 semanas e detecção de byes.
- Pesquisa global, ficha do jogador, Floor/Proj/Ceiling, disponibilidade entre ligas e watchlist.
- Dados de qualidade e status concentrados em Sincronização.
- Mantém cache offline, W1–W18 dinâmica, waivers 2.0, trades e roster horizontal compacto.

## Atualização
1. Copie `arquivos/app/src/main` sobre `app/src/main` no projeto atual.
2. Build > Clean Project (se necessário) > Make Project > Build APK(s).
3. Instale por cima do app existente.
4. Substitua o Sync API pelo arquivo `Fantasy_Command_Center_Sync_API.gs`, salve e publique uma Nova versão da implantação atual mantendo o mesmo /exec e chave.
5. Abra o app e aceite a permissão de notificações.

As notificações usam AlarmManager local. O background sync é inexact e pode ser adiado pelo modo de economia de bateria do Android.
