package com.douglas.fantasycommandcenter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class BackgroundSyncReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        final PendingResult pending=goAsync();
        new Thread(() -> { try { sync(context); } catch(Exception ignored) {} finally { pending.finish(); } },"fcc-bg-sync").start();
    }
    private void sync(Context c) throws Exception {
        String endpoint=c.getSharedPreferences(NotificationScheduler.PREFS,Context.MODE_PRIVATE).getString("endpoint","");
        String token=c.getSharedPreferences(NotificationScheduler.PREFS,Context.MODE_PRIVATE).getString("token","");
        if(!endpoint.startsWith("https://"))return;
        Uri.Builder b=Uri.parse(endpoint).buildUpon().appendQueryParameter("app","android").appendQueryParameter("v","5.9").appendQueryParameter("background","1");
        if(token!=null&&!token.isEmpty())b.appendQueryParameter("key",token);
        HttpURLConnection conn=(HttpURLConnection)new URL(b.build().toString()).openConnection();
        conn.setConnectTimeout(15000);conn.setReadTimeout(45000);conn.setRequestProperty("Accept","application/json");conn.setRequestProperty("User-Agent","FantasyCommandCenter/5.9 Android Background");
        int code=conn.getResponseCode();if(code<200||code>=400){conn.disconnect();return;}String body=readAll(conn.getInputStream());conn.disconnect();
        JSONObject j=new JSONObject(body);if(!j.optBoolean("ok",true))return;File file=new File(c.getFilesDir(),"fcc_sync_cache.json");try(FileOutputStream out=new FileOutputStream(file,false)){out.write(body.getBytes(StandardCharsets.UTF_8));}
        c.getSharedPreferences(NotificationScheduler.PREFS,Context.MODE_PRIVATE).edit().putString("last_sync",java.time.OffsetDateTime.now().toString()).apply();NotificationScheduler.scheduleFromPayload(c,body);
    }
    private String readAll(InputStream in)throws Exception{try(InputStream x=in;ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n,total=0;while((n=x.read(buf))!=-1){total+=n;if(total>20*1024*1024)throw new IOException("payload too large");o.write(buf,0,n);}return o.toString(StandardCharsets.UTF_8.name());}}
}
