package com.douglas.fantasycommandcenter;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        NotificationScheduler.createChannel(context);
        String id=intent.getStringExtra("id"), title=intent.getStringExtra("title"), body=intent.getStringExtra("body");
        Intent open=new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content=PendingIntent.getActivity(context,NotificationScheduler.stableCode("open-"+id),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = android.os.Build.VERSION.SDK_INT>=26 ? new Notification.Builder(context,NotificationScheduler.CHANNEL_ID) : new Notification.Builder(context);
        b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title==null?"Fantasy Command Center":title).setContentText(body==null?"Abra o app para revisar.":body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(content).setWhen(System.currentTimeMillis());
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(NotificationScheduler.stableCode(id),b.build());
    }
}
