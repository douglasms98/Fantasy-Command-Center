package com.douglas.fantasycommandcenter;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

public final class NotificationScheduler {
    static final String PREFS = "fcc_sync";
    static final String PLAN_KEY = "notification_plan";
    static final String CHANNEL_ID = "fcc_fantasy_alerts";
    static final String ACTION_NOTIFY = "com.douglas.fantasycommandcenter.NOTIFY";
    static final String ACTION_BG_SYNC = "com.douglas.fantasycommandcenter.BACKGROUND_SYNC";

    private NotificationScheduler() {}

    public static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Fantasy alerts", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Rodadas, waivers e alertas importantes do Fantasy Command Center");
            nm.createNotificationChannel(ch);
        }
    }

    public static void scheduleFromPayload(Context c, String payload) {
        try {
            JSONObject root = new JSONObject(payload);
            JSONArray events = root.optJSONArray("notificationEvents");
            if (events == null) return;
            cancelStoredPlan(c);
            JSONObject store = new JSONObject();
            store.put("notificationEvents", events);
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(PLAN_KEY, store.toString()).apply();
            scheduleEvents(c, events);
        } catch (Exception ignored) {}
    }

    public static void scheduleStoredPlan(Context c) {
        if (!c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("notifications_enabled", true)) return;
        try {
            String raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PLAN_KEY, "");
            if (raw.isEmpty()) return;
            JSONArray events = new JSONObject(raw).optJSONArray("notificationEvents");
            if (events != null) scheduleEvents(c, events);
        } catch (Exception ignored) {}
    }

    private static void scheduleEvents(Context c, JSONArray events) {
        if (!c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("notifications_enabled", true)) return;
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        long now = System.currentTimeMillis();
        for (int i=0;i<events.length();i++) {
            JSONObject e = events.optJSONObject(i); if (e == null) continue;
            try {
                long at = java.time.OffsetDateTime.parse(e.optString("at")).toInstant().toEpochMilli();
                if (at <= now + 30000) continue;
                String id = e.optString("id", "fcc-"+i);
                Intent intent = new Intent(c, NotificationReceiver.class).setAction(ACTION_NOTIFY)
                        .putExtra("id", id).putExtra("title", e.optString("title","Fantasy Command Center"))
                        .putExtra("body", e.optString("body", "Abra o app para revisar."));
                int req = stableCode(id);
                PendingIntent pi = PendingIntent.getBroadcast(c, req, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                else am.set(AlarmManager.RTC_WAKEUP, at, pi);
            } catch (Exception ignored) {}
        }
    }

    public static void cancelStoredPlan(Context c) {
        try {
            String raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PLAN_KEY, "");
            if (raw.isEmpty()) return;
            JSONArray events = new JSONObject(raw).optJSONArray("notificationEvents");
            if (events == null) return;
            AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            for (int i=0;i<events.length();i++) {
                JSONObject e=events.optJSONObject(i); if(e==null)continue; String id=e.optString("id", "fcc-"+i);
                PendingIntent pi=PendingIntent.getBroadcast(c, stableCode(id), new Intent(c,NotificationReceiver.class).setAction(ACTION_NOTIFY), PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
                if(pi!=null){am.cancel(pi);pi.cancel();}
            }
        } catch(Exception ignored) {}
    }

    public static void scheduleBackgroundSync(Context c) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,BackgroundSyncReceiver.class).setAction(ACTION_BG_SYNC);
        PendingIntent pi=PendingIntent.getBroadcast(c,5909,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        long interval=3L*60L*60L*1000L;
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+30L*60L*1000L,interval,pi);
    }

    static int stableCode(String s){return 10000 + Math.abs((s==null?"":s).hashCode()%50000);}
}
