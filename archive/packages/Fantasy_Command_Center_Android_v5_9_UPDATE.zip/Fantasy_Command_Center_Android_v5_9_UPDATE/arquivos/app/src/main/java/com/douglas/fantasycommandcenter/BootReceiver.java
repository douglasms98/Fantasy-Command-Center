package com.douglas.fantasycommandcenter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c, Intent i){ NotificationScheduler.createChannel(c); NotificationScheduler.scheduleStoredPlan(c); NotificationScheduler.scheduleBackgroundSync(c); } }
