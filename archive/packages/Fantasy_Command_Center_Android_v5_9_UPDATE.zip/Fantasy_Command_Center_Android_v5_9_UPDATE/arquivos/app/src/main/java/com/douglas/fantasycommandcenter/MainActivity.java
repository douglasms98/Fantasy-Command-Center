package com.douglas.fantasycommandcenter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.WebResourceRequest;
import android.os.Bundle;
import android.view.Window;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String PREFS = "fcc_sync";
    private static final String PREF_ENDPOINT = "endpoint";
    private static final String PREF_TOKEN = "token";
    private static final String PREF_LAST_SYNC = "last_sync";
    private static final String PREF_UI_STATE = "ui_state";
    private static final String CACHE_FILE = "fcc_sync_cache.json";
    private static final int MAX_SYNC_BYTES = 15 * 1024 * 1024;

    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(7, 16, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 16, 31));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 16, 31));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);
        webView.setSaveEnabled(true);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; } catch (Exception ignored) {}
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new SyncBridge(), "AndroidSync");

        NotificationScheduler.createChannel(this);
        NotificationScheduler.scheduleBackgroundSync(this);
        NotificationScheduler.scheduleStoredPlan(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5901);
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private class SyncBridge {
        @JavascriptInterface
        public String getEndpoint() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_ENDPOINT, "");
        }

        @JavascriptInterface
        public String getToken() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TOKEN, "");
        }

        @JavascriptInterface
        public String getLastSync() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_LAST_SYNC, "");
        }

        @JavascriptInterface
        public void saveConfig(String endpoint, String token) {
            String cleanEndpoint = endpoint == null ? "" : endpoint.trim();
            String cleanToken = token == null ? "" : token.trim();
            getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit()
                    .putString(PREF_ENDPOINT, cleanEndpoint)
                    .putString(PREF_TOKEN, cleanToken)
                    .apply();
            callback("onConfigSaved", "OK");
        }

        @JavascriptInterface
        public String getUiState() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_UI_STATE, "");
        }

        @JavascriptInterface
        public void saveUiState(String json) {
            getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit()
                    .putString(PREF_UI_STATE, json == null ? "" : json)
                    .apply();
        }

        @JavascriptInterface
        public void setLightTheme(boolean light) {
            runOnUiThread(() -> applySystemTheme(light));
        }

        @JavascriptInterface
        public String getCachedPayload() {
            try {
                File file = new File(getFilesDir(), CACHE_FILE);
                if (!file.exists()) return "";
                return readAll(new FileInputStream(file));
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void clearCache() {
            try {
                File file = new File(getFilesDir(), CACHE_FILE);
                if (file.exists()) file.delete();
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_LAST_SYNC).apply();
                callback("onCacheCleared", "OK");
            } catch (Exception e) {
                callback("onSyncError", "Não foi possível limpar o cache: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public boolean notificationsEnabled() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("notifications_enabled", true);
        }

        @JavascriptInterface
        public void setNotificationsEnabled(boolean enabled) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("notifications_enabled", enabled).apply();
            if (enabled) {
                NotificationScheduler.createChannel(MainActivity.this);
                NotificationScheduler.scheduleStoredPlan(MainActivity.this);
            } else {
                NotificationScheduler.cancelStoredPlan(MainActivity.this);
            }
        }

        @JavascriptInterface
        public void syncNow() {
            final String endpoint = getEndpoint();
            final String token = getToken();
            if (endpoint == null || endpoint.trim().isEmpty()) {
                callback("onSyncError", "Sincronização não configurada. Abra ⚙ Sincronização e informe o URL do Web App.");
                return;
            }
            if (!endpoint.startsWith("https://")) {
                callback("onSyncError", "Use um endpoint HTTPS do Google Apps Script.");
                return;
            }

            callback("onSyncStarted", "Atualizando planilhas...");
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    Uri.Builder builder = Uri.parse(endpoint).buildUpon()
                            .appendQueryParameter("app", "android")
                            .appendQueryParameter("v", "5.9");
                    if (token != null && !token.isEmpty()) {
                        builder.appendQueryParameter("key", token);
                    }
                    URL url = new URL(builder.build().toString());
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setInstanceFollowRedirects(true);
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(45000);
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("User-Agent", "FantasyCommandCenter/5.9 Android");

                    int code = conn.getResponseCode();
                    InputStream stream = (code >= 200 && code < 400) ? conn.getInputStream() : conn.getErrorStream();
                    String body = readAll(stream);
                    if (code < 200 || code >= 400) {
                        throw new Exception("HTTP " + code + (body.isEmpty() ? "" : ": " + body.substring(0, Math.min(180, body.length()))));
                    }
                    if (body.length() < 20) throw new Exception("Resposta vazia do servidor.");
                    String trimmed = body.trim().toLowerCase();
                    if (trimmed.startsWith("<!doctype") || trimmed.startsWith("<html")) {
                        throw new Exception("O Google retornou uma página HTML. Verifique se o Web App está publicado para 'Qualquer pessoa' e use a URL /exec.");
                    }

                    JSONObject parsed = new JSONObject(body);
                    if (!parsed.optBoolean("ok", true)) {
                        throw new Exception(parsed.optString("error", "Servidor recusou a sincronização."));
                    }
                    String schema = parsed.optString("schema", "");
                    if (!(schema.startsWith("fcc-sync-") || schema.startsWith("fcc-data-"))) {
                        throw new Exception("Schema de sincronização incompatível: " + schema);
                    }

                    File file = new File(getFilesDir(), CACHE_FILE);
                    try (FileOutputStream out = new FileOutputStream(file, false)) {
                        out.write(body.getBytes(StandardCharsets.UTF_8));
                    }
                    String when = java.time.OffsetDateTime.now().toString();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_LAST_SYNC, when).apply();
                    NotificationScheduler.scheduleFromPayload(MainActivity.this, body);
                    callbackBase64("onSyncSuccessFromBase64", body);
                } catch (Exception e) {
                    callback("onSyncError", "Falha ao atualizar: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }, "fcc-sync").start();
        }
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int n;
            while ((n = in.read(buffer)) != -1) {
                total += n;
                if (total > MAX_SYNC_BYTES) throw new Exception("Resposta acima de 15 MB.");
                out.write(buffer, 0, n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void callback(String method, String message) {
        String encoded = Base64.encodeToString((message == null ? "" : message).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "window.FCCNative && window.FCCNative." + method + " && window.FCCNative." + method + "(atob('" + encoded + "'))";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void callbackBase64(String method, String payload) {
        String encoded = Base64.encodeToString(payload.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "window.FCCNative && window.FCCNative." + method + " && window.FCCNative." + method + "('" + encoded + "')";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void persistWebUiState() {
        if (webView == null) return;
        webView.evaluateJavascript("window.FCCApp&&window.FCCApp.persistNow&&window.FCCApp.persistNow()", null);
    }

    private void applySystemTheme(boolean light) {
        Window window = getWindow();
        int flags = 0;
        if (light) {
            window.setStatusBarColor(Color.rgb(242, 245, 250));
            window.setNavigationBarColor(Color.rgb(242, 245, 250));
            if (android.os.Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        } else {
            window.setStatusBarColor(Color.rgb(7, 16, 31));
            window.setNavigationBarColor(Color.rgb(7, 16, 31));
        }
        window.getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    protected void onPause() {
        persistWebUiState();
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        persistWebUiState();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript("window.FCCApp&&window.FCCApp.restoreAfterResume&&window.FCCApp.restoreAfterResume()", null);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        persistWebUiState();
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.removeJavascriptInterface("AndroidSync");
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
