# Fantasy Command Center 2026 — v7.2.4 Complete Fix

## Correções principais

- Corrigida a causa real do Semi-dark preto: o CSS legado da Preview AMOLED usava `body:not(.light)` e sobrescrevia o Semi-dark. Agora o preto verdadeiro é exclusivo de `.full-dark`.
- Semi-dark restaurado com hierarquia navy: `#09111E` / `#0E1930` / `#121F3B`.
- Migração de tema v7.2.4 força Semi-dark uma única vez após a atualização, evitando herdar Full Dark salvo por versões antigas.
- `MainActivity` usa o mesmo navy no fundo da WebView, status bar e navigation bar.
- Ícone oficial FCC recuperado do app antigo e usado no cabeçalho e nos novos launchers.
- Launcher passou a usar nomes de recurso exclusivos (`fcc_launcher_v724`), evitando qualquer fallback para o antigo robô Android.
- Novo ícone monocromático de notificação (`ic_stat_fcc_v724`) em densidades Android adequadas.
- `AndroidManifest.xml` completo incluído e validado; corrige o erro `processDebugMainManifest` causado pelo Manifest malformado anterior.
- Tema Android nativo `Theme.FCC.V724` adicionado com `windowBackground` navy.
- Script completo cria backup, substitui os arquivos necessários, remove scheduler Kotlin antigo se existir, elimina duplicidade PNG/WEBP e limpa `app/build`.
- `versionName` atualizado para `7.2.4` e `versionCode` incrementado automaticamente quando possível.

## Não alterado

A lógica principal de Cloud Run, Sync API, rosters, waivers, trades, notícias e agenda de notificações foi preservada da v7.2.3.
