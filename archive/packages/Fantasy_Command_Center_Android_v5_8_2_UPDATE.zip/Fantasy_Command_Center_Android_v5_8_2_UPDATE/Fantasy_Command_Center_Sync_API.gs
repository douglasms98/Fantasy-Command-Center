/**
 * Fantasy Command Center 2026 — Sync API v1.1 (app v5.8)
 *
 * Deploy this file as a Google Apps Script Web App.
 * It reads the three Google Sheets used by the dashboard and returns only
 * the fields needed by the Android app. No Google credentials are stored in
 * the APK. The Web App executes as the Google account that owns/deploys it.
 *
 * One-time setup:
 *   1) Run setupFantasySyncKey() from Apps Script.
 *   2) Copy the returned/logged key.
 *   3) Deploy > New deployment > Web app > Execute as: Me > Who has access: Anyone.
 *   4) In the Android app, paste the /exec URL and the key.
 */

const FCC_CONFIG = [
  {
    id: 'sleeper1',
    platform: 'Sleeper',
    name: 'Paga PPR',
    team: 'RJ Outlaws',
    owner: 'RJ Outlaws',
    spreadsheetId: '1-d2aBSrL2tsjpSuuIy3LjQPxro_acwKOKF78NTYXjqU',
    type: 'sleeper'
  },
  {
    id: 'sleeper2',
    platform: 'Sleeper',
    name: 'SUNDAY NIGHT FUMBLE',
    team: 'Guarus Outlaws',
    owner: 'Guarus Outlaws',
    spreadsheetId: '1qOcny2uvcVow1U7r2oFcXyTM8WSxFlZi2SpgQBupT3g',
    type: 'sleeper'
  },
  {
    id: 'espn1',
    platform: 'ESPN',
    name: 'Cartola VK Serie A',
    team: 'RJ Outlaws',
    owner: 'Douglas',
    spreadsheetId: '1dMeAjhVJdB8uxyRrB3Zpel5sc8S1z3bTkt7H05zuK8E',
    type: 'espn'
  }
];

function setupFantasySyncKey() {
  const key = (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '');
  PropertiesService.getScriptProperties().setProperty('FCC_SYNC_KEY', key);
  console.log('FCC_SYNC_KEY=' + key);
  return key;
}

function doGet(e) {
  try {
    const expected = PropertiesService.getScriptProperties().getProperty('FCC_SYNC_KEY') || '';
    const supplied = (e && e.parameter && e.parameter.key) ? String(e.parameter.key) : '';
    if (!expected) return json_({ok:false, schema:'fcc-sync-v1.1.1', error:'SYNC_KEY_NOT_CONFIGURED'});
    if (supplied !== expected) return json_({ok:false, schema:'fcc-sync-v1.1.1', error:'UNAUTHORIZED'});

    // A rodada analisada deve representar a rodada NFL que está EM ANDAMENTO,
    // e não "maior semana encontrada nas planilhas + 1". As planilhas podem
    // conter linhas parciais da rodada atual antes de ela terminar.
    const nflState = sleeperState_() || {};
    const stateWeek = num_(nflState.week || nflState.display_week || 0);
    const canonicalAnalysisWeek = stateWeek ? clampWeek_(stateWeek) : 0;
    const stateSeasonType = String(nflState.season_type || '').toLowerCase();

    const payload = {
      ok: true,
      schema: 'fcc-sync-v1.1.1',
      apiVersion: '1.1.1',
      generatedAt: new Date().toISOString(),
      analysisWeek: canonicalAnalysisWeek || 1,
      completedWeeks: 0,
      seasonEnded: false,
      leagues: {}
    };

    FCC_CONFIG.forEach(cfg => {
      try {
        const league = cfg.type === 'sleeper'
          ? readSleeper_(cfg, canonicalAnalysisWeek, stateSeasonType)
          : readEspn_(cfg, canonicalAnalysisWeek, stateSeasonType);
        payload.leagues[cfg.id] = league;
        // Se o estado NFL estiver disponível, ele é a referência comum para
        // todas as ligas. Só usamos a semana da fonte como fallback.
        if (!canonicalAnalysisWeek) {
          payload.analysisWeek = Math.max(payload.analysisWeek, Number(league.analysisWeek) || 1);
        }
        payload.completedWeeks = Math.max(payload.completedWeeks, Number(league.completedWeeks) || 0);
        payload.seasonEnded = payload.seasonEnded || Boolean(league.seasonEnded);
      } catch (err) {
        payload.leagues[cfg.id] = {
          id: cfg.id, platform: cfg.platform, name: cfg.name, team: cfg.team, owner: cfg.owner,
          ok: false, error: String(err && err.message ? err.message : err)
        };
      }
    });
    payload.completedWeeks = Math.min(18, payload.completedWeeks);
    payload.seasonEnded = payload.seasonEnded || stateSeasonType === 'post';
    payload.analysisWeek = payload.seasonEnded ? 18 : clampWeek_(payload.analysisWeek);
    // Durante uma rodada em andamento, histórico concluído nunca pode incluir
    // a própria rodada analisada.
    if (!payload.seasonEnded) {
      payload.completedWeeks = Math.min(payload.completedWeeks, Math.max(0, payload.analysisWeek - 1));
    }
    return json_(payload);
  } catch (err) {
    return json_({ok:false, schema:'fcc-sync-v1.1.1', error:String(err && err.message ? err.message : err)});
  }
}

function readSleeper_(cfg, canonicalAnalysisWeek, stateSeasonType) {
  const ss = SpreadsheetApp.openById(cfg.spreadsheetId);
  const weeklySheet = ss.getSheetByName('Weekly Results');
  const sourceMaxWeek = maxWeek_(weeklySheet);
  const infoSheet = ss.getSheetByName('Info');
  const configuredWeek = infoSheet ? num_(infoSheet.getRange('B3').getDisplayValue()) : 0;
  const nflState = canonicalAnalysisWeek ? null : sleeperState_();
  const apiWeek = canonicalAnalysisWeek || num_((nflState || {}).week || (nflState || {}).display_week || 0);
  const seasonType = stateSeasonType || String((nflState || {}).season_type || '').toLowerCase();
  const seasonEnded = seasonType === 'post';
  // Prioridade: estado atual da NFL/Sleeper. Info!B3 é somente fallback.
  const analysisWeek = seasonEnded ? 18 : clampWeek_(apiWeek || configuredWeek || (sourceMaxWeek ? sourceMaxWeek : 1));
  // Weekly Results pode conter W4 enquanto W4 ainda está acontecendo. Nesse
  // cenário, somente W1-W3 são histórico concluído.
  const completedWeeks = seasonEnded
    ? Math.min(18, sourceMaxWeek)
    : Math.min(sourceMaxWeek, Math.max(0, analysisWeek - 1));
  const weekSheetInfo = findWeekDataSheet_(ss, analysisWeek);

  const rosters = records_(ss.getSheetByName('Rosters'), [
    'Roster ID','Owner','Team Name','Roster Slot','Starter Slot','Player ID','Player','Position','Fantasy Positions','NFL Team','Age'
  ]);
  const summary = records_(ss.getSheetByName('Roster Summary'), [
    'Roster ID','Owner','Team Name','Total Players','Active Players','Starters','Bench','Reserve','Taxi','Open Active Spots','Open Reserve Spots','Open Taxi Spots','QB','RB','WR','TE','K','DEF','Other','Average Age','Under 25','FAAB Remaining','Waiver Position','Current Year Picks','Next Year Picks'
  ]);
  const standings = records_(ss.getSheetByName('Standings'), [
    'User','Wins','Losses','Games','Win %','Total Points','High Scores','vs League W','vs League L','vs League %'
  ]);
  const weekly = records_(weeklySheet, [
    'Week','User','Team Score','Rank','Opponent','Opp Score','Opp Rank','Result','Margin','Margin Rank'
  ], r => num_(r.Week) <= completedWeeks);

  const playerFields = [
    'Owner','League','Year','Week','Player_ID','Player','Position','NFL','Fantasy','Points','Projected','Opponent','Age',
    'Rushing Attempts','Rushing Yards','Rushing TD','Targets','Reception','Receiving Yards','Receiving TD','Sacks','Interceptions','Defense TD'
  ];
  const playerResults = records_(ss.getSheetByName('Player Results'), playerFields,
    r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= completedWeeks);
  const weekData = weekSheetInfo.sheet ? records_(weekSheetInfo.sheet, playerFields) : [];

  const faFields = [
    'Week','Player_ID','Player','Position','NFL Team','Fantasy Points','Projected','Rushing Attempts','Rushing Yards','Rushing TD','Targets','Reception','Receiving Yards','Receiving TD','Sacks','Interceptions','Defense TD'
  ];
  const freeAgents = records_(ss.getSheetByName('Free Agents'), faFields,
    r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);
  const transactions = records_(ss.getSheetByName('Transactions'), [
    'Week','Transaction ID','Type','Date','User','Action','Player','Position','Waiver Bid'
  ], r => num_(r.Week) === analysisWeek);

  const playerMeta = sleeperPlayers_();
  enrichSleeperRows_(rosters, 'Player ID', playerMeta);
  enrichSleeperRows_(playerResults, 'Player_ID', playerMeta);
  enrichSleeperRows_(weekData, 'Player_ID', playerMeta);
  enrichSleeperRows_(freeAgents, 'Player_ID', playerMeta);
  const qbContext = buildSleeperQbContext_(playerMeta);

  return {
    ok: true, id: cfg.id, platform: cfg.platform, name: cfg.name, team: cfg.team, owner: cfg.owner,
    sourceTitle: ss.getName(), sourceUpdatedAt: latestDiagnosticsTimestamp_(ss),
    analysisWeek, completedWeeks, seasonEnded,
    data: {rosters, summary, standings, weekly, playerResults, weekData, freeAgents, transactions},
    qbContext
  };
}

function readEspn_(cfg, canonicalAnalysisWeek, stateSeasonType) {
  const ss = SpreadsheetApp.openById(cfg.spreadsheetId);
  const sourceMaxWeek = maxWeek_(ss.getSheetByName('Data_Weekly_Results'));
  let sourceAnalysisWeek = readInfoNumber_(ss.getSheetByName('Data_Info'), 'Analysis Week');
  if (!sourceAnalysisWeek) {
    const faProbe = records_(ss.getSheetByName('Data_Free_Agents'), ['Week']);
    sourceAnalysisWeek = faProbe.reduce((m, r) => Math.max(m, num_(r.Week)), 0) || sourceMaxWeek || 1;
  }
  const seasonEnded = stateSeasonType === 'post';
  // Todas as ligas são da mesma temporada NFL. Quando disponível, o estado
  // Sleeper/NFL é usado como referência para impedir avanço prematuro da ESPN.
  let analysisWeek = seasonEnded ? 18 : clampWeek_(canonicalAnalysisWeek || sourceAnalysisWeek || 1);
  const completedWeeks = seasonEnded
    ? Math.min(18, sourceMaxWeek)
    : Math.min(sourceMaxWeek, Math.max(0, analysisWeek - 1));
  const projHeaders = projectionHeaders_('Proj W');
  const starterProjHeaders = projectionHeaders_('Projected Starter W');

  const rosters = records_(ss.getSheetByName('Data_Rosters'), [
    'Roster ID','Owner','Team Name','Roster Status','Starter Slot','Player ID','Player','Position','NFL Team','Injury Status','Acquisition','Season FP','PPG'
  ].concat(projHeaders));
  rosters.forEach(r => { const v = firstNumericField_(r, ['Projection','Projected','Proj W' + analysisWeek]); if (v !== null) r.Projection = v; });

  const summary = records_(ss.getSheetByName('Data_Roster_Summary'), [
    'Roster ID','Owner','Team Name','Total Players','Starters','Bench','Reserve','QB','RB','WR','TE','K','DEF','Season FP (Roster)'
  ].concat(starterProjHeaders));
  summary.forEach(r => { const v = firstNumericField_(r, ['Projected Starter W' + analysisWeek]); if (v !== null) r['Projected Starter W' + analysisWeek] = v; });

  const standings = records_(ss.getSheetByName('Data_Standings'), [
    'User','Wins','Losses','Games','Win %','Total Points','Points Against','High Scores','vs League W','vs League L','vs League %','Team ID','Team Name'
  ]);
  const weekly = records_(ss.getSheetByName('Data_Weekly_Results'), [
    'Week','User','Team Score','Rank','Opponent','Opp Score','Opp Rank','Result','Margin','Margin Rank','Team ID'
  ], r => num_(r.Week) <= completedWeeks);
  const playerResults = records_(ss.getSheetByName('Data_Player_Results'), [
    'Owner','Team Name','Year','Week','Player ID','Player','Position','NFL','Roster Status','Points','Projected','Injury'
  ], r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= completedWeeks);
  const freeAgents = records_(ss.getSheetByName('Data_Free_Agents'), [
    'Week','Player_ID','Player','Position','NFL Team','Fantasy Points','Projected','Rushing Attempts','Rushing Yards','Rushing TD','Targets','Reception','Receiving Yards','Receiving TD','Availability','Injury Status','Percent Owned','Percent Started'
  ], r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);

  return {
    ok: true, id: cfg.id, platform: cfg.platform, name: cfg.name, team: cfg.team, owner: cfg.owner,
    sourceTitle: ss.getName(), sourceUpdatedAt: latestEspnTimestamp_(ss),
    analysisWeek, completedWeeks, seasonEnded,
    data: {rosters, summary, standings, weekly, playerResults, weekData: [], freeAgents, transactions: []}
  };
}


let FCC_SLEEPER_PLAYERS_CACHE = null;
function sleeperPlayers_() {
  if (FCC_SLEEPER_PLAYERS_CACHE) return FCC_SLEEPER_PLAYERS_CACHE;
  try {
    const response = UrlFetchApp.fetch('https://api.sleeper.app/v1/players/nfl', {
      method: 'get', muteHttpExceptions: true, followRedirects: true
    });
    if (response.getResponseCode() >= 200 && response.getResponseCode() < 300) {
      FCC_SLEEPER_PLAYERS_CACHE = JSON.parse(response.getContentText()) || {};
    } else {
      FCC_SLEEPER_PLAYERS_CACHE = {};
    }
  } catch (err) {
    FCC_SLEEPER_PLAYERS_CACHE = {};
  }
  return FCC_SLEEPER_PLAYERS_CACHE;
}

function enrichSleeperRows_(rows, idField, meta) {
  rows.forEach(r => {
    const m = meta[String(r[idField] || '')];
    if (!m) return;
    r['Injury Status'] = m.injury_status || '';
    r['Injury Body'] = m.injury_body_part || '';
    r['Injury Notes'] = m.injury_notes || '';
    r['Depth Chart Position'] = m.depth_chart_position || '';
    r['Depth Chart Order'] = m.depth_chart_order || '';
    if (!r['NFL Team'] && m.team) r['NFL Team'] = m.team;
    if (!r.NFL && m.team) r.NFL = m.team;
  });
}

function buildSleeperQbContext_(meta) {
  const byTeam = {};
  Object.keys(meta || {}).forEach(id => {
    const p = meta[id] || {};
    const team = String(p.team || '').trim();
    const pos = String(p.position || p.fantasy_positions && p.fantasy_positions[0] || '').toUpperCase();
    if (!team || pos !== 'QB') return;
    const order = Number(p.depth_chart_order || 99);
    if (!byTeam[team] || order < byTeam[team].order) {
      const injury = String(p.injury_status || '').toUpperCase();
      const unavailable = ['OUT','IR','PUP','SUSPENDED','NA'].some(x => injury.indexOf(x) >= 0);
      byTeam[team] = {
        qb1: p.full_name || [p.first_name,p.last_name].filter(Boolean).join(' ') || id,
        status: unavailable ? 'UNAVAILABLE' : 'AVAILABLE',
        injuryStatus: p.injury_status || '',
        order
      };
    }
  });
  Object.keys(byTeam).forEach(k => delete byTeam[k].order);
  return byTeam;
}

function findWeekDataSheet_(ss, preferredWeek) {
  let bestWeek = 0, bestSheet = null;
  const preferred = clampWeek_(preferredWeek || 1);
  ss.getSheets().forEach(sh => {
    const m = sh.getName().match(/^Week\s+(\d+)\s+Data$/i); if (!m) return;
    const w = Number(m[1]); if (w > preferred || !sheetHasData_(sh)) return;
    if (w > bestWeek) { bestWeek = w; bestSheet = sh; }
  });
  return {week: bestWeek, sheet: bestSheet};
}

function inferNextWeek_(sh) {
  const completed = maxWeek_(sh);
  return completed >= 18 ? 18 : clampWeek_(completed + 1 || 1);
}


let FCC_SLEEPER_STATE_CACHE = null;
function sleeperState_() {
  if (FCC_SLEEPER_STATE_CACHE) return FCC_SLEEPER_STATE_CACHE;
  try {
    const response = UrlFetchApp.fetch('https://api.sleeper.app/v1/state/nfl', {method:'get', muteHttpExceptions:true, followRedirects:true});
    if (response.getResponseCode() >= 200 && response.getResponseCode() < 300) FCC_SLEEPER_STATE_CACHE = JSON.parse(response.getContentText()) || {};
    else FCC_SLEEPER_STATE_CACHE = {};
  } catch (err) { FCC_SLEEPER_STATE_CACHE = {}; }
  return FCC_SLEEPER_STATE_CACHE;
}
function clampWeek_(v) { const n = Math.round(Number(v) || 1); return Math.max(1, Math.min(18, n)); }
function maxWeek_(sh) {
  if (!sh) return 0;
  const rows = records_(sh, ['Week']);
  return Math.min(18, rows.reduce((m,r)=>Math.max(m,num_(r.Week)),0));
}
function sheetHasData_(sh) {
  if (!sh || sh.getLastRow() < 2) return false;
  const rows = Math.min(sh.getLastRow()-1, 5), cols = Math.max(1, Math.min(sh.getLastColumn(), 12));
  const values = sh.getRange(2,1,rows,cols).getDisplayValues();
  return values.some(row => row.some(v => String(v||'').trim() !== ''));
}
function projectionHeaders_(prefix) { const out=[]; for(let i=1;i<=18;i++) out.push(prefix+i); return out; }
function firstNumericField_(row, names) {
  for (let i=0;i<names.length;i++) { const name=names[i]; if (!(name in row)) continue; const raw=row[name]; if (raw === '' || raw === null || raw === undefined) continue; const n=numMaybe_(raw); if (n !== null && n !== 0) return n; }
  return null;
}
function numMaybe_(v) {
  if (v === null || v === undefined || v === '') return null;
  const s=String(v).replace('%','').replace(',','.').trim(), n=Number(s); return isFinite(n)?n:null;
}
function readInfoValue_(sh, key) {
  if (!sh) return '';
  const values=sh.getDataRange().getDisplayValues(), target=String(key).trim().toLowerCase();
  for(let r=0;r<values.length;r++) if(String(values[r][0]||'').trim().toLowerCase()===target) return values[r][1]||'';
  return '';
}
function dateIso_(v) { if (!v) return ''; const d=new Date(v); return isNaN(d.getTime())?'':d.toISOString(); }
function latestDiagnosticsTimestamp_(ss) {
  const sh=ss.getSheetByName('Diagnostics'); if (!sh || sh.getLastRow()<2) return '';
  const values=sh.getDataRange().getValues(), headers=values[0].map(x=>String(x||'').trim()), ix=headers.indexOf('Run Timestamp'); if(ix<0)return '';
  let best=null;for(let i=1;i<values.length;i++){const d=new Date(values[i][ix]);if(!isNaN(d.getTime())&&(!best||d>best))best=d;}return best?best.toISOString():'';
}
function latestEspnTimestamp_(ss) {
  const candidates=[];
  const info=readInfoValue_(ss.getSheetByName('Data_Info'),'Updated At'); if(info)candidates.push(info);
  const st=ss.getSheetByName('Data_Status'); if(st&&st.getLastRow()>=2){const values=st.getDataRange().getValues();for(let i=1;i<values.length;i++){const key=String(values[i][0]||'');if(key==='Rosters + Free Agents'&&values[i][2])candidates.push(values[i][2]);if(key==='Last Update'&&values[i][1])candidates.push(values[i][1]);}}
  let best=null;candidates.forEach(v=>{const d=new Date(v);if(!isNaN(d.getTime())&&(!best||d>best))best=d;});return best?best.toISOString():'';
}

function readInfoNumber_(sh, key) {
  if (!sh) return 0;
  const values = sh.getDataRange().getDisplayValues();
  for (let r = 0; r < values.length; r++) {
    if (String(values[r][0] || '').trim().toLowerCase() === String(key).toLowerCase()) {
      return num_(values[r][1]);
    }
  }
  return 0;
}

function records_(sh, wanted, predicate) {
  if (!sh) return [];
  const values = sh.getDataRange().getDisplayValues();
  if (!values.length) return [];
  const header = values[0].map(x => String(x || '').trim());
  const indices = wanted.map(name => ({name, idx: header.indexOf(name)})).filter(x => x.idx >= 0);
  const out = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if (!row.some(v => String(v || '').trim() !== '')) continue;
    const obj = {};
    indices.forEach(x => obj[x.name] = row[x.idx]);
    if (!predicate || predicate(obj)) out.push(obj);
  }
  return out;
}

function num_(v) {
  if (v === null || v === undefined || v === '') return 0;
  const s = String(v).replace('%','').replace(',','.').trim();
  const n = Number(s);
  return isFinite(n) ? n : 0;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
