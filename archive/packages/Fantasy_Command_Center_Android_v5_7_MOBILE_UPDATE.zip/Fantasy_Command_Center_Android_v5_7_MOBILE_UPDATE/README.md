# Fantasy Command Center 2026 — v5.7 Mobile

Pacote de atualização para o projeto Android Studio existente.

**Use a pasta `app/src/main` deste ZIP para substituir a mesma pasta no projeto atual.**
Mantenha o mesmo `applicationId`/package `com.douglas.fantasycommandcenter` e instale o APK por cima da v5.6.

Veja `ATUALIZAR_PARA_V5_7.txt`.
