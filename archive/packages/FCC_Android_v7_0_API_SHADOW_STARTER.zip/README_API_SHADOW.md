# FCC Android v7.0 — API Shadow integration starter

This starter deliberately keeps the current Google Apps Script Sync API as the primary data source.

## Files
- `BackendApiRepository.java`: protected Cloud Run API client using `X-FCC-Key`.
- `MainActivity_v7_0_API_SHADOW.java`: current bridge plus Shadow API methods/callbacks.
- `Fantasy_Command_Center_2026_v7_0_API_SHADOW.html`: current v7 UI plus a Shadow API homologation panel.

## Behavior
1. Existing `AndroidSync.syncNow()` remains unchanged and keeps using `SyncRepository`.
2. `AndroidSync.backendShadowNow()` calls:
   - `/health`
   - `/v1/sources`
   - `/v1/leagues/sleeper1`
   - `/v1/leagues/sleeper2`
   - `/v1/leagues/espn1`
3. The Shadow response is cached separately.
4. The HTML stores Shadow results in:
   - `DATA.backendShadow`
   - `DATA.backend`
   - `DATA.normalizedLeagues`
5. It DOES NOT replace `DATA.leagues`, so the current app remains safe while parity is validated.
6. `FCC_ENABLE_APP_CUTOVER` can remain `false`.

## Android project placement
- `BackendApiRepository.java` -> `app/src/main/java/com/douglas/fantasycommandcenter/`
- Replace the current `MainActivity.java` with the contents of `MainActivity_v7_0_API_SHADOW.java`
  (rename the file itself to `MainActivity.java` in Android Studio).
- Replace `app/src/main/assets/fcc/index.html` with
  `Fantasy_Command_Center_2026_v7_0_API_SHADOW.html`.

## API key
The API key is NOT hardcoded. The homologation panel stores it in the same private app
SharedPreferences used by the existing sync configuration. This is acceptable for the current
personal homologation flow, but it is not a strong long-term authentication model because
secrets stored on a client device are ultimately extractable.

## Next stage
After Shadow parity is accepted, implement the compatibility mapper on the backend and then
change the Android data chain to:

Cloud Run backend -> Apps Script Sync API -> local cache

Only after that should the production cutover flag be enabled.
