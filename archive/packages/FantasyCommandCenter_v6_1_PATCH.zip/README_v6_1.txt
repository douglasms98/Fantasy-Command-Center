Fantasy Command Center 2026 — v6.1

ARQUIVO A SUBSTITUIR:
app/src/main/assets/fcc/index.html

NÃO ALTERAR:
- SyncRepository.java
- NewsRepository.java
- build.gradle.kts
- AndroidManifest.xml
- themes.xml / styles.xml / colors.xml
- Apps Script / Sync API (mantenha a v6.0.6)

NOVIDADES v6.1:
- Home revisada por plataforma (Sleeper / ESPN)
- carrosséis responsivos de ligas, confrontos e planejamento
- Planejamento de 3 semanas filtrado pela liga
- logos dos dois times NFL nos confrontos do planejamento
- BYE em fundo cinza
- logo oficial FCC fornecida pelo usuário no cabeçalho
- temas persistentes: Full Dark (AMOLED), Semi-dark (azul) e Claro
- compatibilidade com preferência antiga: antigo tema dark = Semi-dark

O logo no cabeçalho está embutido no HTML; o PNG de referência também acompanha este patch.
