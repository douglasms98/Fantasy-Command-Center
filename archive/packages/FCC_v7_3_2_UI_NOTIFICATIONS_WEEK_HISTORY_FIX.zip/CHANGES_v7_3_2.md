# Fantasy Command Center 2026 — v7.3.2

## Correções funcionais
- **BYE:** jogador em BYE deixa de usar projeção antiga no otimizador, Central de decisões e alertas. Titular em BYE recebe alerta próprio e uma substituição válida pode ser sugerida.
- **Gráfico semanal:** deixa de depender de W1–W3 fixas. As semanas exibidas acompanham o histórico disponível. Quando o provider já atualizou PF/jogos e o histórico semanal atrasou exatamente uma rodada, o app reconstrói somente essa rodada pela diferença do PF acumulado, marcando-a como `RECONSTR.`.
- **Notificações de waiver/rodada:** suporte a alarme exato, diagnóstico da permissão, formatos de timestamp com e sem fuso, reagendamento após boot, atualização do app, mudança de hora e mudança de fuso. Eventos disparados saem da contagem de agendados.
- **Histórico de decisões:** agora grava novo snapshot quando o conjunto de recomendações/movimentações realmente muda, incluindo lineup, melhor waiver/corte, transação recente e alterações detectadas na sincronização.

## Ajustes gráficos
- **Elencos:** coluna Jogador reduzida no celular, nomes podem ocupar duas linhas e as demais colunas ficam mais acessíveis.
- **Waivers recolhidos:** nomes deixam de ser comprimidos em abreviações extremas; o corte recomendado ganha uma segunda linha legível.
- **Waivers expandidos:** corte recomendado e alternativa recebem tipografia maior e disposição vertical; as informações deixam de ficar escondidas no canto do card.

## Notícias
- Tradução passa a priorizar padrões/frases completas para evitar manchetes híbridas em português + inglês.
- Se a tradução local ainda ficar híbrida, o app prefere a manchete original inteira em vez de exibir uma mistura incompleta.
- **IR permanece `IR`**. O app não traduz IR para “reserva de lesionados”; textos já recebidos com essa forma são normalizados de volta para `IR`.

## Base mantida
- Mantém o fluxo **Cloud First** da v7.3.1 e o fallback/compatibilidade com planilhas.
- Não exige alteração nem novo deploy do Cloud Run nesta revisão.
