# Fantasy Command Center 2026 — v7.2.3 UI + Icons Fix

Esta revisão parte da **v7.2.2 Live API Ready** e corrige a camada visual/Android sem alterar a lógica de dados.

## O que foi corrigido

- Semi-dark restaurado de forma explícita para a paleta azul original (`#07101F / #0E1930 / #121F3B`).
- Full Dark continua preto AMOLED e o tema Claro continua independente.
- Barras nativas do Android e fundo da WebView agora acompanham o tema selecionado; o Semi-dark não fica com moldura nativa preta.
- Ícone oficial FCC esportivo restaurado no cabeçalho e no launcher/adaptive icon.
- Ícone de notificação pequeno convertido para formato Android válido, monocromático/transparente: bola diagonal + `FFC`.
- `versionName` passa a `7.2.3` pelo script de aplicação, com incremento do `versionCode` quando necessário.
- Mantidos Cloud Run/API FCC, fallback Sync, notícias, rosters, waivers, trades e scheduler de notificações.

## Aplicação

Consulte `START_HERE_v7_2_3.txt` ou rode `apply_v7_2_3.ps1` apontando para o projeto Android Studio.
