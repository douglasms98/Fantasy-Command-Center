param(
    [Parameter(Mandatory=$true)]
    [string]$ProjectRoot
)

$ErrorActionPreference = "Stop"
$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = (Resolve-Path $ProjectRoot).Path

function Copy-PatchFile([string]$RelativePath) {
    $src = Join-Path $PatchRoot $RelativePath
    $dst = Join-Path $ProjectRoot $RelativePath
    if (!(Test-Path $src)) { throw "Arquivo do patch não encontrado: $src" }
    $parent = Split-Path -Parent $dst
    if (!(Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    Copy-Item $src $dst -Force
    Write-Host "OK  $RelativePath"
}

$files = @(
    "app\src\main\assets\fcc\index.html",
    "app\src\main\java\com\douglas\fantasycommandcenter\MainActivity.java",
    "app\src\main\res\drawable-nodpi\ic_stat_fcc.png",
    "app\src\main\res\drawable-nodpi\fcc_icon_foreground.png",
    "app\src\main\res\drawable\fcc_launcher_background.xml",
    "app\src\main\res\mipmap-anydpi-v26\ic_launcher.xml",
    "app\src\main\res\mipmap-anydpi-v26\ic_launcher_round.xml",
    "app\src\main\res\mipmap-anydpi-v33\ic_launcher.xml",
    "app\src\main\res\mipmap-anydpi-v33\ic_launcher_round.xml",
    "app\src\main\res\mipmap-mdpi\ic_launcher.png",
    "app\src\main\res\mipmap-mdpi\ic_launcher_round.png",
    "app\src\main\res\mipmap-hdpi\ic_launcher.png",
    "app\src\main\res\mipmap-hdpi\ic_launcher_round.png",
    "app\src\main\res\mipmap-xhdpi\ic_launcher.png",
    "app\src\main\res\mipmap-xhdpi\ic_launcher_round.png",
    "app\src\main\res\mipmap-xxhdpi\ic_launcher.png",
    "app\src\main\res\mipmap-xxhdpi\ic_launcher_round.png",
    "app\src\main\res\mipmap-xxxhdpi\ic_launcher.png",
    "app\src\main\res\mipmap-xxxhdpi\ic_launcher_round.png"
)

foreach ($f in $files) { Copy-PatchFile $f }

# Evita Duplicate resources: PNG e WEBP com o mesmo resource name na mesma pasta.
$resRoot = Join-Path $ProjectRoot "app\src\main\res"
Get-ChildItem $resRoot -Directory -Filter "mipmap-*" | ForEach-Object {
    foreach ($name in @("ic_launcher", "ic_launcher_round")) {
        $png = Join-Path $_.FullName ($name + ".png")
        $webp = Join-Path $_.FullName ($name + ".webp")
        if ((Test-Path $png) -and (Test-Path $webp)) {
            Remove-Item $webp -Force
            Write-Host "REM $webp"
        }
    }
}

function Update-GradleVersion([string]$Path, [bool]$Kts) {
    if (!(Test-Path $Path)) { return $false }
    $txt = Get-Content $Path -Raw
    $already = $txt -match 'versionName\s*(?:=\s*)?["'']7\.2\.3["'']'
    if ($Kts) {
        if ($txt -match 'versionName\s*=\s*"[^"]*"') {
            $txt = [regex]::Replace($txt, 'versionName\s*=\s*"[^"]*"', 'versionName = "7.2.3"', 1)
        } else { Write-Warning "versionName não encontrado em $Path" }
        if (!$already -and $txt -match 'versionCode\s*=\s*(\d+)') {
            $n = [int]$Matches[1] + 1
            $txt = [regex]::Replace($txt, 'versionCode\s*=\s*\d+', "versionCode = $n", 1)
        }
    } else {
        if ($txt -match 'versionName\s+["''][^"'']*["'']') {
            $txt = [regex]::Replace($txt, 'versionName\s+["''][^"'']*["'']', 'versionName "7.2.3"', 1)
        } else { Write-Warning "versionName não encontrado em $Path" }
        if (!$already -and $txt -match 'versionCode\s+(\d+)') {
            $n = [int]$Matches[1] + 1
            $txt = [regex]::Replace($txt, 'versionCode\s+\d+', "versionCode $n", 1)
        }
    }
    Set-Content -Path $Path -Value $txt -Encoding UTF8
    Write-Host "VER $Path -> 7.2.3"
    return $true
}

$done = Update-GradleVersion (Join-Path $ProjectRoot "app\build.gradle.kts") $true
if (!$done) { $done = Update-GradleVersion (Join-Path $ProjectRoot "app\build.gradle") $false }
if (!$done) { Write-Warning "build.gradle(.kts) não encontrado. Aplique app_version_patch.txt manualmente." }

Write-Host ""
Write-Host "FCC v7.2.3 aplicado. Agora: Sync Project -> Clean/Rebuild -> gerar APK e instalar por cima."
