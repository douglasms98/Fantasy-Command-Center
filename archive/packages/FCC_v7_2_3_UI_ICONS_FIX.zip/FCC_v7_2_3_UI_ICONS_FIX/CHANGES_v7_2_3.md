# Fantasy Command Center 2026 — v7.2.3

## Semi-dark

O tema azul foi endurecido como tema próprio e explícito, usando a referência visual antiga:

- `#07101F` — fundo principal;
- `#0E1930` — cards;
- `#121F3B` — cards/áreas elevadas;
- `#243455` — bordas.

A classe `semi-dark` passa a ser aplicada diretamente ao `<body>`. Isso evita o comportamento anterior em que o Semi-dark dependia do estado padrão do CSS. O valor legado `dark` continua migrando para `semi-dark`.

## Integração Android do tema

`MainActivity` não inicia mais as barras nativas em preto. O bridge Android agora recebe o nome do tema e aplica:

- Semi-dark: `#07101F`;
- Full Dark: `#000000`;
- Claro: `#F2F5FA`.

Também atualiza o fundo da WebView para impedir flashes pretos ao abrir o app.

## Ícone do aplicativo

Foi restaurado o ícone FCC esportivo com bola de futebol americano para:

- cabeçalho da interface;
- launcher tradicional por densidade;
- adaptive icon Android 8+;
- adaptive/monochrome icon Android 13+.

## Notificação

`ic_stat_fcc.png` agora é um ícone Android monocromático com fundo transparente, usando a composição solicitada de bola diagonal + `FFC`. `FantasyNotificationReceiver` continua usando `R.drawable.ic_stat_fcc`.

## Versão Android

O script de aplicação define `versionName` como `7.2.3` e incrementa `versionCode` uma única vez quando necessário. Isso corrige a tela do Android que ainda mostrava `Versão: 1.0` quando o Gradle não havia sido atualizado.

## Preservado

Nenhuma alteração foi feita no contrato de API/Cloud Run, fallback de Sync, regras de roster/waivers/trades ou agendamento das notificações.
