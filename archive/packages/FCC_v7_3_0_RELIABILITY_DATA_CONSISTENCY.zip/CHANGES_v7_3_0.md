# FCC v7.3.0 — Reliability & Data Consistency

- aplica `season.userTeam` e `season.teams` do Cloud Run ao recorde/classificação exibidos;
- aceita histórico semanal do Season Engine quando disponível;
- remove candidatos de waiver que já estão em qualquer roster da liga;
- permite troca de K/DEF titular por streamer da mesma posição;
- usa notícias recentes também para atualizar status de jogadores de waiver;
- amplia coleta nativa de notícias e janela de busca;
- exibe alerta de lesão nos waivers;
- corrige gráfico de classificação: aproveitamento usa % e pontos usa PF;
- reorganiza chips do planejamento: confronto em cima, horário centralizado embaixo;
- corrige disponibilidade no modal: roster de outro time tem prioridade sobre registro antigo de waiver;
- reduz textos técnicos/legados na interface;
- prepara nome de perfil dinâmico com fallback para Douglas;
- mantém 0–0 de pré-rodada sem tratá-lo como resultado confirmado.

## Limitação conhecida
As notificações de teste funcionam, mas alertas futuros reais continuam dependendo de `notificationEvents`/eventos produzidos pela fonte. Não foi inventado horário de alerta local para evitar notificações falsas.
