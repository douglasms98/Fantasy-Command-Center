# Fantasy Command Center Android v5.7

Pacote de atualização sobre a v5.6 existente.

Use o arquivo `ATUALIZAR_V5_7.txt`. O package continua `com.douglas.fantasycommandcenter`, portanto a instalação deve ser feita por cima do app atual, sem desinstalar.

A v5.7 adiciona interface mobile-first, ícone FCC, navegação inferior e persistência de tela/filtros/rolagem ao retornar do segundo plano.
