/**
 * Fantasy Command Center 2026 — Sync API v1
 *
 * Deploy this file as a Google Apps Script Web App.
 * It reads the three Google Sheets used by the dashboard and returns only
 * the fields needed by the Android app. No Google credentials are stored in
 * the APK. The Web App executes as the Google account that owns/deploys it.
 *
 * One-time setup:
 *   1) Run setupFantasySyncKey() from Apps Script.
 *   2) Copy the returned/logged key.
 *   3) Deploy > New deployment > Web app > Execute as: Me > Who has access: Anyone.
 *   4) In the Android app, paste the /exec URL and the key.
 */

const FCC_CONFIG = [
  {
    id: 'sleeper1',
    platform: 'Sleeper',
    name: 'Paga PPR',
    team: 'RJ Outlaws',
    owner: 'RJ Outlaws',
    spreadsheetId: '1-d2aBSrL2tsjpSuuIy3LjQPxro_acwKOKF78NTYXjqU',
    type: 'sleeper'
  },
  {
    id: 'sleeper2',
    platform: 'Sleeper',
    name: 'SUNDAY NIGHT FUMBLE',
    team: 'Guarus Outlaws',
    owner: 'Guarus Outlaws',
    spreadsheetId: '1qOcny2uvcVow1U7r2oFcXyTM8WSxFlZi2SpgQBupT3g',
    type: 'sleeper'
  },
  {
    id: 'espn1',
    platform: 'ESPN',
    name: 'Cartola VK Serie A',
    team: 'RJ Outlaws',
    owner: 'Douglas',
    spreadsheetId: '1dMeAjhVJdB8uxyRrB3Zpel5sc8S1z3bTkt7H05zuK8E',
    type: 'espn'
  }
];

function setupFantasySyncKey() {
  const key = (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '');
  PropertiesService.getScriptProperties().setProperty('FCC_SYNC_KEY', key);
  console.log('FCC_SYNC_KEY=' + key);
  return key;
}

function doGet(e) {
  try {
    const expected = PropertiesService.getScriptProperties().getProperty('FCC_SYNC_KEY') || '';
    const supplied = (e && e.parameter && e.parameter.key) ? String(e.parameter.key) : '';
    if (!expected) return json_({ok:false, schema:'fcc-sync-v1', error:'SYNC_KEY_NOT_CONFIGURED'});
    if (supplied !== expected) return json_({ok:false, schema:'fcc-sync-v1', error:'UNAUTHORIZED'});

    const payload = {
      ok: true,
      schema: 'fcc-sync-v1',
      generatedAt: new Date().toISOString(),
      analysisWeek: 0,
      leagues: {}
    };

    FCC_CONFIG.forEach(cfg => {
      try {
        const league = cfg.type === 'sleeper' ? readSleeper_(cfg) : readEspn_(cfg);
        payload.leagues[cfg.id] = league;
        payload.analysisWeek = Math.max(payload.analysisWeek, Number(league.analysisWeek) || 0);
      } catch (err) {
        payload.leagues[cfg.id] = {
          id: cfg.id,
          platform: cfg.platform,
          name: cfg.name,
          team: cfg.team,
          owner: cfg.owner,
          ok: false,
          error: String(err && err.message ? err.message : err)
        };
      }
    });
    return json_(payload);
  } catch (err) {
    return json_({ok:false, schema:'fcc-sync-v1', error:String(err && err.message ? err.message : err)});
  }
}

function readSleeper_(cfg) {
  const ss = SpreadsheetApp.openById(cfg.spreadsheetId);
  const inferredWeek = inferNextWeek_(ss.getSheetByName('Weekly Results'));
  const weekSheetInfo = findWeekDataSheet_(ss, inferredWeek);
  const analysisWeek = weekSheetInfo.week || inferredWeek;

  const rosters = records_(ss.getSheetByName('Rosters'), [
    'Roster ID','Owner','Team Name','Roster Slot','Starter Slot','Player ID','Player','Position','Fantasy Positions','NFL Team','Age'
  ]);
  const summary = records_(ss.getSheetByName('Roster Summary'), [
    'Roster ID','Owner','Team Name','Total Players','Active Players','Starters','Bench','Reserve','Taxi','Open Active Spots','Open Reserve Spots','Open Taxi Spots','QB','RB','WR','TE','K','DEF','Other','Average Age','Under 25','FAAB Remaining','Waiver Position','Current Year Picks','Next Year Picks'
  ]);
  const standings = records_(ss.getSheetByName('Standings'), [
    'User','Wins','Losses','Games','Win %','Total Points','High Scores','vs League W','vs League L','vs League %'
  ]);
  const weekly = records_(ss.getSheetByName('Weekly Results'), [
    'Week','User','Team Score','Rank','Opponent','Opp Score','Opp Rank','Result','Margin','Margin Rank'
  ], r => num_(r.Week) <= analysisWeek);

  const playerFields = [
    'Owner','League','Year','Week','Player_ID','Player','Position','NFL','Fantasy','Points','Projected','Opponent','Age',
    'Rushing Yards','Rushing TD','Reception','Receiving Yards','Receiving TD','Sacks','Interceptions','Defense TD'
  ];
  const playerResults = records_(ss.getSheetByName('Player Results'), playerFields,
    r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);
  const weekData = weekSheetInfo.sheet ? records_(weekSheetInfo.sheet, playerFields) : [];

  const faFields = [
    'Week','Player_ID','Player','Position','NFL Team','Fantasy Points','Projected',
    'Rushing Yards','Rushing TD','Reception','Receiving Yards','Receiving TD','Sacks','Interceptions','Defense TD'
  ];
  const freeAgents = records_(ss.getSheetByName('Free Agents'), faFields,
    r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);
  const transactions = records_(ss.getSheetByName('Transactions'), [
    'Week','Transaction ID','Type','Date','User','Action','Player','Position','Waiver Bid'
  ], r => num_(r.Week) === analysisWeek);

  const playerMeta = sleeperPlayers_();
  enrichSleeperRows_(rosters, 'Player ID', playerMeta);
  enrichSleeperRows_(playerResults, 'Player_ID', playerMeta);
  enrichSleeperRows_(weekData, 'Player_ID', playerMeta);
  enrichSleeperRows_(freeAgents, 'Player_ID', playerMeta);
  const qbContext = buildSleeperQbContext_(playerMeta);

  return {
    ok: true,
    id: cfg.id,
    platform: cfg.platform,
    name: cfg.name,
    team: cfg.team,
    owner: cfg.owner,
    sourceTitle: ss.getName(),
    analysisWeek,
    data: {rosters, summary, standings, weekly, playerResults, weekData, freeAgents, transactions},
    qbContext
  };
}

function readEspn_(cfg) {
  const ss = SpreadsheetApp.openById(cfg.spreadsheetId);
  let analysisWeek = readInfoNumber_(ss.getSheetByName('Data_Info'), 'Analysis Week');
  if (!analysisWeek) {
    const faProbe = records_(ss.getSheetByName('Data_Free_Agents'), ['Week']);
    analysisWeek = faProbe.reduce((m, r) => Math.max(m, num_(r.Week)), 0) || inferNextWeek_(ss.getSheetByName('Data_Weekly_Results'));
  }

  const rosters = records_(ss.getSheetByName('Data_Rosters'), [
    'Roster ID','Owner','Team Name','Roster Status','Starter Slot','Player ID','Player','Position','NFL Team','Injury Status','Acquisition','Season FP','PPG','Proj W4'
  ]);
  const summary = records_(ss.getSheetByName('Data_Roster_Summary'), [
    'Roster ID','Owner','Team Name','Total Players','Starters','Bench','Reserve','QB','RB','WR','TE','K','DEF','Season FP (Roster)','Projected Starter W4'
  ]);
  const standings = records_(ss.getSheetByName('Data_Standings'), [
    'User','Wins','Losses','Games','Win %','Total Points','Points Against','High Scores','vs League W','vs League L','vs League %','Team ID','Team Name'
  ]);
  const weekly = records_(ss.getSheetByName('Data_Weekly_Results'), [
    'Week','User','Team Score','Rank','Opponent','Opp Score','Opp Rank','Result','Margin','Margin Rank','Team ID'
  ], r => num_(r.Week) <= analysisWeek);
  const playerResults = records_(ss.getSheetByName('Data_Player_Results'), [
    'Owner','Team Name','Year','Week','Player ID','Player','Position','NFL','Roster Status','Points','Projected','Injury'
  ], r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);
  const freeAgents = records_(ss.getSheetByName('Data_Free_Agents'), [
    'Week','Player_ID','Player','Position','NFL Team','Fantasy Points','Projected','Rushing Attempts','Rushing Yards','Rushing TD','Targets','Reception','Receiving Yards','Receiving TD','Availability','Injury Status','Percent Owned','Percent Started'
  ], r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);

  return {
    ok: true,
    id: cfg.id,
    platform: cfg.platform,
    name: cfg.name,
    team: cfg.team,
    owner: cfg.owner,
    sourceTitle: ss.getName(),
    analysisWeek,
    data: {rosters, summary, standings, weekly, playerResults, weekData: [], freeAgents, transactions: []}
  };
}


let FCC_SLEEPER_PLAYERS_CACHE = null;
function sleeperPlayers_() {
  if (FCC_SLEEPER_PLAYERS_CACHE) return FCC_SLEEPER_PLAYERS_CACHE;
  try {
    const response = UrlFetchApp.fetch('https://api.sleeper.app/v1/players/nfl', {
      method: 'get', muteHttpExceptions: true, followRedirects: true
    });
    if (response.getResponseCode() >= 200 && response.getResponseCode() < 300) {
      FCC_SLEEPER_PLAYERS_CACHE = JSON.parse(response.getContentText()) || {};
    } else {
      FCC_SLEEPER_PLAYERS_CACHE = {};
    }
  } catch (err) {
    FCC_SLEEPER_PLAYERS_CACHE = {};
  }
  return FCC_SLEEPER_PLAYERS_CACHE;
}

function enrichSleeperRows_(rows, idField, meta) {
  rows.forEach(r => {
    const m = meta[String(r[idField] || '')];
    if (!m) return;
    r['Injury Status'] = m.injury_status || '';
    r['Injury Body'] = m.injury_body_part || '';
    r['Injury Notes'] = m.injury_notes || '';
    r['Depth Chart Position'] = m.depth_chart_position || '';
    r['Depth Chart Order'] = m.depth_chart_order || '';
    if (!r['NFL Team'] && m.team) r['NFL Team'] = m.team;
    if (!r.NFL && m.team) r.NFL = m.team;
  });
}

function buildSleeperQbContext_(meta) {
  const byTeam = {};
  Object.keys(meta || {}).forEach(id => {
    const p = meta[id] || {};
    const team = String(p.team || '').trim();
    const pos = String(p.position || p.fantasy_positions && p.fantasy_positions[0] || '').toUpperCase();
    if (!team || pos !== 'QB') return;
    const order = Number(p.depth_chart_order || 99);
    if (!byTeam[team] || order < byTeam[team].order) {
      const injury = String(p.injury_status || '').toUpperCase();
      const unavailable = ['OUT','IR','PUP','SUSPENDED','NA'].some(x => injury.indexOf(x) >= 0);
      byTeam[team] = {
        qb1: p.full_name || [p.first_name,p.last_name].filter(Boolean).join(' ') || id,
        status: unavailable ? 'UNAVAILABLE' : 'AVAILABLE',
        injuryStatus: p.injury_status || '',
        order
      };
    }
  });
  Object.keys(byTeam).forEach(k => delete byTeam[k].order);
  return byTeam;
}

function findWeekDataSheet_(ss, preferredWeek) {
  let bestWeek = 0;
  let bestSheet = null;
  const preferred = Number(preferredWeek) || 0;
  ss.getSheets().forEach(sh => {
    const m = sh.getName().match(/^Week\s+(\d+)\s+Data$/i);
    if (!m) return;
    const w = Number(m[1]);
    if (w === preferred) {
      bestWeek = w;
      bestSheet = sh;
      return;
    }
    // Ignore future placeholder tabs (for example Week 18 Data) when history only reached Week 3.
    if (w <= preferred && w > bestWeek) {
      bestWeek = w;
      bestSheet = sh;
    }
  });
  return {week: bestWeek, sheet: bestSheet};
}

function inferNextWeek_(sh) {
  if (!sh) return 1;
  const rows = records_(sh, ['Week']);
  return rows.reduce((m, r) => Math.max(m, num_(r.Week)), 0) + 1;
}

function readInfoNumber_(sh, key) {
  if (!sh) return 0;
  const values = sh.getDataRange().getDisplayValues();
  for (let r = 0; r < values.length; r++) {
    if (String(values[r][0] || '').trim().toLowerCase() === String(key).toLowerCase()) {
      return num_(values[r][1]);
    }
  }
  return 0;
}

function records_(sh, wanted, predicate) {
  if (!sh) return [];
  const values = sh.getDataRange().getDisplayValues();
  if (!values.length) return [];
  const header = values[0].map(x => String(x || '').trim());
  const indices = wanted.map(name => ({name, idx: header.indexOf(name)})).filter(x => x.idx >= 0);
  const out = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if (!row.some(v => String(v || '').trim() !== '')) continue;
    const obj = {};
    indices.forEach(x => obj[x.name] = row[x.idx]);
    if (!predicate || predicate(obj)) out.push(obj);
  }
  return out;
}

function num_(v) {
  if (v === null || v === undefined || v === '') return 0;
  const s = String(v).replace('%','').replace(',','.').trim();
  const n = Number(s);
  return isFinite(n) ? n : 0;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
