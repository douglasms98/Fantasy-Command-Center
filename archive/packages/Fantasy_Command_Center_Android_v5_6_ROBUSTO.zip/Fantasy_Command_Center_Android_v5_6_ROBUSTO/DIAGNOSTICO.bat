@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0GERAR_APK.ps1" -DiagnosticoSomente
echo.
echo O relatorio foi salvo como FCC_DIAGNOSTICO.txt
pause
