# Fantasy Command Center Android v5.6.1 — Builder robusto

Execute **`GERAR_APK.bat`**. O script faz preflight de Java/SDK, valida API 36 e Build Tools 36.0.0, usa uma cópia de trabalho em caminho ASCII seguro e só então chama o Gradle.

Se houver qualquer problema, envie `FCC_DIAGNOSTICO.txt` e, quando existir, `FCC_BUILD_LOG.txt`.

Para detalhes, abra `README_PRIMEIRO.txt`.
