FANTASY COMMAND CENTER 2026 - ANDROID v5.6.1 ROBUSTO

OBJETIVO
Este pacote foi preparado para evitar a sequencia de erros de ambiente que pode ocorrer no Windows.
Nao e necessario editar JAVA_HOME, ANDROID_HOME ou local.properties manualmente na maioria dos computadores.

COMO GERAR O APK
1. Extraia todo o ZIP.
2. De dois cliques em GERAR_APK.bat.
3. O builder faz, nesta ordem:
   - detecta JDK 17+ e prioriza o Java/JBR do Android Studio;
   - ignora JAVA_HOME quebrado;
   - procura o Android SDK em variaveis, caminho padrao, adb e sdkmanager;
   - valida API 36 e Build Tools 36.0.0 ANTES de chamar o Gradle;
   - tenta instalar os componentes faltantes se sdkmanager estiver disponivel;
   - cria local.properties automaticamente;
   - copia o projeto para um caminho ASCII seguro fora de OneDrive;
   - baixa/reutiliza Gradle 9.6.0;
   - compila o app;
   - copia o APK pronto de volta para esta pasta.

SAIDA
Fantasy_Command_Center_2026_v5_6.apk

SE ALGO ESTIVER FALTANDO
O script para antes do Gradle e mostra apenas a acao necessaria.
Ele tambem cria:
- FCC_DIAGNOSTICO.txt
- FCC_BUILD_LOG.txt (somente quando o Gradle chegou a ser executado)

Se precisar de suporte, envie esses arquivos em vez de procurar o erro manualmente.

DIAGNOSTICO SEM COMPILAR
Execute DIAGNOSTICO.bat.

INSTALAR DIRETO NO CELULAR POR USB
Depois de gerar o APK:
1. Ative Opcoes do desenvolvedor > Depuracao USB no Android.
2. Conecte o celular e autorize o computador.
3. Execute INSTALAR_NO_CELULAR.bat.
Isso requer Android SDK Platform-Tools / adb.

REQUISITOS VALIDADOS
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- JDK 17 ou superior
- Android SDK Platform 36
- Android SDK Build-Tools 36.0.0

SINCRONIZACAO
A configuracao Google Sheets continua igual a v5.6.
Veja SINCRONIZACAO_GOOGLE_SHEETS.txt.
