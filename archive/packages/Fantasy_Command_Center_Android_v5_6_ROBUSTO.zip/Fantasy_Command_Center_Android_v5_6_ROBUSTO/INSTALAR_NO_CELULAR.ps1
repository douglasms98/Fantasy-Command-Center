﻿$ErrorActionPreference = "Stop"
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
$Apk = Join-Path $Project "Fantasy_Command_Center_2026_v5_6.apk"
if (-not (Test-Path $Apk)) {
    Write-Host "APK nao encontrado. Execute GERAR_APK.bat primeiro." -ForegroundColor Red
    exit 1
}

$candidates = @(
    $env:ANDROID_HOME,
    $env:ANDROID_SDK_ROOT,
    "$env:LOCALAPPDATA\Android\Sdk",
    "$env:USERPROFILE\AppData\Local\Android\Sdk"
)
$adb = $null
foreach ($sdk in $candidates) {
    if (-not $sdk) { continue }
    $p = Join-Path ($sdk.Trim().Trim('"')) "platform-tools\adb.exe"
    if (Test-Path $p) { $adb = $p; break }
}
if (-not $adb) {
    $cmd = Get-Command adb.exe -ErrorAction SilentlyContinue
    if ($cmd) { $adb = $cmd.Source }
}
if (-not $adb) {
    Write-Host "ADB nao encontrado. No SDK Manager instale Android SDK Platform-Tools." -ForegroundColor Red
    exit 2
}

Write-Host "Conecte o celular por USB e ative Depuracao USB." -ForegroundColor Cyan
& $adb start-server | Out-Null
$devices = (& $adb devices) | Select-Object -Skip 1 | Where-Object { $_ -match "\tdevice$" }
if (-not $devices) {
    Write-Host "Nenhum celular autorizado foi detectado." -ForegroundColor Yellow
    Write-Host "Desbloqueie o celular e aceite a janela 'Permitir depuracao USB'." -ForegroundColor Yellow
    exit 3
}

Write-Host "Instalando/atualizando o APK..." -ForegroundColor Cyan
& $adb install -r $Apk
exit $LASTEXITCODE
