@echo off
setlocal
cd /d "%~dp0"

where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo ERRO: Windows PowerShell nao foi encontrado.
  echo Execute pelo Android Studio ou instale o componente Windows PowerShell.
  pause
  exit /b 1
)

echo.
echo ==============================================
echo  Fantasy Command Center - Builder robusto
echo ==============================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0GERAR_APK.ps1"
set "EXITCODE=%ERRORLEVEL%"

echo.
if "%EXITCODE%"=="0" (
  echo Processo concluido com sucesso.
) else (
  echo O builder parou antes de deixar o Gradle falhar de forma confusa.
  echo Codigo: %EXITCODE%
  echo.
  echo Se precisar de ajuda, envie:
  echo   FCC_DIAGNOSTICO.txt
  if exist "%~dp0FCC_BUILD_LOG.txt" echo   FCC_BUILD_LOG.txt
)
echo.
pause
exit /b %EXITCODE%
