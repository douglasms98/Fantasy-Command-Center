﻿param(
    [switch]$DiagnosticoSomente
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$SourceProject = Split-Path -Parent $MyInvocation.MyCommand.Path
$DiagFile = Join-Path $SourceProject "FCC_DIAGNOSTICO.txt"
$BuildLog = Join-Path $SourceProject "FCC_BUILD_LOG.txt"
$GradleVersion = "9.6.0"
$RequiredApi = "36"
$RequiredBuildTools = "36.0.0"

function Say([string]$Message, [ConsoleColor]$Color = [ConsoleColor]::Gray) {
    Write-Host $Message -ForegroundColor $Color
}

function Add-Diag([string]$Key, [object]$Value) {
    $script:Diag += ("{0}: {1}" -f $Key, $Value)
}

function Normalize-PathText([string]$Path) {
    if (-not $Path) { return "" }
    return [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
}

function Test-Ascii([string]$Text) {
    if (-not $Text) { return $true }
    foreach ($c in $Text.ToCharArray()) {
        if ([int][char]$c -gt 127) { return $false }
    }
    return $true
}

function Get-JavaInfo([string]$Home) {
    $Home = Normalize-PathText $Home
    if (-not $Home) { return $null }
    $JavaExe = Join-Path $Home "bin\java.exe"
    if (-not (Test-Path $JavaExe)) { return $null }
    try {
        $raw = (& $JavaExe -version 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0) { return $null }
        $major = 0
        if ($raw -match 'version\s+"(\d+)(?:\.(\d+))?') {
            $major = [int]$matches[1]
            if ($major -eq 1 -and $matches[2]) { $major = [int]$matches[2] }
        } elseif ($raw -match 'openjdk\s+(\d+)') {
            $major = [int]$matches[1]
        }
        if ($major -lt 17) { return $null }
        return [pscustomobject]@{ Home=$Home; Major=$major; Raw=$raw.Trim() }
    } catch {
        return $null
    }
}

function Find-Java {
    $candidates = New-Object System.Collections.Generic.List[string]
    function Add-JavaCandidate([string]$p) {
        if (-not $p) { return }
        $p = Normalize-PathText $p
        if ($p -and -not $candidates.Contains($p)) { $candidates.Add($p) }
    }

    Add-JavaCandidate $env:JAVA_HOME
    Add-JavaCandidate "$env:ProgramFiles\Android\Android Studio\jbr"
    Add-JavaCandidate "$env:ProgramFiles\Android\Android Studio\jre"
    Add-JavaCandidate "${env:ProgramFiles(x86)}\Android\Android Studio\jbr"
    Add-JavaCandidate "$env:LOCALAPPDATA\Programs\Android Studio\jbr"
    Add-JavaCandidate "$env:LOCALAPPDATA\Android\Android Studio\jbr"

    foreach ($regPath in @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )) {
        try {
            Get-ItemProperty $regPath -ErrorAction SilentlyContinue |
                Where-Object { $_.DisplayName -like "Android Studio*" -and $_.InstallLocation } |
                ForEach-Object { Add-JavaCandidate (Join-Path $_.InstallLocation "jbr") }
        } catch {}
    }

    try {
        $cmd = Get-Command java.exe -ErrorAction SilentlyContinue
        if ($cmd) {
            $bin = Split-Path -Parent $cmd.Source
            Add-JavaCandidate (Split-Path -Parent $bin)
        }
    } catch {}

    foreach ($c in $candidates) {
        $info = Get-JavaInfo $c
        if ($info) { return $info }
    }
    return $null
}

function Get-SdkManager([string]$Sdk) {
    if (-not $Sdk) { return $null }
    $patterns = @(
        (Join-Path $Sdk "cmdline-tools\latest\bin\sdkmanager.bat"),
        (Join-Path $Sdk "tools\bin\sdkmanager.bat")
    )
    foreach ($p in $patterns) {
        if (Test-Path $p) { return $p }
    }
    $root = Join-Path $Sdk "cmdline-tools"
    if (Test-Path $root) {
        try {
            $found = Get-ChildItem $root -Directory -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending |
                ForEach-Object { Join-Path $_.FullName "bin\sdkmanager.bat" } |
                Where-Object { Test-Path $_ } |
                Select-Object -First 1
            if ($found) { return $found }
        } catch {}
    }
    return $null
}

function Test-SdkRoot([string]$Path, [switch]$RequirePackages) {
    $Path = Normalize-PathText $Path
    if (-not $Path -or -not (Test-Path $Path)) { return $false }
    if (-not $RequirePackages) {
        return (Test-Path (Join-Path $Path "platforms")) -or
               (Test-Path (Join-Path $Path "build-tools")) -or
               (Test-Path (Join-Path $Path "cmdline-tools"))
    }
    $jar = Join-Path $Path "platforms\android-$RequiredApi\android.jar"
    $aapt2 = Join-Path $Path "build-tools\$RequiredBuildTools\aapt2.exe"
    return (Test-Path $jar) -and (Test-Path $aapt2)
}

function Infer-SdkFromCommand([string]$CommandName) {
    try {
        $cmd = Get-Command $CommandName -ErrorAction SilentlyContinue
        if (-not $cmd) { return $null }
        $src = $cmd.Source
        if ($CommandName -like "adb*") {
            return Split-Path -Parent (Split-Path -Parent $src)
        }
        if ($CommandName -like "sdkmanager*") {
            $bin = Split-Path -Parent $src
            $version = Split-Path -Parent $bin
            $cmdline = Split-Path -Parent $version
            return Split-Path -Parent $cmdline
        }
    } catch {}
    return $null
}

function Find-AndroidSdk {
    $candidates = New-Object System.Collections.Generic.List[string]
    function Add-SdkCandidate([string]$p) {
        if (-not $p) { return }
        $p = Normalize-PathText $p
        if ($p -and -not $candidates.Contains($p)) { $candidates.Add($p) }
    }

    # Existing local.properties is only a hint; invalid values are ignored.
    $lp = Join-Path $SourceProject "local.properties"
    if (Test-Path $lp) {
        try {
            $line = Get-Content $lp | Where-Object { $_ -match '^\s*sdk\.dir\s*=' } | Select-Object -First 1
            if ($line) {
                $value = ($line -replace '^\s*sdk\.dir\s*=\s*','') -replace '\\\\','\'
                Add-SdkCandidate ($value -replace '/','\')
            }
        } catch {}
    }

    Add-SdkCandidate $env:ANDROID_HOME
    Add-SdkCandidate $env:ANDROID_SDK_ROOT
    Add-SdkCandidate "$env:LOCALAPPDATA\Android\Sdk"
    Add-SdkCandidate "$env:USERPROFILE\AppData\Local\Android\Sdk"
    Add-SdkCandidate "$env:ProgramData\Android\Sdk"
    Add-SdkCandidate "$env:PUBLIC\Android\Sdk"
    Add-SdkCandidate "C:\Android\Sdk"
    Add-SdkCandidate "C:\Android\sdk"
    Add-SdkCandidate "D:\Android\Sdk"
    Add-SdkCandidate "D:\Android\sdk"
    Add-SdkCandidate (Infer-SdkFromCommand "adb.exe")
    Add-SdkCandidate (Infer-SdkFromCommand "sdkmanager.bat")

    # First prefer a fully ready API 36 SDK.
    foreach ($c in $candidates) {
        if (Test-SdkRoot $c -RequirePackages) { return [pscustomobject]@{ Path=$c; Ready=$true } }
    }
    # Then accept a recognizable SDK root and install/check packages later.
    foreach ($c in $candidates) {
        if (Test-SdkRoot $c) { return [pscustomobject]@{ Path=$c; Ready=$false } }
    }
    return $null
}

function Ensure-SdkPackages([string]$Sdk) {
    if (Test-SdkRoot $Sdk -RequirePackages) { return $true }

    $manager = Get-SdkManager $Sdk
    if (-not $manager) {
        Say ""
        Say "SDK encontrado, mas API 36 / Build Tools 36.0.0 estao incompletos." Yellow
        Say "Abra Android Studio > Tools > SDK Manager e instale:" Yellow
        Say "  - Android SDK Platform 36" Yellow
        Say "  - Android SDK Build-Tools 36.0.0" Yellow
        return $false
    }

    Say ""
    Say "Componentes do SDK 36 incompletos. Tentando instalar automaticamente..." Cyan
    Say "Se o sdkmanager pedir licenca, aceite no console para continuar." Yellow
    & $manager "--sdk_root=$Sdk" "platforms;android-36" "build-tools;36.0.0" "platform-tools"
    if ($LASTEXITCODE -ne 0) { return $false }
    return (Test-SdkRoot $Sdk -RequirePackages)
}

function Get-WritableSafeRoot {
    $candidates = @(
        (Join-Path $env:PUBLIC "FCCBuild"),
        "C:\FCCBuild"
    )
    foreach ($root in $candidates) {
        if (-not $root) { continue }
        if (-not (Test-Ascii $root)) { continue }
        try {
            New-Item -ItemType Directory -Force -Path $root | Out-Null
            $test = Join-Path $root ".__write_test"
            Set-Content -Path $test -Value "ok" -Encoding ASCII
            Remove-Item $test -Force
            return $root
        } catch {}
    }
    return $null
}

function Copy-ProjectToSafePath([string]$Destination) {
    if (Test-Path $Destination) {
        Remove-Item $Destination -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null

    $args = @(
        $SourceProject,
        $Destination,
        "/MIR",
        "/R:2",
        "/W:1",
        "/NFL",
        "/NDL",
        "/NJH",
        "/NJS",
        "/NP",
        "/XD", ".build-tools", ".gradle", "build",
        "/XF", "local.properties", "*.apk", "FCC_BUILD_LOG.txt", "FCC_DIAGNOSTICO.txt"
    )
    & robocopy @args | Out-Null
    $code = $LASTEXITCODE
    if ($code -gt 7) {
        throw "Falha ao copiar o projeto para o caminho seguro. Codigo robocopy: $code"
    }
}

function Test-Url([string]$Url) {
    try {
        Invoke-WebRequest -UseBasicParsing -Method Head -Uri $Url -TimeoutSec 8 | Out-Null
        return $true
    } catch {
        return $false
    }
}

function Get-Gradle([string]$ToolsRoot) {
    $gradleHome = Join-Path $ToolsRoot "gradle-$GradleVersion"
    $gradleExe = Join-Path $gradleHome "bin\gradle.bat"
    if (Test-Path $gradleExe) { return $gradleExe }

    try {
        $cmd = Get-Command gradle.bat -ErrorAction SilentlyContinue
        if ($cmd) {
            $ver = (& $cmd.Source --version 2>&1 | Out-String)
            if ($ver -match "Gradle\s+$([regex]::Escape($GradleVersion))") {
                return $cmd.Source
            }
        }
    } catch {}

    New-Item -ItemType Directory -Force -Path $ToolsRoot | Out-Null
    $zip = Join-Path $ToolsRoot "gradle-$GradleVersion-bin.zip"
    $url = "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip"

    for ($try = 1; $try -le 3; $try++) {
        try {
            Say "Baixando Gradle $GradleVersion (tentativa $try/3)..." Cyan
            if (Test-Path $zip) { Remove-Item $zip -Force }
            Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip -TimeoutSec 300
            Expand-Archive -Force $zip $ToolsRoot
            Remove-Item $zip -Force
            if (Test-Path $gradleExe) { return $gradleExe }
        } catch {
            if (Test-Path $zip) { Remove-Item $zip -Force -ErrorAction SilentlyContinue }
            if ($try -lt 3) { Start-Sleep -Seconds 2 }
        }
    }
    throw "Nao foi possivel obter o Gradle $GradleVersion. Verifique internet/firewall."
}

function Classify-BuildFailure([string]$Text) {
    if ($Text -match "SDK location not found") {
        return "O Gradle nao encontrou o SDK. O diagnostico mostra o caminho usado."
    }
    if ($Text -match "license|Licenses for package") {
        return "Licenca do Android SDK pendente. Abra Android Studio > SDK Manager e aceite as licencas."
    }
    if ($Text -match "Could not resolve|UnknownHostException|Connection timed out|Read timed out") {
        return "Dependencias nao puderam ser baixadas. Verifique internet, proxy, VPN ou firewall."
    }
    if ($Text -match "non-ASCII characters") {
        return "Caminho com caracteres especiais detectado. O builder deveria usar a copia segura; envie FCC_DIAGNOSTICO.txt."
    }
    if ($Text -match "requires Java|Unsupported class file|JAVA_HOME") {
        return "Incompatibilidade de Java. O builder exige JDK 17 ou superior e prefere o JBR do Android Studio."
    }
    return "Falha de compilacao nao classificada. Envie FCC_DIAGNOSTICO.txt e FCC_BUILD_LOG.txt."
}

# ---------- PRE-FLIGHT ----------
$script:Diag = @()
$now = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Add-Diag "Data" $now
Add-Diag "Projeto_origem" $SourceProject
Add-Diag "Projeto_origem_ASCII" (Test-Ascii $SourceProject)
Add-Diag "Projeto_em_OneDrive" ($SourceProject -match '(?i)OneDrive')
Add-Diag "Windows" ([Environment]::OSVersion.VersionString)
Add-Diag "Usuario" $env:USERNAME
Add-Diag "PowerShell" $PSVersionTable.PSVersion.ToString()

Say ""
Say "Fantasy Command Center - Builder robusto v5.6.1" Cyan
Say "Executando diagnostico antes do build..." Gray

$java = Find-Java
if ($java) {
    $env:JAVA_HOME = $java.Home
    $env:Path = (Join-Path $java.Home "bin") + ";" + $env:Path
    Add-Diag "JAVA_HOME_usado" $java.Home
    Add-Diag "Java_major" $java.Major
    Add-Diag "Java_version" (($java.Raw -split "`r?`n")[0])
    Say "OK Java $($java.Major): $($java.Home)" Green
} else {
    Add-Diag "Java" "NAO ENCONTRADO (JDK 17+)"
    $script:Diag | Set-Content -Path $DiagFile -Encoding UTF8
    Say "ERRO: JDK 17+ nao encontrado. Instale/abra o Android Studio e rode novamente." Red
    Say "Diagnostico: $DiagFile" Yellow
    exit 10
}

$sdkInfo = Find-AndroidSdk
if (-not $sdkInfo -and -not $DiagnosticoSomente) {
    Say ""
    Say "Nao consegui localizar automaticamente o Android SDK." Yellow
    Say "Abra Android Studio > Tools > SDK Manager e copie 'Android SDK Location'." Yellow
    $manual = Read-Host "Cole o Android SDK Location"
    $manual = Normalize-PathText $manual
    if ($manual -and (Test-SdkRoot $manual)) {
        $sdkInfo = [pscustomobject]@{ Path=$manual; Ready=(Test-SdkRoot $manual -RequirePackages) }
    }
}

if ($sdkInfo) {
    $sdk = Normalize-PathText $sdkInfo.Path
    $env:ANDROID_HOME = $sdk
    if ($env:ANDROID_SDK_ROOT) { Remove-Item Env:ANDROID_SDK_ROOT -ErrorAction SilentlyContinue }
    Add-Diag "ANDROID_HOME_usado" $sdk
    Add-Diag "API_36_android_jar" (Test-Path (Join-Path $sdk "platforms\android-36\android.jar"))
    Add-Diag "BuildTools_36_0_0" (Test-Path (Join-Path $sdk "build-tools\36.0.0\aapt2.exe"))
    Add-Diag "sdkmanager" (Get-SdkManager $sdk)
    Say "OK Android SDK: $sdk" Green
} else {
    Add-Diag "Android_SDK" "NAO ENCONTRADO"
    $script:Diag | Set-Content -Path $DiagFile -Encoding UTF8
    Say "ERRO: Android SDK nao encontrado." Red
    Say "Diagnostico: $DiagFile" Yellow
    exit 11
}

$safeRoot = Get-WritableSafeRoot
if ($safeRoot) {
    Add-Diag "Build_root_seguro" $safeRoot
    try {
        $driveName = (Split-Path -Qualifier $safeRoot).TrimEnd('\')
        $drive = [System.IO.DriveInfo]::new($driveName)
        $freeGb = [math]::Round($drive.AvailableFreeSpace / 1GB, 2)
        Add-Diag "Espaco_livre_GB" $freeGb
        if ($freeGb -lt 1.5) {
            Say "AVISO: pouco espaco livre ($freeGb GB)." Yellow
        }
    } catch {}
} else {
    Add-Diag "Build_root_seguro" "NAO DISPONIVEL"
}

Add-Diag "Internet_services_gradle_org" (Test-Url "https://services.gradle.org")
Add-Diag "Internet_google_maven" (Test-Url "https://dl.google.com/dl/android/maven2/")
Add-Diag "Arquivo_app_build_gradle" (Test-Path (Join-Path $SourceProject "app\build.gradle"))
Add-Diag "Arquivo_manifest" (Test-Path (Join-Path $SourceProject "app\src\main\AndroidManifest.xml"))
Add-Diag "Arquivo_dashboard" (Test-Path (Join-Path $SourceProject "app\src\main\assets\index.html"))

$script:Diag | Set-Content -Path $DiagFile -Encoding UTF8
Say "Diagnostico salvo: $DiagFile" DarkGray

if ($DiagnosticoSomente) {
    Say ""
    Say "Diagnostico concluido. Nenhum build foi executado." Green
    exit 0
}

if (-not $safeRoot) {
    Say "ERRO: nao consegui criar um caminho de build seguro em C:\Users\Public\FCCBuild ou C:\FCCBuild." Red
    exit 12
}

if (-not (Ensure-SdkPackages $sdk)) {
    Add-Content -Path $DiagFile -Value "SDK_packages_ready: False" -Encoding UTF8
    Say ""
    Say "ERRO: SDK 36 incompleto. Corrija uma vez no SDK Manager e rode novamente." Red
    Say "O Gradle NAO foi iniciado; assim evitamos um erro confuso no meio do build." Yellow
    exit 13
}
Add-Content -Path $DiagFile -Value "SDK_packages_ready: True" -Encoding UTF8

# ---------- SAFE WORK COPY ----------
$workProject = Join-Path $safeRoot "FantasyCommandCenter_v5_6_1"
Say ""
Say "Preparando copia segura para compilacao:" Cyan
Say "  $workProject" Gray
Copy-ProjectToSafePath $workProject
Add-Content -Path $DiagFile -Value ("Projeto_build: " + $workProject) -Encoding UTF8

$localProps = Join-Path $workProject "local.properties"
$sdkForProps = $sdk -replace '\\','/'
Set-Content -Path $localProps -Value ("sdk.dir=" + $sdkForProps) -Encoding ASCII

# ---------- GRADLE ----------
$toolsRoot = Join-Path $safeRoot "tools"
try {
    $gradleExe = Get-Gradle $toolsRoot
} catch {
    Add-Content -Path $DiagFile -Value ("Gradle_error: " + $_.Exception.Message) -Encoding UTF8
    Say "ERRO: $($_.Exception.Message)" Red
    exit 14
}
Add-Content -Path $DiagFile -Value ("Gradle_exe: " + $gradleExe) -Encoding UTF8

Say ""
Say "Compilando Fantasy Command Center..." Cyan
if (Test-Path $BuildLog) { Remove-Item $BuildLog -Force -ErrorAction SilentlyContinue }

& $gradleExe -p $workProject --no-daemon --console=plain assembleDebug 2>&1 |
    Tee-Object -FilePath $BuildLog
$gradleExit = $LASTEXITCODE

if ($gradleExit -ne 0) {
    $raw = ""
    try { $raw = Get-Content $BuildLog -Raw -ErrorAction SilentlyContinue } catch {}
    $reason = Classify-BuildFailure $raw
    Add-Content -Path $DiagFile -Value ("Build_exit_code: " + $gradleExit) -Encoding UTF8
    Add-Content -Path $DiagFile -Value ("Build_failure_classification: " + $reason) -Encoding UTF8
    Say ""
    Say "BUILD FALHOU: $reason" Red
    Say "Envie estes dois arquivos se precisar de ajuda:" Yellow
    Say "  $DiagFile" Yellow
    Say "  $BuildLog" Yellow
    exit $gradleExit
}

# ---------- OUTPUT ----------
$apk = Join-Path $workProject "app\build\outputs\apk\debug\app-debug.apk"
if (-not (Test-Path $apk)) {
    Add-Content -Path $DiagFile -Value "Build_success_but_apk_missing: True" -Encoding UTF8
    Say "ERRO: build terminou sem localizar app-debug.apk." Red
    exit 15
}

$out = Join-Path $SourceProject "Fantasy_Command_Center_2026_v5_6.apk"
Copy-Item -Force $apk $out
$hash = (Get-FileHash $out -Algorithm SHA256).Hash
Set-Content -Path (Join-Path $SourceProject "APK_SHA256.txt") -Value ("SHA256  " + $hash + "  " + (Split-Path -Leaf $out)) -Encoding ASCII
Add-Content -Path $DiagFile -Value "Build_exit_code: 0" -Encoding UTF8
Add-Content -Path $DiagFile -Value ("APK: " + $out) -Encoding UTF8
Add-Content -Path $DiagFile -Value ("APK_SHA256: " + $hash) -Encoding UTF8

Say ""
Say "==============================================" Green
Say "BUILD SUCCESSFUL" Green
Say "APK GERADO:" Green
Say $out Green
Say "==============================================" Green

try { Start-Process explorer.exe "/select,`"$out`"" } catch {}
exit 0
