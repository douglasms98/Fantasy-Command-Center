/**
 * Fantasy Command Center 2026 — Sync API v1.3.2 (app v6.0.2)
 *
 * Deploy this file as a Google Apps Script Web App.
 * It reads the three Google Sheets used by the dashboard and returns only
 * the fields needed by the Android app. No Google credentials are stored in
 * the APK. The Web App executes as the Google account that owns/deploys it.
 *
 * One-time setup:
 *   1) Run setupFantasySyncKey() from Apps Script.
 *   2) Copy the returned/logged key.
 *   3) Deploy > New deployment > Web app > Execute as: Me > Who has access: Anyone.
 *   4) In the Android app, paste the /exec URL and the key.
 */

const FCC_CONFIG = [
  {
    id: 'sleeper1',
    platform: 'Sleeper',
    name: 'Paga PPR',
    team: 'RJ Outlaws',
    owner: 'RJ Outlaws',
    spreadsheetId: '1-d2aBSrL2tsjpSuuIy3LjQPxro_acwKOKF78NTYXjqU',
    type: 'sleeper'
  },
  {
    id: 'sleeper2',
    platform: 'Sleeper',
    name: 'SUNDAY NIGHT FUMBLE',
    team: 'Guarus Outlaws',
    owner: 'Guarus Outlaws',
    spreadsheetId: '1qOcny2uvcVow1U7r2oFcXyTM8WSxFlZi2SpgQBupT3g',
    type: 'sleeper'
  },
  {
    id: 'espn1',
    platform: 'ESPN',
    name: 'Cartola VK Serie A',
    team: 'RJ Outlaws',
    owner: 'Douglas',
    spreadsheetId: '1dMeAjhVJdB8uxyRrB3Zpel5sc8S1z3bTkt7H05zuK8E',
    type: 'espn'
  }
];

function setupFantasySyncKey() {
  const key = (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '');
  PropertiesService.getScriptProperties().setProperty('FCC_SYNC_KEY', key);
  console.log('FCC_SYNC_KEY=' + key);
  return key;
}

function doGet(e) {
  try {
    const expected = PropertiesService.getScriptProperties().getProperty('FCC_SYNC_KEY') || '';
    const supplied = (e && e.parameter && e.parameter.key) ? String(e.parameter.key) : '';
    if (!expected) return json_({ok:false, schema:'fcc-sync-v1.3.2', error:'SYNC_KEY_NOT_CONFIGURED'});
    if (supplied !== expected) return json_({ok:false, schema:'fcc-sync-v1.3.2', error:'UNAUTHORIZED'});

    // A rodada analisada deve representar a rodada NFL que está EM ANDAMENTO,
    // e não "maior semana encontrada nas planilhas + 1". As planilhas podem
    // conter linhas parciais da rodada atual antes de ela terminar.
    const nflState = sleeperState_() || {};
    const stateWeek = num_(nflState.week || nflState.display_week || 0);
    const canonicalAnalysisWeek = stateWeek ? clampWeek_(stateWeek) : 0;
    const stateSeasonType = String(nflState.season_type || '').toLowerCase();
    const seasonYear = num_(nflState.season || new Date().getFullYear());
    const currentSchedule = nflWeekSchedule_(seasonYear, canonicalAnalysisWeek || stateWeek || 1);

    const payload = {
      ok: true,
      schema: 'fcc-sync-v1.3.2',
      apiVersion: '1.3.2',
      generatedAt: new Date().toISOString(),
      analysisWeek: canonicalAnalysisWeek || 1,
      completedWeeks: 0,
      seasonEnded: false,
      leagues: {}
    };

    FCC_CONFIG.forEach(cfg => {
      try {
        const league = cfg.type === 'sleeper'
          ? readSleeper_(cfg, canonicalAnalysisWeek, stateSeasonType, currentSchedule)
          : readEspn_(cfg, canonicalAnalysisWeek, stateSeasonType, currentSchedule);
        payload.leagues[cfg.id] = league;
        // Se o estado NFL estiver disponível, ele é a referência comum para
        // todas as ligas. Só usamos a semana da fonte como fallback.
        if (!canonicalAnalysisWeek) {
          payload.analysisWeek = Math.max(payload.analysisWeek, Number(league.analysisWeek) || 1);
        }
        payload.completedWeeks = Math.max(payload.completedWeeks, Number(league.completedWeeks) || 0);
        payload.seasonEnded = payload.seasonEnded || Boolean(league.seasonEnded);
      } catch (err) {
        payload.leagues[cfg.id] = {
          id: cfg.id, platform: cfg.platform, name: cfg.name, team: cfg.team, owner: cfg.owner,
          ok: false, error: String(err && err.message ? err.message : err)
        };
      }
    });
    payload.completedWeeks = Math.min(18, payload.completedWeeks);
    payload.seasonEnded = payload.seasonEnded || stateSeasonType === 'post';
    payload.analysisWeek = payload.seasonEnded ? 18 : clampWeek_(payload.analysisWeek);
    // Durante uma rodada em andamento, histórico concluído nunca pode incluir
    // a própria rodada analisada.
    if (!payload.seasonEnded) {
      payload.completedWeeks = Math.min(payload.completedWeeks, Math.max(0, payload.analysisWeek - 1));
    }
    const nflWeeks = [];
    for (let w = payload.analysisWeek; w <= Math.min(18, payload.analysisWeek + 2); w++) nflWeeks.push(nflWeekSchedule_(seasonYear, w));
    payload.online = {news: buildRosterNews_(payload.leagues), newsUpdatedAt: new Date().toISOString(), nflWeeks: nflWeeks};
    payload.notificationEvents = buildNotificationEvents_(payload, nflState, currentSchedule);
    return json_(payload);
  } catch (err) {
    return json_({ok:false, schema:'fcc-sync-v1.3.2', error:String(err && err.message ? err.message : err)});
  }
}

function readSleeper_(cfg, canonicalAnalysisWeek, stateSeasonType, currentSchedule) {
  const ss = SpreadsheetApp.openById(cfg.spreadsheetId);
  const weeklySheet = ss.getSheetByName('Weekly Results');
  const sourceMaxWeek = maxWeek_(weeklySheet);
  const infoSheet = ss.getSheetByName('Info');
  const configuredWeek = infoSheet ? num_(infoSheet.getRange('B3').getDisplayValue()) : 0;
  const nflState = canonicalAnalysisWeek ? null : sleeperState_();
  const apiWeek = canonicalAnalysisWeek || num_((nflState || {}).week || (nflState || {}).display_week || 0);
  const seasonType = stateSeasonType || String((nflState || {}).season_type || '').toLowerCase();
  const seasonEnded = seasonType === 'post';
  // Prioridade: estado atual da NFL/Sleeper. Info!B3 é somente fallback.
  const analysisWeek = seasonEnded ? 18 : clampWeek_(apiWeek || configuredWeek || (sourceMaxWeek ? sourceMaxWeek : 1));
  // Weekly Results pode conter W4 enquanto W4 ainda está acontecendo. Nesse
  // cenário, somente W1-W3 são histórico concluído.
  const completedWeeks = seasonEnded
    ? Math.min(18, sourceMaxWeek)
    : Math.min(sourceMaxWeek, Math.max(0, analysisWeek - 1));
  const weekSheetInfo = findWeekDataSheet_(ss, analysisWeek);

  const rosters = records_(ss.getSheetByName('Rosters'), [
    'Roster ID','Owner','Team Name','Roster Slot','Starter Slot','Player ID','Player','Position','Fantasy Positions','NFL Team','Age'
  ]);
  const summary = records_(ss.getSheetByName('Roster Summary'), [
    'Roster ID','Owner','Team Name','Total Players','Active Players','Starters','Bench','Reserve','Taxi','Open Active Spots','Open Reserve Spots','Open Taxi Spots','QB','RB','WR','TE','K','DEF','Other','Average Age','Under 25','FAAB Remaining','Waiver Position','Current Year Picks','Next Year Picks'
  ]);
  const standings = records_(ss.getSheetByName('Standings'), [
    'User','Wins','Losses','Games','Win %','Total Points','High Scores','vs League W','vs League L','vs League %'
  ]);
  const weekly = records_(weeklySheet, [
    'Week','User','Team Score','Rank','Opponent','Opp Score','Opp Rank','Result','Margin','Margin Rank'
  ], r => num_(r.Week) <= completedWeeks);

  const playerFields = [
    'Owner','League','Year','Week','Player_ID','Player','Position','NFL','Fantasy','Points','Projected','Opponent','Age',
    'Rushing Attempts','Rushing Yards','Rushing TD','Targets','Reception','Receiving Yards','Receiving TD','Sacks','Interceptions','Defense TD'
  ];
  const playerResults = records_(ss.getSheetByName('Player Results'), playerFields,
    r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= completedWeeks);
  const weekData = weekSheetInfo.sheet ? records_(weekSheetInfo.sheet, playerFields) : [];

  const faFields = [
    'Week','Player_ID','Player','Position','NFL Team','Fantasy Points','Projected','Rushing Attempts','Rushing Yards','Rushing TD','Targets','Reception','Receiving Yards','Receiving TD','Sacks','Interceptions','Defense TD'
  ];
  const freeAgents = records_(ss.getSheetByName('Free Agents'), faFields,
    r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);
  const transactions = records_(ss.getSheetByName('Transactions'), [
    'Week','Transaction ID','Type','Date','User','Action','Player','Position','Waiver Bid'
  ], r => num_(r.Week) === analysisWeek);

  const playerMeta = sleeperPlayers_();
  enrichSleeperRows_(rosters, 'Player ID', playerMeta);
  enrichSleeperRows_(playerResults, 'Player_ID', playerMeta);
  enrichSleeperRows_(weekData, 'Player_ID', playerMeta);
  enrichSleeperRows_(freeAgents, 'Player_ID', playerMeta);
  const qbContext = buildSleeperQbContext_(playerMeta);

  return {
    ok: true, id: cfg.id, platform: cfg.platform, name: cfg.name, team: cfg.team, owner: cfg.owner,
    sourceTitle: ss.getName(), sourceUpdatedAt: latestDiagnosticsTimestamp_(ss),
    analysisWeek, completedWeeks, seasonEnded,
    data: {rosters, summary, standings, weekly, playerResults, weekData, freeAgents, transactions},
    matchup: resolveSleeperMatchup_(ss, cfg, analysisWeek, weekData, playerMeta, currentSchedule),
    waiverConfig: sleeperWaiverConfig_(ss),
    qbContext
  };
}

function readEspn_(cfg, canonicalAnalysisWeek, stateSeasonType, currentSchedule) {
  const ss = SpreadsheetApp.openById(cfg.spreadsheetId);
  const sourceMaxWeek = maxWeek_(ss.getSheetByName('Data_Weekly_Results'));
  let sourceAnalysisWeek = readInfoNumber_(ss.getSheetByName('Data_Info'), 'Analysis Week');
  if (!sourceAnalysisWeek) {
    const faProbe = records_(ss.getSheetByName('Data_Free_Agents'), ['Week']);
    sourceAnalysisWeek = faProbe.reduce((m, r) => Math.max(m, num_(r.Week)), 0) || sourceMaxWeek || 1;
  }
  const seasonEnded = stateSeasonType === 'post';
  // Todas as ligas são da mesma temporada NFL. Quando disponível, o estado
  // Sleeper/NFL é usado como referência para impedir avanço prematuro da ESPN.
  let analysisWeek = seasonEnded ? 18 : clampWeek_(canonicalAnalysisWeek || sourceAnalysisWeek || 1);
  const completedWeeks = seasonEnded
    ? Math.min(18, sourceMaxWeek)
    : Math.min(sourceMaxWeek, Math.max(0, analysisWeek - 1));
  const projHeaders = projectionHeaders_('Proj W');
  const starterProjHeaders = projectionHeaders_('Projected Starter W');

  const rosters = records_(ss.getSheetByName('Data_Rosters'), [
    'Roster ID','Owner','Team Name','Roster Status','Starter Slot','Player ID','Player','Position','NFL Team','Injury Status','Acquisition','Season FP','PPG'
  ].concat(projHeaders));
  rosters.forEach(r => { const v = firstNumericField_(r, ['Projection','Projected','Proj W' + analysisWeek]); if (v !== null) r.Projection = v; });

  const summary = records_(ss.getSheetByName('Data_Roster_Summary'), [
    'Roster ID','Owner','Team Name','Total Players','Starters','Bench','Reserve','QB','RB','WR','TE','K','DEF','Season FP (Roster)'
  ].concat(starterProjHeaders));
  summary.forEach(r => { const v = firstNumericField_(r, ['Projected Starter W' + analysisWeek]); if (v !== null) r['Projected Starter W' + analysisWeek] = v; });

  const standings = records_(ss.getSheetByName('Data_Standings'), [
    'User','Wins','Losses','Games','Win %','Total Points','Points Against','High Scores','vs League W','vs League L','vs League %','Team ID','Team Name'
  ]);
  const weekly = records_(ss.getSheetByName('Data_Weekly_Results'), [
    'Week','User','Team Score','Rank','Opponent','Opp Score','Opp Rank','Result','Margin','Margin Rank','Team ID'
  ], r => num_(r.Week) <= completedWeeks);
  const playerResults = records_(ss.getSheetByName('Data_Player_Results'), [
    'Owner','Team Name','Year','Week','Player ID','Player','Position','NFL','Roster Status','Points','Projected','Injury'
  ], r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= completedWeeks);
  const freeAgents = records_(ss.getSheetByName('Data_Free_Agents'), [
    'Week','Player_ID','Player','Position','NFL Team','Fantasy Points','Projected','Rushing Attempts','Rushing Yards','Rushing TD','Targets','Reception','Receiving Yards','Receiving TD','Availability','Injury Status','Percent Owned','Percent Started'
  ], r => num_(r.Week) >= Math.max(1, analysisWeek - 3) && num_(r.Week) <= analysisWeek);

  return {
    ok: true, id: cfg.id, platform: cfg.platform, name: cfg.name, team: cfg.team, owner: cfg.owner,
    sourceTitle: ss.getName(), sourceUpdatedAt: latestEspnTimestamp_(ss),
    analysisWeek, completedWeeks, seasonEnded,
    data: {rosters, summary, standings, weekly, playerResults, weekData: [], freeAgents, transactions: records_(ss.getSheetByName('Data_Transactions'), ['Week','Transaction ID','Type','Date','User','Action','Player','Position','Waiver Bid'], r => num_(r.Week) === analysisWeek)},
    matchup: resolveEspnMatchup_(ss, cfg, analysisWeek, rosters, currentSchedule),
    waiverConfig: espnWaiverConfig_(ss, cfg)
  };
}


let FCC_SLEEPER_PLAYERS_CACHE = null;
function sleeperPlayers_() {
  if (FCC_SLEEPER_PLAYERS_CACHE) return FCC_SLEEPER_PLAYERS_CACHE;
  try {
    const response = UrlFetchApp.fetch('https://api.sleeper.app/v1/players/nfl', {
      method: 'get', muteHttpExceptions: true, followRedirects: true
    });
    if (response.getResponseCode() >= 200 && response.getResponseCode() < 300) {
      FCC_SLEEPER_PLAYERS_CACHE = JSON.parse(response.getContentText()) || {};
    } else {
      FCC_SLEEPER_PLAYERS_CACHE = {};
    }
  } catch (err) {
    FCC_SLEEPER_PLAYERS_CACHE = {};
  }
  return FCC_SLEEPER_PLAYERS_CACHE;
}

function enrichSleeperRows_(rows, idField, meta) {
  rows.forEach(r => {
    const m = meta[String(r[idField] || '')];
    if (!m) return;
    r['Injury Status'] = m.injury_status || '';
    r['Injury Body'] = m.injury_body_part || '';
    r['Injury Notes'] = m.injury_notes || '';
    r['Depth Chart Position'] = m.depth_chart_position || '';
    r['Depth Chart Order'] = m.depth_chart_order || '';
    if (!r['NFL Team'] && m.team) r['NFL Team'] = m.team;
    if (!r.NFL && m.team) r.NFL = m.team;
  });
}

function buildSleeperQbContext_(meta) {
  const byTeam = {};
  Object.keys(meta || {}).forEach(id => {
    const p = meta[id] || {};
    const team = String(p.team || '').trim();
    const pos = String(p.position || p.fantasy_positions && p.fantasy_positions[0] || '').toUpperCase();
    if (!team || pos !== 'QB') return;
    const order = Number(p.depth_chart_order || 99);
    if (!byTeam[team] || order < byTeam[team].order) {
      const injury = String(p.injury_status || '').toUpperCase();
      const unavailable = ['OUT','IR','PUP','SUSPENDED','NA'].some(x => injury.indexOf(x) >= 0);
      byTeam[team] = {
        qb1: p.full_name || [p.first_name,p.last_name].filter(Boolean).join(' ') || id,
        status: unavailable ? 'UNAVAILABLE' : 'AVAILABLE',
        injuryStatus: p.injury_status || '',
        order
      };
    }
  });
  Object.keys(byTeam).forEach(k => delete byTeam[k].order);
  return byTeam;
}

function findWeekDataSheet_(ss, preferredWeek) {
  let bestWeek = 0, bestSheet = null;
  const preferred = clampWeek_(preferredWeek || 1);
  ss.getSheets().forEach(sh => {
    const m = sh.getName().match(/^Week\s+(\d+)\s+Data$/i); if (!m) return;
    const w = Number(m[1]); if (w > preferred || !sheetHasData_(sh)) return;
    if (w > bestWeek) { bestWeek = w; bestSheet = sh; }
  });
  return {week: bestWeek, sheet: bestSheet};
}

function inferNextWeek_(sh) {
  const completed = maxWeek_(sh);
  return completed >= 18 ? 18 : clampWeek_(completed + 1 || 1);
}


let FCC_SLEEPER_STATE_CACHE = null;
function sleeperState_() {
  if (FCC_SLEEPER_STATE_CACHE) return FCC_SLEEPER_STATE_CACHE;
  try {
    const response = UrlFetchApp.fetch('https://api.sleeper.app/v1/state/nfl', {method:'get', muteHttpExceptions:true, followRedirects:true});
    if (response.getResponseCode() >= 200 && response.getResponseCode() < 300) FCC_SLEEPER_STATE_CACHE = JSON.parse(response.getContentText()) || {};
    else FCC_SLEEPER_STATE_CACHE = {};
  } catch (err) { FCC_SLEEPER_STATE_CACHE = {}; }
  return FCC_SLEEPER_STATE_CACHE;
}
function clampWeek_(v) { const n = Math.round(Number(v) || 1); return Math.max(1, Math.min(18, n)); }
function maxWeek_(sh) {
  if (!sh) return 0;
  const rows = records_(sh, ['Week']);
  return Math.min(18, rows.reduce((m,r)=>Math.max(m,num_(r.Week)),0));
}
function sheetHasData_(sh) {
  if (!sh || sh.getLastRow() < 2) return false;
  const rows = Math.min(sh.getLastRow()-1, 5), cols = Math.max(1, Math.min(sh.getLastColumn(), 12));
  const values = sh.getRange(2,1,rows,cols).getDisplayValues();
  return values.some(row => row.some(v => String(v||'').trim() !== ''));
}
function projectionHeaders_(prefix) { const out=[]; for(let i=1;i<=18;i++) out.push(prefix+i); return out; }
function firstNumericField_(row, names) {
  for (let i=0;i<names.length;i++) { const name=names[i]; if (!(name in row)) continue; const raw=row[name]; if (raw === '' || raw === null || raw === undefined) continue; const n=numMaybe_(raw); if (n !== null && n !== 0) return n; }
  return null;
}
function numMaybe_(v) {
  if (v === null || v === undefined || v === '') return null;
  const s=String(v).replace('%','').replace(',','.').trim(), n=Number(s); return isFinite(n)?n:null;
}
function readInfoValue_(sh, key) {
  if (!sh) return '';
  const values=sh.getDataRange().getDisplayValues(), target=String(key).trim().toLowerCase();
  for(let r=0;r<values.length;r++) if(String(values[r][0]||'').trim().toLowerCase()===target) return values[r][1]||'';
  return '';
}
function dateIso_(v) { if (!v) return ''; const d=new Date(v); return isNaN(d.getTime())?'':d.toISOString(); }
function latestDiagnosticsTimestamp_(ss) {
  const sh=ss.getSheetByName('Diagnostics'); if (!sh || sh.getLastRow()<2) return '';
  const values=sh.getDataRange().getValues(), headers=values[0].map(x=>String(x||'').trim()), ix=headers.indexOf('Run Timestamp'); if(ix<0)return '';
  let best=null;for(let i=1;i<values.length;i++){const d=new Date(values[i][ix]);if(!isNaN(d.getTime())&&(!best||d>best))best=d;}return best?best.toISOString():'';
}
function latestEspnTimestamp_(ss) {
  const candidates=[];
  const info=readInfoValue_(ss.getSheetByName('Data_Info'),'Updated At'); if(info)candidates.push(info);
  const st=ss.getSheetByName('Data_Status'); if(st&&st.getLastRow()>=2){const values=st.getDataRange().getValues();for(let i=1;i<values.length;i++){const key=String(values[i][0]||'');if(key==='Rosters + Free Agents'&&values[i][2])candidates.push(values[i][2]);if(key==='Last Update'&&values[i][1])candidates.push(values[i][1]);}}
  let best=null;candidates.forEach(v=>{const d=new Date(v);if(!isNaN(d.getTime())&&(!best||d>best))best=d;});return best?best.toISOString():'';
}

function readInfoNumber_(sh, key) {
  if (!sh) return 0;
  const values = sh.getDataRange().getDisplayValues();
  for (let r = 0; r < values.length; r++) {
    if (String(values[r][0] || '').trim().toLowerCase() === String(key).toLowerCase()) {
      return num_(values[r][1]);
    }
  }
  return 0;
}

function records_(sh, wanted, predicate) {
  if (!sh) return [];
  const values = sh.getDataRange().getDisplayValues();
  if (!values.length) return [];
  const header = values[0].map(x => String(x || '').trim());
  const indices = wanted.map(name => ({name, idx: header.indexOf(name)})).filter(x => x.idx >= 0);
  const out = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if (!row.some(v => String(v || '').trim() !== '')) continue;
    const obj = {};
    indices.forEach(x => obj[x.name] = row[x.idx]);
    if (!predicate || predicate(obj)) out.push(obj);
  }
  return out;
}

function num_(v) {
  if (v === null || v === undefined || v === '') return 0;
  const s = String(v).replace('%','').replace(',','.').trim();
  const n = Number(s);
  return isFinite(n) ? n : 0;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}


// ================= v5.9 ONLINE / MATCHUPS / NOTIFICATIONS =================
function normalizeText_(v) { return String(v || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,''); }
function settingPathValue_(ss, sheetName, path) {
  const sh=ss.getSheetByName(sheetName); if(!sh||sh.getLastRow()<2)return '';
  const h=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0]; const ix=h.indexOf(path); return ix>=0?sh.getRange(2,ix+1).getDisplayValue():'';
}
function nflWeekSchedule_(year, week) {
  const cache=CacheService.getScriptCache(), key='fcc-nfl-'+year+'-'+week; const cached=cache.get(key); if(cached){try{return JSON.parse(cached);}catch(e){}}
  const out={week:Number(week)||1, year:Number(year)||new Date().getFullYear(), games:[], ok:false};
  try{
    const url='https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?seasontype=2&week='+encodeURIComponent(week)+'&year='+encodeURIComponent(year);
    const r=UrlFetchApp.fetch(url,{method:'get',muteHttpExceptions:true,followRedirects:true}); if(r.getResponseCode()<200||r.getResponseCode()>=300)return out;
    const j=JSON.parse(r.getContentText())||{}; (j.events||[]).forEach(ev=>{const c=(ev.competitions||[])[0]||{},comps=c.competitors||[],home=comps.find(x=>x.homeAway==='home')||{},away=comps.find(x=>x.homeAway==='away')||{},status=(c.status||ev.status||{}).type||{};out.games.push({id:String(ev.id||''),start:ev.date||c.date||'',home:String(home.team?.abbreviation||''),away:String(away.team?.abbreviation||''),homeScore:num_(home.score),awayScore:num_(away.score),completed:Boolean(status.completed),status:String(status.shortDetail||status.detail||status.name||'')});});out.ok=out.games.length>0;cache.put(key,JSON.stringify(out),1800);
  }catch(e){}
  return out;
}
function scheduleMap_(schedule){const m={};(schedule?.games||[]).forEach(g=>{if(g.home)m[g.home]=g;if(g.away)m[g.away]=g;});return m;}
function remainingStarters_(ids,meta,schedule){const sm=scheduleMap_(schedule);let n=0;(ids||[]).forEach(id=>{const p=meta[String(id)]||{},team=String(p.team||id||'').toUpperCase();const g=sm[team];if(g&&!g.completed)n++;});return n;}
function sleeperCurrentMatchup_(ss,cfg,week,weekData,playerMeta,schedule){
  try{const sh=ss.getSheetByName('Week '+week);if(!sh)return null;const v=sh.getDataRange().getDisplayValues();if(!v.length)return null;
    const findHeader=(labels)=>v.findIndex(row=>labels.every((lab,i)=>normalizeText_(row[i]||'')===normalizeText_(lab)));
    const rosterHeader=findHeader(['Roster','Roster_ID']);const pointsHeader=findHeader(['Points','roster_id']);const matchupHeader=findHeader(['Team Name','Roster ID','Matchup ID']);if(rosterHeader<0||matchupHeader<0)return null;
    const rosters={},scores={},matches=[];
    for(let r=rosterHeader+1;r<v.length;r++){const name=String(v[r][0]||'').trim(),rid=String(v[r][1]||'').replace(/^'/,'').trim();if(!name||!rid)break;rosters[rid]={name,players:v[r].slice(4).map(String),starters:String(v[r][3]||'').replace(/^'/,'').split(',').filter(Boolean)};}
    if(pointsHeader>=0){for(let r=pointsHeader+1;r<v.length;r++){const name=String(v[r][0]||'').trim(),rid=String(v[r][1]||'').replace(/^'/,'').trim();if(!name||!rid)break;const direct=numMaybe_(v[r][2]);if(direct!==null){scores[rid]=direct;continue;}let sum=0,found=false;const starter=new Set(rosters[rid]?.starters||[]);(rosters[rid]?.players||[]).forEach((pid,i)=>{if(starter.has(String(pid))){const n=numMaybe_(v[r][4+i]);if(n!==null){sum+=n;found=true;}}});scores[rid]=found?Math.round(sum*100)/100:0;}}
    for(let r=matchupHeader+1;r<v.length;r++){const name=String(v[r][0]||'').trim(),rid=String(v[r][1]||'').replace(/^'/,'').trim(),mid=String(v[r][2]||'').trim();if(!name||!rid||!mid)break;matches.push({name,rid,mid});}
    const teamNorm=normalizeText_(cfg.team),mine=matches.find(x=>normalizeText_(x.name)===teamNorm)||matches.find(x=>normalizeText_(rosters[x.rid]?.name)===teamNorm);if(!mine)return null;const opp=matches.find(x=>x.mid===mine.mid&&x.rid!==mine.rid);if(!opp)return null;
    const proj={};(weekData||[]).forEach(r=>{const id=String(r.Player_ID||r['Player ID']||'');const p=numMaybe_(r.Projected);if(id&&p!==null)proj[id]=p;});const sumProj=rid=>{let found=false,s=0;(rosters[rid]?.starters||[]).forEach(id=>{if(proj[id]!=null){s+=proj[id];found=true;}});return found?Math.round(s*100)/100:null;};const myStarters=rosters[mine.rid]?.starters||[],oppStarters=rosters[opp.rid]?.starters||[];
    return {myTeam:mine.name||cfg.team,oppTeam:opp.name||rosters[opp.rid]?.name||'Adversário',myScore:scores[mine.rid]??0,oppScore:scores[opp.rid]??0,myProjection:sumProj(mine.rid),oppProjection:sumProj(opp.rid),myRemaining:remainingStarters_(myStarters,playerMeta,schedule),oppRemaining:remainingStarters_(oppStarters,playerMeta,schedule),status:statusFromSchedule_(schedule)};
  }catch(e){return null;}
}
function espnCurrentMatchup_(ss,cfg,week,rosters,schedule){
  try{const rows=records_(ss.getSheetByName('Data_Matchups'),['Away ID','Away Score','Home ID','Home Score','Week','Away Live','Home Live'],r=>num_(r.Week)===num_(week));const mineRows=(rosters||[]).filter(r=>normalizeText_(r['Team Name'])===normalizeText_(cfg.team));if(!mineRows.length)return null;const myId=String(mineRows[0]['Roster ID']);const match=rows.find(r=>String(r['Away ID'])===myId||String(r['Home ID'])===myId);if(!match)return null;const away=String(match['Away ID']),home=String(match['Home ID']),oppId=away===myId?home:away;const oppRows=(rosters||[]).filter(r=>String(r['Roster ID'])===oppId),projKey='Proj W'+week;const starter=r=>String(r['Roster Status']||'').toLowerCase()==='starter';const sumProj=rs=>rs.filter(starter).reduce((s,r)=>s+(numMaybe_(r[projKey])||0),0);const sm=scheduleMap_(schedule);const remain=rs=>rs.filter(starter).filter(r=>{const g=sm[String(r['NFL Team']||'').toUpperCase()];return g&&!g.completed;}).length;
    return {myTeam:cfg.team,oppTeam:oppRows[0]?.['Team Name']||'Adversário',myScore:num_(away===myId?match['Away Score']:match['Home Score']),oppScore:num_(away===myId?match['Home Score']:match['Away Score']),myProjection:Math.round(sumProj(mineRows)*100)/100,oppProjection:Math.round(sumProj(oppRows)*100)/100,myRemaining:remain(mineRows),oppRemaining:remain(oppRows),status:(schedule?.games||[]).some(g=>!g.completed)?'Em andamento':'Rodada finalizada'};
  }catch(e){return null;}
}

// ================= v6.0.1 MATCHUP RESILIENCE =================
// The source spreadsheets are authoritative. The app tries the rich/live
// structures first, then falls back to any matchup/result row already present
// in the workbook instead of displaying "SEM DADOS" prematurely.
function allRecords_(sh) {
  if (!sh || sh.getLastRow() < 2 || sh.getLastColumn() < 1) return [];
  const values = sh.getDataRange().getDisplayValues();
  const headers = values[0].map(x => String(x || '').trim());
  const out = [];
  for (let r = 1; r < values.length; r++) {
    if (!values[r].some(v => String(v || '').trim() !== '')) continue;
    const row = {};
    headers.forEach((h, i) => { if (h) row[h] = values[r][i]; });
    out.push(row);
  }
  return out;
}
function firstValue_(row, aliases) {
  for (let i = 0; i < aliases.length; i++) {
    const wanted = normalizeText_(aliases[i]).replace(/\s+/g,'');
    const key = Object.keys(row || {}).find(k => normalizeText_(k).replace(/\s+/g,'') === wanted);
    if (key != null && String(row[key] ?? '').trim() !== '') return row[key];
  }
  return '';
}
function maybeNumber_(v) {
  if (v === '' || v === null || v === undefined) return null;
  const n = numMaybe_(v); return n === null ? null : n;
}
function rowWeek_(row) {
  return num_(firstValue_(row, ['Week','Scoring Period','Matchup Period','Period','Semana']));
}
function rowIdentity_(row) {
  return String(firstValue_(row, ['Team Name','User','Owner','Team','Manager','Entry','Name']) || '').trim();
}
function rowOpponent_(row) {
  return String(firstValue_(row, ['Opponent','Opponent Name','Opp Team','Opp Team Name','Versus','Vs','Adversario','Adversário']) || '').trim();
}
function matchupRowForTeam_(rows,cfg,week) {
  const identities=[cfg.team,cfg.owner].concat(cfg.identities||[]).filter(Boolean).map(normalizeText_);
  const ids=(cfg.ids||[]).filter(Boolean).map(x=>String(x));
  let candidates=(rows||[]).filter(r=>!week || rowWeek_(r)===Number(week));
  let mine=candidates.find(r=>identities.includes(normalizeText_(rowIdentity_(r))));
  if(!mine&&ids.length) mine=candidates.find(r=>ids.includes(String(firstValue_(r,['Team ID','Roster ID','Entry ID','Owner ID']))));
  if(!mine) mine=candidates.find(r=>identities.some(id=>id && normalizeText_(JSON.stringify(r)).indexOf(id)>=0));
  return mine||null;
}
function statusFromSchedule_(schedule) {
  const games=(schedule?.games||[]); if(!games.length) return 'Programado';
  if(games.every(g=>g.completed)) return 'Rodada finalizada';
  if(games.some(g=>!g.completed && g.status && !/scheduled|pre/i.test(g.status))) return 'Em andamento';
  return 'Programado';
}
function genericSheetMatchup_(ss,cfg,week,schedule,sheetNames) {
  for (let i=0;i<sheetNames.length;i++) {
    const sh=ss.getSheetByName(sheetNames[i]); if(!sh) continue;
    const rows=allRecords_(sh), mine=matchupRowForTeam_(rows,cfg,week); if(!mine) continue;
    const opp=rowOpponent_(mine);
    if(!opp) continue;
    const myScore=maybeNumber_(firstValue_(mine,['Team Score','Score','Points','Fantasy Points','Total Points','Live Score']));
    const oppScore=maybeNumber_(firstValue_(mine,['Opp Score','Opponent Score','Opp Points','Opponent Points']));
    const myProj=maybeNumber_(firstValue_(mine,['Projected','Projection','Projected Score','Team Projection','Projected Points']));
    const oppProj=maybeNumber_(firstValue_(mine,['Opp Projected','Opponent Projected','Opponent Projection','Opp Projection']));
    return {myTeam:rowIdentity_(mine)||cfg.team,oppTeam:opp,myScore,myScoreSource:sheetNames[i],oppScore,myProjection:myProj,oppProjection:oppProj,myRemaining:null,oppRemaining:null,status:statusFromSchedule_(schedule),source:'Planilha • '+sheetNames[i]};
  }
  return null;
}
function rosterProjectionByTeam_(rosters, teamName, week, statusField) {
  const norm=normalizeText_(teamName), key='Proj W'+week;
  const rows=(rosters||[]).filter(r=>normalizeText_(r['Team Name']||r.Owner||'')===norm);
  let found=false,sum=0;
  rows.forEach(r=>{const st=normalizeText_(r[statusField]||r['Roster Slot']||'');if(st!=='starter')return;const n=numMaybe_(r[key]??r.Projection??r.Projected);if(n!==null){sum+=n;found=true;}});
  return found?Math.round(sum*100)/100:null;
}
function enrichFallbackProjection_(m,rosters,week,statusField) {
  if(!m)return m;
  if(m.myProjection==null)m.myProjection=rosterProjectionByTeam_(rosters,m.myTeam,week,statusField);
  if(m.oppProjection==null)m.oppProjection=rosterProjectionByTeam_(rosters,m.oppTeam,week,statusField);
  return m;
}
function resolveSleeperMatchup_(ss,cfg,week,weekData,playerMeta,schedule) {
  const rosterRows=allRecords_(ss.getSheetByName('Rosters'));
  const mineRoster=rosterRows.find(r=>normalizeText_(r['Team Name']||'')===normalizeText_(cfg.team))||rosterRows.find(r=>normalizeText_(r.Owner||'')===normalizeText_(cfg.owner));
  const lookupCfg=Object.assign({},cfg,{identities:[mineRoster?.Owner,mineRoster?.['Team Name']],ids:[mineRoster?.['Roster ID']]});
  const rich=sleeperCurrentMatchup_(ss,cfg,week,weekData,playerMeta,schedule);
  if(rich){rich.source='Planilha • Week '+week;return rich;}
  let m=genericSheetMatchup_(ss,lookupCfg,week,schedule,['Weekly Results','Matchups','Weekly Matchups','Schedule','Schedules']);
  if(m)return m;
  // Last resort: a row can exist under an alternate "Week N Results" name.
  const dynamic=ss.getSheets().map(s=>s.getName()).filter(n=>new RegExp('week\\s*'+week,'i').test(n) && /result|match|schedule/i.test(n));
  return genericSheetMatchup_(ss,lookupCfg,week,schedule,dynamic);
}
function resolveEspnMatchup_(ss,cfg,week,rosters,schedule) {
  const mineRoster=(rosters||[]).find(r=>normalizeText_(r['Team Name']||'')===normalizeText_(cfg.team))||(rosters||[]).find(r=>normalizeText_(r.Owner||'')===normalizeText_(cfg.owner));
  const lookupCfg=Object.assign({},cfg,{identities:[mineRoster?.Owner,mineRoster?.['Team Name']],ids:[mineRoster?.['Roster ID'],mineRoster?.['Team ID']]});
  const rich=espnCurrentMatchup_(ss,cfg,week,rosters,schedule);
  if(rich){rich.source='Planilha • Data_Matchups';return rich;}
  let m=genericSheetMatchup_(ss,lookupCfg,week,schedule,['Data_Weekly_Results','Weekly Results','Data_Schedule','Data_Schedules','Matchups','Schedule']);
  if(m)return enrichFallbackProjection_(m,rosters,week,'Roster Status');
  return null;
}

function sleeperWaiverConfig_(ss){const wd=num_(settingPathValue_(ss,'Settings','/settings/waiver_day_of_week')),hour=num_(settingPathValue_(ss,'Settings','/settings/daily_waivers_hour')),clear=num_(settingPathValue_(ss,'Settings','/settings/waiver_clear_days')),daily=num_(settingPathValue_(ss,'Settings','/settings/daily_waivers')),type=num_(settingPathValue_(ss,'Settings','/settings/waiver_type'));return {source:'Sleeper',waiverDayOfWeek:wd,dailyWaiversHour:hour,clearDays:clear,dailyWaivers:daily,waiverType:type,nextProcessAt:nextSleeperWaiverProcess_(wd,hour)};}
function nextSleeperWaiverProcess_(waiverDay,hour){try{const tz='America/Los_Angeles',days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],target=(Number(waiverDay)+1)%7,now=new Date();for(let i=0;i<10;i++){const probe=new Date(now.getTime()+i*86400000),dow=days.indexOf(Utilities.formatDate(probe,tz,'EEE'));if(dow!==target)continue;const d=Utilities.formatDate(probe,tz,'yyyy-MM-dd').split('-').map(Number),noon=new Date(Date.UTC(d[0],d[1]-1,d[2],12,0,0)),z=Utilities.formatDate(noon,tz,'Z'),sign=z[0]==='-'?-1:1,off=sign*(Number(z.slice(1,3))*60+Number(z.slice(3,5)))*60000,t=new Date(Date.UTC(d[0],d[1]-1,d[2],Number(hour)||0,5,0)-off);if(t>now)return t.toISOString();}}catch(e){}return '';}
function espnLeagueSettings_(ss,cfg){try{const year=num_(readInfoValue_(ss.getSheetByName('Data_Info'),'Year'))||new Date().getFullYear(),leagueId=readInfoValue_(ss.getSheetByName('Data_Info'),'League ID')||'';if(!leagueId)return null;const url='https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/'+year+'/segments/0/leagues/'+leagueId+'?view=mSettings&view=mStatus';const r=UrlFetchApp.fetch(url,{method:'get',muteHttpExceptions:true,followRedirects:true});if(r.getResponseCode()<200||r.getResponseCode()>=300)return null;return JSON.parse(r.getContentText())||null;}catch(e){return null;}}
function espnWaiverConfig_(ss,cfg){const j=espnLeagueSettings_(ss,cfg)||{},a=j.settings?.acquisitionSettings||{},status=j.status||{},keys=Object.keys(status.waiverProcessStatus||{}).map(k=>new Date(k)).filter(d=>!isNaN(d)&&d>new Date()).sort((x,y)=>x-y);return {source:'ESPN',acquisitionType:a.acquisitionType||'',waiverHours:a.waiverHours??null,waiverProcessDays:a.waiverProcessDays||[],waiverProcessHour:a.waiverProcessHour??null,nextProcessAt:keys.length?keys[0].toISOString():''};}
function rosterPlayerNames_(leagues){const out=[],seen={};Object.keys(leagues||{}).forEach(id=>{const l=leagues[id];if(!l||l.ok===false)return;(l.data?.rosters||[]).forEach(r=>{const name=String(r.Player||'').trim();if(!name||seen[normalizeText_(name)])return;seen[normalizeText_(name)]=1;out.push(name);});});return out.slice(0,48);}
function newsPlayerMatch_(text,name){const hay=normalizeText_(text),full=normalizeText_(name);if(hay.indexOf(full)>=0)return true;const t=full.split(/\s+/).filter(Boolean);if(t.length<2)return false;const first=t[0],last=t[t.length-1];return last.length>=4&&hay.indexOf(last)>=0&&hay.indexOf(first.slice(0,Math.min(3,first.length)))>=0;}
function buildRosterNews_(leagues){const cache=CacheService.getScriptCache(),names=rosterPlayerNames_(leagues),key='fcc-news-v602-'+Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.MD5,names.join('|'))).slice(0,20),cached=cache.get(key);if(cached){try{return JSON.parse(cached);}catch(e){}}const out=[];for(let i=0;i<names.length;i+=5){const batch=names.slice(i,i+5),q=batch.map(n=>'"'+n.replace(/"/g,'')+'"').join(' OR ')+' NFL fantasy when:3d';try{const url='https://news.google.com/rss/search?q='+encodeURIComponent(q)+'&hl=en-US&gl=US&ceid=US:en',r=UrlFetchApp.fetch(url,{method:'get',muteHttpExceptions:true,followRedirects:true,headers:{'User-Agent':'Mozilla/5.0 FCC/6.0.2'}});if(r.getResponseCode()<200||r.getResponseCode()>=300)continue;const doc=XmlService.parse(r.getContentText()),items=doc.getRootElement().getChild('channel').getChildren('item');items.slice(0,18).forEach(it=>{const title=it.getChildText('title')||'',desc=it.getChildText('description')||'',matched=batch.filter(n=>newsPlayerMatch_(title+' '+desc,n));if(!matched.length)return;const sourceEl=it.getChild('source');out.push({title:title,url:it.getChildText('link')||'',publishedAt:dateIso_(it.getChildText('pubDate'))||'',source:sourceEl?sourceEl.getText():'Google News',players:matched});});}catch(e){}}
  const dedup=[],seen={};out.sort((a,b)=>new Date(b.publishedAt||0)-new Date(a.publishedAt||0)).forEach(n=>{const k=normalizeText_(n.title);if(seen[k])return;seen[k]=1;dedup.push(n);});const final=dedup.slice(0,50);try{cache.put(key,JSON.stringify(final),3600);}catch(e){}return final;}
function roundWindow_(state,week,schedule){const games=(schedule?.games||[]).filter(g=>g.start).map(g=>new Date(g.start)).filter(d=>!isNaN(d));if(games.length){games.sort((a,b)=>a-b);return {start:new Date(games[0].getTime()-90*60000),end:new Date(games[games.length-1].getTime()+4*3600000)};}try{const d=new Date(String(state.season_start_date||'')+'T00:00:00Z');if(!isNaN(d)){const s=new Date(d.getTime()+(week-1)*7*86400000+20*3600000),e=new Date(s.getTime()+4*86400000+9*3600000);return {start:s,end:e};}}catch(e){}return {start:null,end:null};}
function notificationRoundWindow_(state,week,schedule){
  const games=(schedule?.games||[]).filter(g=>g.start).map(g=>({...g,date:new Date(g.start)})).filter(g=>!isNaN(g.date));
  const tz='America/New_York';
  const byDay=day=>games.filter(g=>Utilities.formatDate(g.date,tz,'EEE')===day).sort((a,b)=>a.date-b.date);
  const thu=byDay('Thu'), mon=byDay('Mon');
  // Pré-rodada: 2 h antes do primeiro kickoff de quinta-feira.
  // Pós-rodada: estimativa de 4 h após o último kickoff de segunda-feira.
  // Se a semana não tiver jogo nesses dias, cai no calendário geral da rodada.
  const fallback=roundWindow_(state,week,schedule);
  const start=thu.length?new Date(thu[0].date.getTime()-2*3600000):fallback.start;
  const end=mon.length?new Date(mon[mon.length-1].date.getTime()+4*3600000):fallback.end;
  return {start,end,thursdayKickoff:thu[0]?.date||null,mondayKickoff:mon.length?mon[mon.length-1].date:null};
}
function buildNotificationEvents_(payload,state,schedule){
  const out=[],w=payload.analysisWeek,now=new Date(),win=notificationRoundWindow_(state,w,schedule);
  if(win.start&&win.start>now)out.push({id:'round-start-w'+w,type:'round_start',at:win.start.toISOString(),title:'NFL W'+w+' começa hoje',body:'Faltam cerca de 2 horas para o jogo de quinta. Revise titulares, lesões e projeções.'});
  if(win.end&&win.end>now)out.push({id:'round-end-w'+w,type:'round_end',at:win.end.toISOString(),title:'Rodada W'+w+' encerrada',body:'Monday Night Football terminou. Confira resultados e prepare os waivers.'});
  Object.keys(payload.leagues||{}).forEach(id=>{
    const l=payload.leagues[id];if(!l||l.ok===false)return;
    const wc=l.waiverConfig||{},proc=wc.nextProcessAt?new Date(wc.nextProcessAt):null;
    if(!proc||isNaN(proc))return;
    // Abertura da janela respeita a configuração da liga quando a fonte expõe
    // a duração: ESPN waiverHours; Sleeper clearDays. Nunca deixa a abertura
    // anterior ao encerramento estimado da rodada.
    let configuredHours=null;
    if(wc.source==='ESPN' && Number(wc.waiverHours)>0) configuredHours=Number(wc.waiverHours);
    if(wc.source==='Sleeper' && Number(wc.clearDays)>0) configuredHours=Number(wc.clearDays)*24;
    const afterRound=win.end?new Date(win.end.getTime()+10*60000):null;
    const byConfig=configuredHours?new Date(proc.getTime()-configuredHours*3600000):null;
    let open=byConfig||afterRound;
    if(afterRound && (!open || open<afterRound)) open=afterRound;
    if(open&&open>now&&open<proc)out.push({id:'waiver-open-'+id+'-w'+w,type:'waiver_start',leagueId:id,at:open.toISOString(),title:'Janela de waivers aberta • '+l.name,body:'Revise prioridades, drops e bids antes do processamento desta liga.'});
    const done=new Date(proc.getTime()+15*60000);
    if(done>now)out.push({id:'waiver-end-'+id+'-w'+w,type:'waiver_end',leagueId:id,at:done.toISOString(),title:'Waivers processados • '+l.name,body:'O horário de processamento previsto passou. Confira claims, adds e drops.'});
  });
  return out.sort((a,b)=>new Date(a.at)-new Date(b.at)).slice(0,24);
}
