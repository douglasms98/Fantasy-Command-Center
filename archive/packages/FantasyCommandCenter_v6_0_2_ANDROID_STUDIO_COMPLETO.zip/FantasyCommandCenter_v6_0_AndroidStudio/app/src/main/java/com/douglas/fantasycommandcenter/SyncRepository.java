package com.douglas.fantasycommandcenter;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class SyncRepository {
    public static final String PREFS="fcc_native", KEY_ENDPOINT="sync_endpoint", KEY_TOKEN="sync_token", KEY_CACHE="cached_payload", KEY_LAST="last_sync";
    private SyncRepository(){}
    public static boolean migrateLegacyConfig(Context context) {
        SharedPreferences target=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        String ep=target.getString(KEY_ENDPOINT,"");
        String tk=target.getString(KEY_TOKEN,"");
        if(isEndpoint(ep) && tk!=null && !tk.trim().isEmpty()) return false;
        String foundEndpoint=isEndpoint(ep)?ep:"";
        String foundToken=(tk==null?"":tk.trim());
        try {
            File dir=new File(context.getApplicationInfo().dataDir,"shared_prefs");
            File[] files=dir.listFiles((d,n)->n.endsWith(".xml"));
            if(files!=null){
                for(File f:files){
                    String name=f.getName().substring(0,f.getName().length()-4);
                    SharedPreferences legacy=context.getSharedPreferences(name,Context.MODE_PRIVATE);
                    Map<String,?> all=legacy.getAll();
                    if(all==null) continue;
                    String localEndpoint="", localToken="";
                    for(Map.Entry<String,?> e:all.entrySet()){
                        if(!(e.getValue() instanceof String)) continue;
                        String key=e.getKey()==null?"":e.getKey().toLowerCase(Locale.ROOT);
                        String val=((String)e.getValue()).trim();
                        if(isEndpoint(val)) localEndpoint=val;
                        if(isLikelyToken(key,val)) localToken=val;
                    }
                    if(foundEndpoint.isEmpty() && !localEndpoint.isEmpty()) foundEndpoint=localEndpoint;
                    if(foundToken.isEmpty() && !localToken.isEmpty() && (!localEndpoint.isEmpty() || name.toLowerCase(Locale.ROOT).contains("fcc") || name.toLowerCase(Locale.ROOT).contains("fantasy"))) foundToken=localToken;
                    if(!foundEndpoint.isEmpty() && !foundToken.isEmpty()) break;
                }
            }
        } catch(Exception ignored){}
        boolean changed=false;
        SharedPreferences.Editor ed=target.edit();
        if(!foundEndpoint.isEmpty() && !isEndpoint(ep)){ed.putString(KEY_ENDPOINT,foundEndpoint);changed=true;}
        if(!foundToken.isEmpty() && (tk==null || tk.trim().isEmpty())){ed.putString(KEY_TOKEN,foundToken);changed=true;}
        if(changed) ed.apply();
        return changed;
    }
    private static boolean isEndpoint(String v){return v!=null && v.startsWith("https://script.google.com/macros/s/") && v.contains("/exec");}
    private static boolean isLikelyToken(String key,String v){
        if(v==null) return false; String x=v.trim(); if(x.length()<24 || x.length()>256 || x.startsWith("http")) return false;
        boolean named=key.contains("token")||key.contains("sync_key")||key.contains("synckey")||key.equals("key")||key.contains("api_key");
        boolean shape=x.matches("[A-Za-z0-9_\-]{24,256}");
        return named && shape;
    }

    public static String sync(Context context) throws Exception {
        SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        String endpoint=p.getString(KEY_ENDPOINT,""); String token=p.getString(KEY_TOKEN,"");
        if(endpoint==null||endpoint.trim().isEmpty()) throw new IllegalStateException("Endpoint de sincronização não configurado.");
        String sep=endpoint.contains("?")?"&":"?";
        URL url=new URL(endpoint+sep+"key="+URLEncoder.encode(token==null?"":token,StandardCharsets.UTF_8.name())+"&t="+System.currentTimeMillis());
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("GET"); c.setUseCaches(false); c.setRequestProperty("Accept","application/json");
        int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        String body=read(in); c.disconnect();
        if(code<200||code>=300) throw new IOException("HTTP "+code+": "+body);
        JSONObject j=new JSONObject(body); if(!j.optBoolean("ok",false)) throw new IOException(j.optString("error","Resposta inválida do servidor"));
        String now=j.optString("generatedAt",java.time.Instant.now().toString());
        p.edit().putString(KEY_CACHE,body).putString(KEY_LAST,now).apply();
        FantasyNotificationScheduler.scheduleFromPayload(context,j);
        return body;
    }
    private static String read(InputStream in)throws IOException{if(in==null)return"";BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();return sb.toString();}
}
