package com.douglas.fantasycommandcenter;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class NewsRepository {
    public static final String KEY_CACHE="native_news_cache";
    private NewsRepository(){}
    public static String fetch(Context context,String playersJson) throws Exception {
        JSONArray input=new JSONArray(playersJson==null?"[]":playersJson); List<String> names=new ArrayList<>(); Set<String> seen=new HashSet<>();
        for(int i=0;i<input.length() && names.size()<42;i++){String n=input.optString(i,"").trim();String k=norm(n);if(n.length()>2&&seen.add(k))names.add(n);}
        JSONArray out=new JSONArray(); Set<String> titles=new HashSet<>();
        for(int i=0;i<names.size();i+=5){List<String> batch=names.subList(i,Math.min(i+5,names.size()));StringBuilder q=new StringBuilder();for(String n:batch){if(q.length()>0)q.append(" OR ");q.append('"').append(n.replace("\"","")).append('"');}q.append(" NFL fantasy when:3d");
            String url="https://news.google.com/rss/search?q="+URLEncoder.encode(q.toString(),"UTF-8")+"&hl=en-US&gl=US&ceid=US:en"; parseFeed(url,batch,out,titles); }
        JSONObject payload=new JSONObject();payload.put("generatedAt",Instant.now().toString());payload.put("news",out);String raw=payload.toString();
        context.getSharedPreferences(SyncRepository.PREFS,Context.MODE_PRIVATE).edit().putString(KEY_CACHE,raw).apply(); return raw;
    }
    private static void parseFeed(String url,List<String> batch,JSONArray out,Set<String> seen) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","Mozilla/5.0 FCC/6.0.2");InputStream in=c.getInputStream();
        XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(new InputStreamReader(in,StandardCharsets.UTF_8));int event=p.getEventType();String tag="",title="",link="",date="",source="",desc="";boolean item=false;
        while(event!=XmlPullParser.END_DOCUMENT && out.length()<40){if(event==XmlPullParser.START_TAG){tag=p.getName();if("item".equals(tag)){item=true;title=link=date=source=desc="";}}else if(event==XmlPullParser.TEXT&&item){String t=p.getText();if("title".equals(tag))title+=t;else if("link".equals(tag))link+=t;else if("pubDate".equals(tag))date+=t;else if("source".equals(tag))source+=t;else if("description".equals(tag))desc+=t;}else if(event==XmlPullParser.END_TAG){if("item".equals(p.getName())&&item){item=false;String nk=norm(title);if(!title.trim().isEmpty()&&seen.add(nk)){JSONArray players=new JSONArray();String hay=norm(title+" "+desc);for(String n:batch)if(matches(hay,n))players.put(n);if(players.length()>0){JSONObject o=new JSONObject();o.put("title",title.trim());o.put("url",link.trim());o.put("publishedAt",iso(date));o.put("source",source.trim().isEmpty()?"Google News":source.trim());o.put("players",players);out.put(o);}}}tag="";}event=p.next();}
        in.close();c.disconnect();
    }
    private static boolean matches(String hay,String name){String full=norm(name);if(hay.contains(full))return true;String[] t=full.split(" ");if(t.length<2)return hay.contains(full);String last=t[t.length-1];String first=t[0];return last.length()>=4&&hay.contains(last)&&hay.contains(first.substring(0,Math.min(3,first.length())));}
    private static String norm(String s){String x=Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();return x;}
    private static String iso(String d){try{return ZonedDateTime.parse(d.trim(),DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toString();}catch(Exception e){return "";}}
}
