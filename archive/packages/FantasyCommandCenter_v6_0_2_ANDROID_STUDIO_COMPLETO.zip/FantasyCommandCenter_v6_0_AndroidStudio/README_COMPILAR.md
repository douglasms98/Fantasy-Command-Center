# Fantasy Command Center 2026 — v6.0.2

Correções desta versão:
- ícone FCC nativo incluído em todas as densidades;
- migração automática da URL/chave de sincronização a partir de SharedPreferences de versões anteriores;
- confrontos W4 incluídos no snapshot offline e parser de confrontos Sleeper/ESPN reforçado;
- notícias também são buscadas nativamente pelo Android (Google News RSS), com cache local, sem depender apenas do Apps Script;
- waivers no celular usam cards compactos de uma linha, expansíveis ao toque;
- package mantido: com.douglas.fantasycommandcenter; versionCode 602.

## Compilar
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle Sync.
3. Build > Make Project.
4. Para testar: Run.
5. Para atualizar o app instalado, gere APK assinado com a mesma keystore da versão anterior.

## Apps Script
Publique `apps-script/Fantasy_Command_Center_Sync_API_v6_0_2.gs` como nova versão da MESMA implantação Web App. Não execute `setupFantasySyncKey()` de novo se a chave atual já existe.

## URL/chave
O app tenta migrar automaticamente valores antigos preservados no diretório de SharedPreferences. Se a versão anterior foi desinstalada/teve os dados apagados, o Android já não possui esses valores e será necessário colá-los novamente uma vez. A v6.0.2 não gera nem substitui sua chave automaticamente.
