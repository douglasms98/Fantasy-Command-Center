# FCC v7.2.7 — Live Schedule + Planner Fix

## AO VIVO
O estado do confronto deixou de depender de placar > 0 ou de um status genérico da liga.

Prioridade:
1. **AO VIVO**: há pelo menos um jogador do roster (ou do adversário, quando o roster dele está disponível) cujo time NFL está jogando agora.
2. **EM ANDAMENTO**: a rodada NFL já começou, ainda não acabou, mas nenhum jogador relevante está em campo naquele horário.
3. **ENCERRADO**: todos os jogos NFL da semana terminaram ou a fonte marcou explicitamente final.
4. **PRÉ-JOGO**: nenhum jogo da semana começou.

## Fonte do calendário
`NflScheduleRepository.java` consulta o scoreboard público ESPN por semana e guarda o último payload válido em SharedPreferences. Falha de rede não apaga o cache.

## Planejamento 3 semanas
A janela agora seleciona explicitamente `[W atual, W+1, W+2]` em vez de usar os três primeiros blocos recebidos. Assim W4 não permanece no planner quando a análise já virou W5.
