package com.douglas.fantasycommandcenter;

import android.content.Context;
import org.json.*;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Native fallback de notícias. A fonte principal continua sendo o Sync API,
 * que traduz títulos completos via LanguageApp. Este fallback preserva fontes
 * relevantes em inglês e acrescenta uma segunda busca pt-BR sem substituir o
 * feed melhor do servidor. */
public final class NewsRepository {
    public static final String KEY_CACHE="native_news_cache";
    private NewsRepository(){}

    public static String fetch(Context context,String playersJson) throws Exception {
        JSONArray input=new JSONArray(playersJson==null?"[]":playersJson);
        List<String> names=new ArrayList<>(); Set<String> seenNames=new HashSet<>();
        for(int i=0;i<input.length() && names.size()<48;i++){
            String n=input.optString(i,"").trim(),k=norm(n);
            if(n.length()>2&&seenNames.add(k))names.add(n);
        }
        JSONArray out=new JSONArray(); Set<String> titles=new HashSet<>();
        for(int i=0;i<names.size();i+=5){
            List<String> batch=names.subList(i,Math.min(i+5,names.size()));
            StringBuilder q=new StringBuilder();
            for(String n:batch){if(q.length()>0)q.append(" OR ");q.append('"').append(n.replace("\"","")).append('"');}
            q.append(" NFL fantasy when:4d");
            String encoded=URLEncoder.encode(q.toString(),"UTF-8");
            parseFeed("https://news.google.com/rss/search?q="+encoded+"&hl=en-US&gl=US&ceid=US:en",batch,out,titles);
            if(out.length()<12) parseFeed("https://news.google.com/rss/search?q="+encoded+"&hl=pt-BR&gl=BR&ceid=BR:pt-419",batch,out,titles);
        }
        JSONObject payload=new JSONObject();
        payload.put("generatedAt",Instant.now().toString());
        payload.put("news",out);
        payload.put("source","native-fallback-v6.0.4");
        String raw=payload.toString();
        context.getSharedPreferences(SyncRepository.PREFS,Context.MODE_PRIVATE).edit().putString(KEY_CACHE,raw).apply();
        return raw;
    }

    private static void parseFeed(String url,List<String> batch,JSONArray out,Set<String> seen) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 FCC/6.0.4");
        int code=c.getResponseCode(); if(code<200||code>=300){c.disconnect();return;}
        InputStream in=c.getInputStream();
        XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();
        p.setInput(new InputStreamReader(in,StandardCharsets.UTF_8));
        int event=p.getEventType();String tag="",title="",link="",date="",source="",desc="";boolean item=false;
        while(event!=XmlPullParser.END_DOCUMENT && out.length()<55){
            if(event==XmlPullParser.START_TAG){tag=p.getName();if("item".equals(tag)){item=true;title=link=date=source=desc="";}}
            else if(event==XmlPullParser.TEXT&&item){String t=p.getText();if("title".equals(tag))title+=t;else if("link".equals(tag))link+=t;else if("pubDate".equals(tag))date+=t;else if("source".equals(tag))source+=t;else if("description".equals(tag))desc+=t;}
            else if(event==XmlPullParser.END_TAG){
                if("item".equals(p.getName())&&item){
                    item=false;String nk=norm(title);
                    if(!title.trim().isEmpty()&&seen.add(nk)){
                        JSONArray players=new JSONArray();String hay=norm(title+" "+desc);
                        for(String n:batch)if(matches(hay,n))players.put(n);
                        if(players.length()>0){
                            JSONObject o=new JSONObject();
                            o.put("title",title.trim());o.put("titlePt",translateCommon(title.trim()));
                            o.put("url",link.trim());o.put("publishedAt",iso(date));
                            o.put("source",source.trim().isEmpty()?"Google News":source.trim());o.put("players",players);
                            o.put("priority",priority(title+" "+desc));out.put(o);
                        }
                    }
                }
                tag="";
            }
            event=p.next();
        }
        in.close();c.disconnect();
    }

    private static String priority(String text){
        String s=norm(text);
        if(s.matches(".*\\b(ruled out|injured reserve|inactive|did not practice|dnp|surgery|suspended)\\b.*") || s.matches(".*(^| )out( |$).*$")) return "URGENTE";
        if(s.matches(".*\\b(questionable|doubtful|limited|practice|expected to play|game time decision|hamstring|ankle|knee|concussion|groin|glute)\\b.*")) return "IMPORTANTE";
        return "NORMAL";
    }

    private static String translateCommon(String title){
        String t=title;
        t=t.replaceAll("(?i)Week ([0-9]+) Outlook for Fantasy Football","Perspectiva para a Semana $1 do Fantasy Football");
        t=t.replaceAll("(?i)Week ([0-9]+) Outlook","Perspectiva para a Semana $1");
        t=t.replaceAll("(?i)limited practice","treino limitado");
        t=t.replaceAll("(?i)expected to play","deve jogar");
        t=t.replaceAll("(?i)ruled out","fora do jogo");
        t=t.replaceAll("(?i)questionable","questionável");
        t=t.replaceAll("(?i)doubtful","duvidoso");
        t=t.replaceAll("(?i)injured reserve","reserva de lesionados");
        return t;
    }

    private static boolean matches(String hay,String name){String full=norm(name);if(hay.contains(full))return true;String[] t=full.split(" ");if(t.length<2)return hay.contains(full);String last=t[t.length-1],first=t[0];return last.length()>=4&&hay.contains(last)&&hay.contains(first.substring(0,Math.min(3,first.length())));}
    private static String norm(String s){return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();}
    private static String iso(String d){try{return ZonedDateTime.parse(d.trim(),DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toString();}catch(Exception e){return "";}}
}
