# Fantasy Command Center 2026 — v6.0 Android

## O que muda
- O app continua online híbrido: sincroniza quando há internet e preserva o último cache quando fica offline.
- A fonte estruturada continua sendo Google Sheets, mas o Sync API também consulta estado/calendário NFL, notícias, metadados Sleeper e configurações de waiver.
- Pré-rodada: alerta cerca de 2 h antes do primeiro kickoff de quinta-feira da semana NFL.
- Pós-rodada: alerta estimado 4 h após o último kickoff de segunda-feira (Monday Night Football).
- Waivers: cada liga usa sua própria configuração retornada pelo Sleeper/ESPN; o app agenda início do período após a rodada e confirmação após o horário previsto de processamento.

## Arquivos
1. `Fantasy_Command_Center_2026_v6_0_ANDROID.html` — dashboard/WebView.
2. `Fantasy_Command_Center_Sync_API_v6_0.gs` — Google Apps Script Web App.
3. `FantasyNotificationScheduler.kt` — scheduler/receiver Android.
4. `AndroidManifest_v6_notification_patch.xml` — permissões e receiver.

## Integração Android
O HTML chama `AndroidSync.scheduleNotifications(json)` após cada sincronização. A classe JavaScript bridge que você já usa para `syncNow()`, `notificationsEnabled()` e `setNotificationsEnabled()` deve expor também `scheduleNotifications(json)`.

Se a bridge atual for uma classe única, copie para ela o corpo dos três métodos existentes em `FantasyNotificationBridge` ou delegue `scheduleNotifications` para `FantasyNotificationScheduler.schedule(...)`.

No Android 13+ solicite `POST_NOTIFICATIONS` em runtime. Para alarmes exatos, alguns aparelhos/versões podem exigir autorização do usuário nas configurações do sistema; sem ela, adapte para WorkManager/alarme inexato.

## Google Apps Script
Substitua o código do Web App pelo arquivo v6.0 e publique uma nova versão do deployment mantendo a mesma URL `/exec`, se possível. A schema passa a `fcc-sync-v1.3.0` e continua aceita pelo HTML porque o parser reconhece qualquer schema iniciado por `fcc-sync-`.
