# Fantasy Command Center v5.6 — Android Studio limpo

Este pacote contém **somente o código do aplicativo**. O projeto-base deve ser criado pelo próprio Android Studio no seu computador.

Isso é intencional: o Android Studio gera o Gradle Wrapper, JDK/Gradle settings e `local.properties` adequados ao seu ambiente, eliminando a camada de scripts que causou os erros anteriores.

Abra `LEIA_PRIMEIRO.txt` e siga os passos.
