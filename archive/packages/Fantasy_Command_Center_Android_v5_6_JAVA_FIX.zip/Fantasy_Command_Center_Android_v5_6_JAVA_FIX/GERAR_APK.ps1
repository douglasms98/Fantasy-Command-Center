$ErrorActionPreference = "Stop"
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path

# ------------------------------------------------------------------
# 1) Detecta automaticamente um Java valido.
#    O Android Studio normalmente inclui o JetBrains Runtime em \jbr.
# ------------------------------------------------------------------
$JavaCandidates = @()

# JAVA_HOME existente so entra se realmente contiver java.exe.
if ($env:JAVA_HOME) { $JavaCandidates += $env:JAVA_HOME }

$JavaCandidates += @(
  "$env:ProgramFiles\Android\Android Studio\jbr",
  "$env:ProgramFiles\Android\Android Studio\jre",
  "${env:ProgramFiles(x86)}\Android\Android Studio\jbr",
  "$env:LOCALAPPDATA\Programs\Android Studio\jbr",
  "$env:LOCALAPPDATA\Android\Android Studio\jbr"
)

$JavaHome = $null
foreach ($Candidate in $JavaCandidates) {
  if ($Candidate -and (Test-Path (Join-Path $Candidate "bin\java.exe"))) {
    $JavaHome = $Candidate
    break
  }
}

# Ultimo recurso: java.exe ja disponivel no PATH.
if (-not $JavaHome) {
  $JavaCommand = Get-Command java.exe -ErrorAction SilentlyContinue
  if ($JavaCommand) {
    $JavaBin = Split-Path -Parent $JavaCommand.Source
    $JavaHome = Split-Path -Parent $JavaBin
  }
}

if (-not $JavaHome) {
  Write-Host "Java/JDK nao encontrado." -ForegroundColor Red
  Write-Host ""
  Write-Host "No Android Studio, abra:"
  Write-Host "File > Settings > Build, Execution, Deployment > Build Tools > Gradle"
  Write-Host "e confirme que existe um Gradle JDK selecionado."
  Write-Host ""
  Write-Host "Caminho esperado na instalacao padrao:"
  Write-Host "C:\Program Files\Android\Android Studio\jbr"
  exit 3
}

$env:JAVA_HOME = $JavaHome
$env:Path = (Join-Path $JavaHome "bin") + ";" + $env:Path
Write-Host "Java encontrado:" -ForegroundColor Green
Write-Host $JavaHome -ForegroundColor Green
& (Join-Path $JavaHome "bin\java.exe") -version
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

# ------------------------------------------------------------------
# 2) Detecta Android SDK.
# ------------------------------------------------------------------
$SdkCandidates = @(
  $env:ANDROID_SDK_ROOT,
  $env:ANDROID_HOME,
  "$env:LOCALAPPDATA\Android\Sdk"
) | Where-Object { $_ -and (Test-Path $_) }

if (-not $SdkCandidates) {
  Write-Host "Android SDK nao encontrado." -ForegroundColor Yellow
  Write-Host "Abra o Android Studio e confirme o caminho em Tools > SDK Manager."
  exit 2
}
$Sdk = $SdkCandidates[0]
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk
Write-Host "Android SDK encontrado:" -ForegroundColor Green
Write-Host $Sdk -ForegroundColor Green

$LocalProps = Join-Path $Project "local.properties"
("sdk.dir=" + ($Sdk -replace '\\','\\\\')) | Set-Content -Encoding ASCII $LocalProps

# ------------------------------------------------------------------
# 3) Baixa Gradle localmente (uma unica vez) e compila.
# ------------------------------------------------------------------
$GradleVersion = "9.6.0"
$ToolsDir = Join-Path $Project ".build-tools"
$GradleHome = Join-Path $ToolsDir "gradle-$GradleVersion"
$GradleExe = Join-Path $GradleHome "bin\gradle.bat"

if (-not (Test-Path $GradleExe)) {
  New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
  $Zip = Join-Path $ToolsDir "gradle-$GradleVersion-bin.zip"
  Write-Host "Baixando Gradle $GradleVersion..." -ForegroundColor Cyan
  Invoke-WebRequest -UseBasicParsing "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $Zip
  Expand-Archive -Force $Zip $ToolsDir
  Remove-Item $Zip -Force
}

Write-Host ""
Write-Host "Compilando Fantasy Command Center..." -ForegroundColor Cyan
& $GradleExe -p $Project --no-daemon assembleDebug
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$Apk = Join-Path $Project "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $Apk) {
  $Out = Join-Path $Project "Fantasy_Command_Center_2026_v5_6.apk"
  Copy-Item -Force $Apk $Out
  Write-Host ""
  Write-Host "APK GERADO:" -ForegroundColor Green
  Write-Host $Out -ForegroundColor Green
  Start-Process explorer.exe "/select,`"$Out`""
} else {
  Write-Host "Build terminou, mas o APK nao foi localizado no caminho esperado." -ForegroundColor Yellow
  exit 4
}
