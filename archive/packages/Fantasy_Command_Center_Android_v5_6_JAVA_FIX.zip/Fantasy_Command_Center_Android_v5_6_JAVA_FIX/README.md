# Fantasy Command Center 2026 — Android v5.6

Projeto Android nativo que empacota o dashboard **Fantasy Command Center 2026** em um `WebView` local, agora com **sincronização Google Sheets + cache offline**.

## O que funciona
- Dashboard completo offline.
- Overview, standings, weekly, roster, waivers e trades.
- Análise de drop e contexto do roster.
- Trades 1×1, 2×1 e 1×2 com indicação de drop.
- Botão **⟳ Atualizar dados**.
- Tela **⚙ Sincronização** para configurar o Web App.
- Cache da última atualização no armazenamento interno do Android.
- Fallback automático para o snapshot embutido quando ainda não existe cache.
- Sincronização de roster, standings, resultados, projeções e free agents.
- Nas ligas Sleeper, o Web App consulta também metadados de lesão e contexto do QB1 quando disponíveis.
- Após a sincronização, o dashboard recalcula drop risk, necessidades posicionais e propostas de trade.

## Arquitetura da sincronização
O APK **não contém credenciais Google**. O arquivo `Fantasy_Command_Center_Sync_API.gs` é implantado uma única vez como Google Apps Script Web App e executa usando sua conta. O app guarda apenas:
- URL `/exec` do Web App;
- chave secreta de sincronização;
- último payload válido em cache local.

Veja `SINCRONIZACAO_GOOGLE_SHEETS.txt` para o passo a passo.

## Gerar o APK
1. Instale o Android Studio.
2. Abra esta pasta (`Fantasy_Command_Center_Android_v5_6`) como projeto.
3. Instale/aceite Android SDK 36 se solicitado.
4. Use **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

Ou execute `GERAR_APK.bat` no Windows.

APK debug padrão:
`app/build/outputs/apk/debug/app-debug.apk`

O script também cria:
`Fantasy_Command_Center_2026_v5_6.apk`

## Observação sobre atualização das fontes
O botão do app lê o conteúdo **atual** das três planilhas. Ele não consegue executar os Apps Scripts originais que pertencem a outros projetos/bound scripts. Se alguma planilha exige um refresh manual do Sleeper/ESPN, faça esse refresh primeiro e depois toque em **Atualizar dados** no app.


## Correcao JAVA_HOME
Esta revisao do script detecta automaticamente o JDK/JetBrains Runtime embutido no Android Studio (pasta `jbr`) e ignora um JAVA_HOME invalido.
