# No shrinking is enabled in v5.5. Kept for future release builds.
