package com.douglas.fantasycommandcenter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String PREFS = "fcc_sync";
    private static final String PREF_ENDPOINT = "endpoint";
    private static final String PREF_TOKEN = "token";
    private static final String PREF_LAST_SYNC = "last_sync";
    private static final String CACHE_FILE = "fcc_sync_cache.json";
    private static final int MAX_SYNC_BYTES = 15 * 1024 * 1024;

    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(7, 16, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 16, 31));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 16, 31));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new SyncBridge(), "AndroidSync");

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private class SyncBridge {
        @JavascriptInterface
        public String getEndpoint() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_ENDPOINT, "");
        }

        @JavascriptInterface
        public String getToken() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TOKEN, "");
        }

        @JavascriptInterface
        public String getLastSync() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_LAST_SYNC, "");
        }

        @JavascriptInterface
        public void saveConfig(String endpoint, String token) {
            String cleanEndpoint = endpoint == null ? "" : endpoint.trim();
            String cleanToken = token == null ? "" : token.trim();
            getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit()
                    .putString(PREF_ENDPOINT, cleanEndpoint)
                    .putString(PREF_TOKEN, cleanToken)
                    .apply();
            callback("onConfigSaved", "OK");
        }

        @JavascriptInterface
        public String getCachedPayload() {
            try {
                File file = new File(getFilesDir(), CACHE_FILE);
                if (!file.exists()) return "";
                return readAll(new FileInputStream(file));
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void clearCache() {
            try {
                File file = new File(getFilesDir(), CACHE_FILE);
                if (file.exists()) file.delete();
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_LAST_SYNC).apply();
                callback("onCacheCleared", "OK");
            } catch (Exception e) {
                callback("onSyncError", "Não foi possível limpar o cache: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void syncNow() {
            final String endpoint = getEndpoint();
            final String token = getToken();
            if (endpoint == null || endpoint.trim().isEmpty()) {
                callback("onSyncError", "Sincronização não configurada. Abra ⚙ Sincronização e informe o URL do Web App.");
                return;
            }
            if (!endpoint.startsWith("https://")) {
                callback("onSyncError", "Use um endpoint HTTPS do Google Apps Script.");
                return;
            }

            callback("onSyncStarted", "Atualizando planilhas...");
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    Uri.Builder builder = Uri.parse(endpoint).buildUpon()
                            .appendQueryParameter("app", "android")
                            .appendQueryParameter("v", "5.6");
                    if (token != null && !token.isEmpty()) {
                        builder.appendQueryParameter("key", token);
                    }
                    URL url = new URL(builder.build().toString());
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setInstanceFollowRedirects(true);
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(45000);
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("User-Agent", "FantasyCommandCenter/5.6 Android");

                    int code = conn.getResponseCode();
                    InputStream stream = (code >= 200 && code < 400) ? conn.getInputStream() : conn.getErrorStream();
                    String body = readAll(stream);
                    if (code < 200 || code >= 400) {
                        throw new Exception("HTTP " + code + (body.isEmpty() ? "" : ": " + body.substring(0, Math.min(180, body.length()))));
                    }
                    if (body.length() < 20) throw new Exception("Resposta vazia do servidor.");

                    JSONObject parsed = new JSONObject(body);
                    if (!parsed.optBoolean("ok", true)) {
                        throw new Exception(parsed.optString("error", "Servidor recusou a sincronização."));
                    }
                    String schema = parsed.optString("schema", "");
                    if (!(schema.startsWith("fcc-sync-") || schema.startsWith("fcc-data-"))) {
                        throw new Exception("Schema de sincronização incompatível: " + schema);
                    }

                    File file = new File(getFilesDir(), CACHE_FILE);
                    try (FileOutputStream out = new FileOutputStream(file, false)) {
                        out.write(body.getBytes(StandardCharsets.UTF_8));
                    }
                    String when = java.time.OffsetDateTime.now().toString();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_LAST_SYNC, when).apply();
                    callbackBase64("onSyncSuccessFromBase64", body);
                } catch (Exception e) {
                    callback("onSyncError", "Falha ao atualizar: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }, "fcc-sync").start();
        }
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int n;
            while ((n = in.read(buffer)) != -1) {
                total += n;
                if (total > MAX_SYNC_BYTES) throw new Exception("Resposta acima de 15 MB.");
                out.write(buffer, 0, n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void callback(String method, String message) {
        String encoded = Base64.encodeToString((message == null ? "" : message).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "window.FCCNative && window.FCCNative." + method + " && window.FCCNative." + method + "(atob('" + encoded + "'))";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void callbackBase64(String method, String payload) {
        String encoded = Base64.encodeToString(payload.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String js = "window.FCCNative && window.FCCNative." + method + " && window.FCCNative." + method + "('" + encoded + "')";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.removeJavascriptInterface("AndroidSync");
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
