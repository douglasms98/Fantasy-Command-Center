# Fantasy Command Center 2026 — Android v5.5

Projeto Android nativo que empacota o dashboard `Fantasy Command Center 2026 v5.5` em um `WebView` local.

## O que já funciona
- Dashboard completo offline.
- Overview, standings, weekly, roster, waivers e trades.
- Filtros e busca em JavaScript.
- Trades 1x1, 2x1 e 1x2 com indicação de drop.
- Tema escuro e layout responsivo para celular.
- LocalStorage/DOM storage habilitados.
- Permissão de internet já incluída para futura sincronização.

## Gerar o APK no Android Studio
1. Instale o Android Studio estável.
2. Abra esta pasta (`Fantasy_Command_Center_Android_v5_5`) como projeto.
3. Aguarde o Android Studio instalar/sincronizar Gradle e Android SDK 36, se solicitado.
4. Menu **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar no celular
- Envie `app-debug.apk` para o Android.
- Abra o arquivo no celular.
- Autorize "Instalar apps desconhecidos" para o app usado para abrir o APK, se o Android solicitar.

## Dados
A v5.5 está embutida em `app/src/main/assets/index.html`; portanto o APK funciona offline com o snapshot atual.

### Atualização automática pelo Google Sheets
A estrutura Android já possui permissão de internet e WebView com storage/cache. A conexão privada com Google Sheets deve ser adicionada com OAuth/Google Identity ou por um backend seguro. Não inclua credenciais privadas dentro do HTML/APK.
