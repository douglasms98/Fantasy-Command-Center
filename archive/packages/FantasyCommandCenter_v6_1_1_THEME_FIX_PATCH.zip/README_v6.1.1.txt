Fantasy Command Center v6.1.1 — correção de tema

Substitua somente:
app/src/main/assets/fcc/index.html

Correção principal:
- Semi-dark volta a usar exatamente a paleta azul da Preview 2.
- Regras pretas AMOLED agora se aplicam somente ao Full Dark.
- Tema claro permanece inalterado.
- Cor do chrome/WebView acompanha o tema selecionado.

Não é necessário atualizar a API.
