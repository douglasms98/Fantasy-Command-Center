from app.models import NormalizedLeague, SourceFreshness

def test_normalized_contract_keeps_source_timestamps():
    l = NormalizedLeague(id='sleeper1',platform='Sleeper',name='Paga PPR',team='RJ Outlaws',owner='RJ Outlaws',leagueId='1',source=SourceFreshness(providerStatus='OK'))
    assert l.source.providerStatus == 'OK'
    assert l.analysisWeek == 1

def test_large_data_stays_outside_root_contract():
    l = NormalizedLeague(id='espn1',platform='ESPN',name='Cartola',team='RJ Outlaws',owner='Douglas',leagueId='1',data={'freeAgents':[{'id':str(i)} for i in range(100)]})
    root = l.model_dump()
    data = root.pop('data')
    assert 'data' not in root
    assert len(data['freeAgents']) == 100
