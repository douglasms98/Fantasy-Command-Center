from __future__ import annotations
from datetime import datetime, timezone
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .auth import client_key
from .config import settings
from .league_config import PENDING_LEAGUES, league_configs
from .repositories.firestore import FirestoreRepo
from .sync_service import SyncService

s = settings()
app = FastAPI(title='Fantasy Command Center Backend', version='0.1.1')

if s.FCC_ROLE == 'api':
    app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=False, allow_methods=['GET'], allow_headers=['*'])

@app.get('/health')
def health():
    return {'ok': True, 'service':f'fcc-{s.FCC_ROLE}', 'version':'0.1.1', 'mode':'shadow' if not s.FCC_ENABLE_APP_CUTOVER else 'cutover-enabled', 'at':datetime.now(timezone.utc).isoformat()}

if s.FCC_ROLE == 'api':
    @app.get('/v1/sources', dependencies=[Depends(client_key)])
    def sources():
        repo = FirestoreRepo(); rows = []
        for cfg in league_configs():
            root = repo.get_league_root(cfg.id) or {}; src = root.get('source') or {}
            rows.append({
                'id':cfg.id,'platform':cfg.platform,'name':cfg.name,
                'providerUpdatedAt':src.get('providerUpdatedAt'),'backendUpdatedAt':src.get('backendUpdatedAt'),
                'sheetUpdatedAt':src.get('sheetUpdatedAt'),'providerStatus':src.get('providerStatus','UNKNOWN'),
                'backendStatus':src.get('backendStatus','UNKNOWN'),'sheetStatus':src.get('sheetStatus','UNKNOWN'),
                'fallbackUsed':src.get('fallbackUsed',False),'notes':src.get('notes',[])
            })
        return {'ok':True,'generatedAt':datetime.now(timezone.utc).isoformat(),'sources':rows}

    @app.get('/v1/leagues/{league_id}', dependencies=[Depends(client_key)])
    def league(league_id: str):
        repo=FirestoreRepo(); root=repo.get_league_root(league_id)
        if not root: raise HTTPException(404,'LEAGUE_NOT_FOUND')
        return {'ok':True,**root,'data':repo.get_sections(league_id)}

    @app.get('/v1/app-payload', dependencies=[Depends(client_key)])
    def app_payload():
        if not s.FCC_ENABLE_APP_CUTOVER:
            raise HTTPException(503, detail={
                'code':'CUTOVER_NOT_ENABLED',
                'message':'Backend v0.1 is shadow-only. Keep the Android app on the Apps Script Sync API until parity validation passes.'
            })
        repo=FirestoreRepo(); leagues={}; normalized=[]; max_week=1; completed=0; season_ended=False; source_rows=[]
        for cfg in league_configs():
            root=repo.get_league_root(cfg.id)
            if not root: continue
            data=repo.get_sections(cfg.id); entry={**root,'data':data,'ok':True,'loaded':True}
            leagues[cfg.id]=entry; normalized.append(entry)
            max_week=max(max_week,int(root.get('analysisWeek') or 1)); completed=max(completed,int(root.get('completedWeeks') or 0)); season_ended=season_ended or bool(root.get('seasonEnded'))
            source_rows.append({'id':cfg.id,**(root.get('source') or {})})
        return {
            'ok':True,'schema':'fcc-backend-v1','apiVersion':'0.1.1','generatedAt':datetime.now(timezone.utc).isoformat(),
            'analysisWeek':max_week,'completedWeeks':completed,'seasonEnded':season_ended,'leagues':leagues,
            'normalizedLeagues':normalized,'pendingLeagues':PENDING_LEAGUES,'sources':source_rows,
            'backend':{'mode':'cloud-run-firestore','contract':'fcc-normalized-v1','database':'firestore','recommendations':'migration-in-progress'}
        }

if s.FCC_ROLE == 'worker':
    # Deploy the worker Cloud Run service with --no-allow-unauthenticated.
    # Cloud Scheduler invokes this route using OIDC/IAM, so no shared worker secret is stored in the app.
    @app.post('/internal/sync')
    async def internal_sync():
        run=await SyncService().run_all()
        return run.model_dump(mode='json')
