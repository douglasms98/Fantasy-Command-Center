from fastapi import Header, HTTPException
from .config import settings

async def client_key(x_fcc_key: str | None = Header(default=None)):
    expected = settings().FCC_CLIENT_KEY
    if expected and x_fcc_key != expected:
        raise HTTPException(status_code=401, detail='UNAUTHORIZED')
