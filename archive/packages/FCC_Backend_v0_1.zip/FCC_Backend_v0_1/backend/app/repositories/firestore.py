from __future__ import annotations
import gzip
import json
from datetime import datetime, timezone
from typing import Any
from google.cloud import firestore
from ..config import settings
from ..models import NormalizedLeague, SyncRun

# Conservative chunk size: safely below Firestore's per-document limit after metadata overhead.
CHUNK_BYTES = 650_000

class FirestoreRepo:
    def __init__(self):
        s = settings()
        self.db = firestore.Client(project=s.FCC_GCP_PROJECT, database=s.FCC_FIRESTORE_DATABASE)

    def save_sync_run(self, run: SyncRun):
        self.db.collection('sync_runs').document(run.runId).set(run.model_dump(mode='json'), merge=True)

    def _save_section(self, root, key: str, value: Any, now_iso: str):
        raw = json.dumps(value, ensure_ascii=False, separators=(',',':'), default=str).encode('utf-8')
        packed = gzip.compress(raw, compresslevel=6)
        chunks = [packed[i:i+CHUNK_BYTES] for i in range(0, len(packed), CHUNK_BYTES)] or [b'']
        section = root.collection('sections').document(str(key))
        section.set({
            'encoding':'gzip-json-v1', 'chunkCount':len(chunks),
            'rawBytes':len(raw), 'compressedBytes':len(packed), 'updatedAt':now_iso
        }, merge=False)
        batch = self.db.batch()
        for i, chunk in enumerate(chunks):
            batch.set(section.collection('chunks').document(f'{i:04d}'), {'data':chunk}, merge=False)
            # Firestore batch supports max 500 writes; flush safely.
            if (i + 1) % 450 == 0:
                batch.commit(); batch = self.db.batch()
        batch.commit()

    def _read_section(self, section) -> Any:
        meta = section.to_dict() or {}
        count = int(meta.get('chunkCount') or 0)
        if meta.get('encoding') != 'gzip-json-v1' or count < 1:
            return None
        packed = bytearray()
        for i in range(count):
            d = section.reference.collection('chunks').document(f'{i:04d}').get()
            if not d.exists:
                raise RuntimeError(f'MISSING_SECTION_CHUNK {section.id}/{i}')
            packed.extend((d.to_dict() or {}).get('data') or b'')
        return json.loads(gzip.decompress(bytes(packed)).decode('utf-8'))

    def save_league(self, league: NormalizedLeague, run_id: str):
        now = datetime.now(timezone.utc)
        league.source.backendUpdatedAt = now
        league.source.backendStatus = 'OK'
        root = self.db.collection('league_state').document(league.id)
        payload = league.model_dump(mode='json')
        data = payload.pop('data', {})
        root.set({**payload, 'lastRunId': run_id, 'updatedAt': now.isoformat()}, merge=True)
        for key, value in data.items():
            self._save_section(root, str(key), value, now.isoformat())


    def mark_league_failure(self, league_id: str, provider: str, error: str, run_id: str):
        root = self.db.collection('league_state').document(league_id)
        snap = root.get()
        existing = snap.to_dict() if snap.exists else {}
        source = dict((existing or {}).get('source') or {})
        source['providerStatus'] = 'ERROR'
        source['backendStatus'] = 'ERROR'
        source['fallbackUsed'] = False
        notes = list(source.get('notes') or [])
        notes.append(f'{provider}: {error}')
        source['notes'] = notes[-8:]
        root.set({
            'source': source, 'lastRunId': run_id,
            'lastErrorAt': datetime.now(timezone.utc).isoformat(),
            'lastError': str(error)[:1500]
        }, merge=True)

    def get_league_root(self, league_id: str) -> dict[str, Any] | None:
        snap = self.db.collection('league_state').document(league_id).get()
        return snap.to_dict() if snap.exists else None

    def get_sections(self, league_id: str) -> dict[str, Any]:
        out = {}
        for section in self.db.collection('league_state').document(league_id).collection('sections').stream():
            out[section.id] = self._read_section(section)
        return out

    def all_leagues(self) -> list[dict[str, Any]]:
        return [d.to_dict() for d in self.db.collection('league_state').stream()]
