from __future__ import annotations
from datetime import datetime
from typing import Any
import google.auth
from googleapiclient.discovery import build
from ..models import LeagueConfig

class SheetsBackupReader:
    """Read backup health only. v0.1 does not import league data from Sheets yet."""
    def __init__(self):
        creds, _ = google.auth.default(scopes=['https://www.googleapis.com/auth/spreadsheets.readonly'])
        self.svc = build('sheets', 'v4', credentials=creds, cache_discovery=False)

    def values(self, spreadsheet_id: str, a1: str) -> list[list[Any]]:
        out = self.svc.spreadsheets().values().get(spreadsheetId=spreadsheet_id, range=a1).execute()
        return out.get('values') or []

    @staticmethod
    def _parse_iso(value: Any) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        except Exception:
            return None

    def health(self, cfg: LeagueConfig) -> dict[str, Any]:
        rows = self.values(cfg.spreadsheetId, "'FCC_Automation_Status'!A1:J250")
        latest_attempt = None
        latest_success = None
        latest_status = 'NOT_CONFIGURED'
        latest_message = ''

        for row in rows[1:]:
            if len(row) < 6 or str(row[5]).upper() != 'FULL':
                continue
            finished = self._parse_iso(row[3] if len(row) > 3 else None) or self._parse_iso(row[2] if len(row) > 2 else None)
            if not finished:
                continue
            status = str(row[4] if len(row) > 4 else '').upper()
            if latest_attempt is None or finished > latest_attempt:
                latest_attempt = finished
                latest_status = status or 'UNKNOWN'
                latest_message = str(row[9] if len(row) > 9 else '')
            if status.startswith('SUCCESS') and (latest_success is None or finished > latest_success):
                latest_success = finished

        if latest_attempt is None:
            status = 'NOT_CONFIGURED'
        elif latest_status.startswith('SUCCESS'):
            status = 'OK'
        else:
            # Important: an in-place spreadsheet refresh can partially write before failing.
            # A newer failed FULL makes the live sheet unsafe as an automatic data fallback.
            status = 'UNSAFE_AFTER_FAILED_FULL'

        return {
            'status': status,
            'lastSuccessAt': latest_success,
            'lastAttemptAt': latest_attempt,
            'latestFullStatus': latest_status,
            'message': latest_message,
        }

    def last_update(self, cfg: LeagueConfig) -> datetime | None:
        return self.health(cfg).get('lastSuccessAt')
