from __future__ import annotations
from abc import ABC, abstractmethod
from ..models import LeagueConfig, NormalizedLeague

class ProviderAdapter(ABC):
    @abstractmethod
    async def fetch(self, cfg: LeagueConfig) -> NormalizedLeague:
        raise NotImplementedError
