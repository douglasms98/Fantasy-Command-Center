from __future__ import annotations
from datetime import datetime, timezone
import httpx
from .base import ProviderAdapter
from ..models import LeagueConfig, NormalizedLeague, SourceFreshness

BASE = 'https://api.sleeper.app/v1'

class SleeperAdapter(ProviderAdapter):
    def __init__(self, timeout: float = 20.0):
        self.timeout = timeout

    async def _get(self, client: httpx.AsyncClient, path: str):
        r = await client.get(BASE + path)
        r.raise_for_status()
        return r.json()

    async def fetch(self, cfg: LeagueConfig) -> NormalizedLeague:
        now = datetime.now(timezone.utc)
        async with httpx.AsyncClient(timeout=self.timeout, headers={'User-Agent':'FCC/7.x'}) as client:
            state = await self._get(client, '/state/nfl')
            week = int(state.get('week') or state.get('display_week') or 1)
            season_type = str(state.get('season_type') or '').lower()
            season_ended = season_type == 'post'
            completed = 18 if season_ended else max(0, week - 1)

            league = await self._get(client, f'/league/{cfg.leagueId}')
            users = await self._get(client, f'/league/{cfg.leagueId}/users')
            rosters = await self._get(client, f'/league/{cfg.leagueId}/rosters')
            matchups = await self._get(client, f'/league/{cfg.leagueId}/matchups/{week}')
            transactions = await self._get(client, f'/league/{cfg.leagueId}/transactions/{week}')

        user_by_id = {str(u.get('user_id')): u for u in users or []}
        roster_rows = []
        roster_by_id = {}
        for r in rosters or []:
            rid = str(r.get('roster_id'))
            owner = user_by_id.get(str(r.get('owner_id')), {})
            row = {
                'rosterId': rid,
                'ownerId': str(r.get('owner_id') or ''),
                'owner': owner.get('display_name') or owner.get('username') or '',
                'players': r.get('players') or [],
                'starters': r.get('starters') or [],
                'reserve': r.get('reserve') or [],
                'taxi': r.get('taxi') or [],
                'settings': r.get('settings') or {},
                'metadata': r.get('metadata') or {},
            }
            roster_rows.append(row)
            roster_by_id[rid] = row

        matchup_rows = []
        for m in matchups or []:
            rid = str(m.get('roster_id'))
            matchup_rows.append({
                'matchupId': m.get('matchup_id'),
                'rosterId': rid,
                'points': m.get('points'),
                'customPoints': m.get('custom_points'),
                'players': m.get('players') or [],
                'starters': m.get('starters') or [],
                'playersPoints': m.get('players_points') or {},
                'owner': (roster_by_id.get(rid) or {}).get('owner',''),
            })

        return NormalizedLeague(
            id=cfg.id, platform=cfg.platform, name=cfg.name, team=cfg.team, owner=cfg.owner,
            leagueId=cfg.leagueId, teamId=cfg.teamId, analysisWeek=week,
            completedWeeks=completed, seasonEnded=season_ended,
            source=SourceFreshness(providerUpdatedAt=now, providerStatus='OK', backendStatus='PENDING'),
            data={
                'league': league,
                'users': users,
                'rosters': roster_rows,
                'currentWeekMatchups': matchup_rows,
                'transactions': transactions,
            }
        )
