from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from uuid import uuid4
from .adapters.sleeper import SleeperAdapter
from .adapters.espn import EspnAdapter
from .adapters.sheets import SheetsBackupReader
from .league_config import league_configs
from .models import NormalizedLeague, SyncRun
from .repositories.firestore import FirestoreRepo

class SyncService:
    def __init__(self, repo: FirestoreRepo | None = None):
        self.repo = repo or FirestoreRepo()

    async def run_all(self, requested_by: str = 'scheduler') -> SyncRun:
        run = SyncRun(runId=str(uuid4()), startedAt=datetime.now(timezone.utc), requestedBy=requested_by)
        self.repo.save_sync_run(run)
        sheets = None
        try:
            sheets = SheetsBackupReader()
        except Exception as e:
            run.errors.append(f'Sheets reader unavailable: {e}')

        for cfg in league_configs():
            try:
                adapter = SleeperAdapter() if cfg.platform == 'Sleeper' else EspnAdapter()
                league = await adapter.fetch(cfg)
                if sheets:
                    try:
                        backup = sheets.health(cfg)
                        league.source.sheetUpdatedAt = backup.get('lastSuccessAt')
                        league.source.sheetStatus = backup.get('status') or 'UNKNOWN'
                        if backup.get('status') == 'UNSAFE_AFTER_FAILED_FULL':
                            league.source.notes.append('Backup sheet has a newer failed FULL run; do not use it as automatic data fallback until repaired.')
                        if backup.get('latestFullStatus') not in ('SUCCESS', 'SUCCESS_WITH_WARNINGS', 'NOT_CONFIGURED'):
                            league.source.notes.append(f"Latest backup FULL status: {backup.get('latestFullStatus')}")
                    except Exception as e:
                        league.source.sheetStatus = 'ERROR'
                        league.source.notes.append(f'Backup sheet health failed: {e}')
                self.repo.save_league(league, run.runId)
                run.leagueResults[cfg.id] = {'status':'SUCCESS','provider':cfg.platform,'week':league.analysisWeek}
            except Exception as e:
                # Shadow phase: preserve the last valid state and mark health as failed.
                # We do NOT silently manufacture/provider-substitute league data yet.
                self.repo.mark_league_failure(cfg.id, cfg.platform, str(e), run.runId)
                run.leagueResults[cfg.id] = {'status':'FAILED','provider':cfg.platform,'error':str(e)}
                run.errors.append(f'{cfg.id}: {e}')

        run.finishedAt = datetime.now(timezone.utc)
        ok = sum(1 for x in run.leagueResults.values() if x.get('status') == 'SUCCESS')
        run.status = 'SUCCESS' if ok == len(run.leagueResults) else ('PARTIAL' if ok else 'FAILED')
        self.repo.save_sync_run(run)
        return run
