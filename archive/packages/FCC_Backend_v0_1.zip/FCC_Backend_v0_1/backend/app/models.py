from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field

Platform = Literal['Sleeper', 'ESPN']

class SourceFreshness(BaseModel):
    providerUpdatedAt: datetime | None = None
    backendUpdatedAt: datetime | None = None
    sheetUpdatedAt: datetime | None = None
    providerStatus: str = 'UNKNOWN'
    sheetStatus: str = 'UNKNOWN'
    backendStatus: str = 'UNKNOWN'
    fallbackUsed: bool = False
    notes: list[str] = Field(default_factory=list)

class LeagueConfig(BaseModel):
    id: str
    platform: Platform
    name: str
    team: str
    owner: str
    leagueId: str
    teamId: str | None = None
    spreadsheetId: str
    enabled: bool = True

class NormalizedLeague(BaseModel):
    id: str
    platform: Platform
    name: str
    team: str
    owner: str
    leagueId: str
    teamId: str | None = None
    analysisWeek: int = 1
    completedWeeks: int = 0
    seasonEnded: bool = False
    source: SourceFreshness = Field(default_factory=SourceFreshness)
    data: dict[str, Any] = Field(default_factory=dict)
    matchup: dict[str, Any] | None = None
    waiverConfig: dict[str, Any] = Field(default_factory=dict)
    powerRankings: list[dict[str, Any]] = Field(default_factory=list)

class SyncRun(BaseModel):
    runId: str
    startedAt: datetime
    finishedAt: datetime | None = None
    status: Literal['RUNNING','SUCCESS','PARTIAL','FAILED'] = 'RUNNING'
    requestedBy: str = 'scheduler'
    leagueResults: dict[str, dict[str, Any]] = Field(default_factory=dict)
    errors: list[str] = Field(default_factory=list)

class AppPayload(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    ok: bool = True
    schema_: str = Field(default='fcc-backend-v1', alias='schema', serialization_alias='schema')
    apiVersion: str = '0.1.0'
    generatedAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    analysisWeek: int = 1
    completedWeeks: int = 0
    seasonEnded: bool = False
    leagues: dict[str, dict[str, Any]] = Field(default_factory=dict)
    normalizedLeagues: list[dict[str, Any]] = Field(default_factory=list)
    pendingLeagues: list[dict[str, Any]] = Field(default_factory=list)
    sources: list[dict[str, Any]] = Field(default_factory=list)
    backend: dict[str, Any] = Field(default_factory=dict)
