# Verificação técnica do pacote v0.1

Executado antes do empacotamento:

- `pytest`: **2 testes passaram** para o contrato normalizado e separação de dados grandes.
- `python -m compileall backend/app`: **OK**.
- `node --check` nos arquivos Apps Script gerados/patchados: **OK**.
- `node --check` no JavaScript principal extraído do HTML: **OK**.
- validação manual da regra de freshness: somente `Workflow=FULL` + `Status=SUCCESS*` atualiza `sheetUpdatedAt`.
- backend marca planilha `UNSAFE_AFTER_FAILED_FULL` se existir uma execução FULL mais recente que falhou.
- `/v1/app-payload` possui gate `FCC_ENABLE_APP_CUTOVER=false` na configuração inicial.

## Limite do ambiente desta geração

O ambiente local não tinha o pacote `google-cloud-firestore` pré-instalado e não possui acesso ao índice PyPI, portanto o smoke-test HTTP completo com todas as dependências externas não pôde ser executado aqui. O `requirements.txt` inclui explicitamente as dependências necessárias e a implantação Cloud Run instala essas dependências durante o build.

Isso não substitui o teste de implantação da Fase 3. O primeiro deploy deve permanecer em shadow mode.
