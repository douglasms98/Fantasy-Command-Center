# Fantasy Command Center 2026 — Backend v0.1 (Shadow)

Este pacote inicia a migração do FCC 7.x para backend online **sem trocar a fonte de produção do app ainda**.

## Princípio de segurança

A ordem deliberada é:

1. Automatizar e validar completamente as três planilhas atuais.
2. Exibir a hora real do último backup completo na tela **Fontes**.
3. Subir o backend em modo **shadow**.
4. Comparar backend x planilhas por pelo menos uma rodada completa.
5. Somente depois habilitar o cutover do Android.

Enquanto `FCC_ENABLE_APP_CUTOVER=false`, `/v1/app-payload` devolve 503 de propósito. Isso impede uma troca acidental da interface para um contrato ainda não homologado.

## Fluxos

### Produção durante a migração

Sleeper / ESPN -> Apps Script automático -> Google Sheets -> Sync API atual -> HTML/WebView -> cache Android

### Backend shadow

Sleeper / ESPN -> `fcc-worker` (Cloud Run) -> Firestore -> `fcc-api` (Cloud Run)

O worker também lê apenas o **timestamp do último backup FULL** das planilhas para medir a saúde da redundância.

### Fluxo alvo após homologação

Android -> backend online -> se falhar: Sync API/Sheets -> se falhar: cache local

## Arquivos principais

- `apps_script/Sleeper_Data_Export_v8_FCC_AUTOMATION_PATCHED.gs`: fonte Sleeper atual com somente o patch necessário para rodar sem UI em gatilhos.
- `apps_script/Sleeper_Backup_Automation_v1.gs`: automação/validação/registro do backup Sleeper.
- `apps_script/ESPN_Backup_Automation_v1.gs`: automação/validação/registro do backup ESPN.
- `Fantasy_Command_Center_Sync_API_v7_0_1_BACKEND_BRIDGE.gs`: ponte atual, ainda Apps Script, lendo apenas backups FULL válidos.
- `Fantasy_Command_Center_2026_v7_0_BACKEND_PREP.html`: interface aprovada com horários em Fontes.
- `backend/`: FastAPI para Cloud Run + Firestore.
- `docs/ARQUITETURA.md`: decisões técnicas e proteções contra regressão.
- `IMPLEMENTACAO_PASSO_A_PASSO.md`: roteiro de implantação em ordem segura.

## Estado da versão v0.1

Pronto para iniciar **Fase 1 (planilhas automáticas)** e **Fase 2 (backend shadow)**. Não é um cutover de produção.
