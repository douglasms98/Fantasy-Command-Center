# Data contract — freshness

Exemplo esperado em `/v1/sources`:

```json
{
  "id": "sleeper1",
  "platform": "Sleeper",
  "providerUpdatedAt": "2026-10-04T23:15:04Z",
  "backendUpdatedAt": "2026-10-04T23:15:05Z",
  "sheetUpdatedAt": "2026-10-04T18:20:42Z",
  "providerStatus": "OK",
  "backendStatus": "OK",
  "sheetStatus": "OK",
  "fallbackUsed": false,
  "notes": []
}
```

## Semântica

- `providerUpdatedAt`: consulta online concluída com sucesso.
- `backendUpdatedAt`: persistência Firestore concluída.
- `sheetUpdatedAt`: último `FULL / SUCCESS*` da planilha.
- não atualizar timestamps de sucesso em falha;
- atualização só de Players/Free Agents não muda `sheetUpdatedAt`.

## Interface

A tela Fontes usa o mais recente relevante como “Última atualização” e, quando os três campos existem, apresenta uma linha secundária Provedor / Backend / Backup. Nenhuma mudança de navegação ou card estrutural é necessária.
