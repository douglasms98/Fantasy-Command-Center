# Arquitetura FCC 7.x — desenho inicial

## 1. Objetivos

- atualização online sem depender da abertura do app;
- Google Sheets como backup independente e auditável;
- nenhum redesenho da interface AMOLED aprovada;
- migração reversível;
- separar coleta, armazenamento, API e apresentação;
- timestamps explícitos para não confundir dado recente com cache antigo;
- não misturar IDs entre ligas.

## 2. Componentes

### 2.1 Planilhas de backup

As três fontes atuais permanecem:

| ID interno | Plataforma | Planilha | League ID esperado |
|---|---|---|---|
| sleeper1 | Sleeper | Sleeper Data Export LIGA PPR | 1398756583143477248 |
| sleeper2 | Sleeper | Sleeper Data Export LIGA SNF | 1397017429250478080 |
| espn1 | ESPN | ESPN Data Export 2026 - Adaptada | 1088464775 |

Cada automação valida **Spreadsheet ID + League ID** antes de qualquer refresh. Se houver divergência, aborta.

A aba escondida `FCC_Automation_Status` registra:

- Run ID;
- versão da automação;
- início e fim ISO;
- status;
- workflow;
- league ID esperado e real;
- semana;
- mensagem/contagens.

A tela Fontes considera como freshness apenas `Workflow=FULL` e `Status` iniciado por `SUCCESS`.

### 2.2 Worker online

`fcc-worker` no Cloud Run:

- privado (sem acesso anônimo);
- chamado pelo Cloud Scheduler via OIDC;
- consulta Sleeper/ESPN diretamente;
- normaliza metadados básicos;
- grava Firestore;
- lê o timestamp do backup das planilhas para monitorar redundância;
- registra cada ciclo em `sync_runs`.

### 2.3 Firestore

Estrutura inicial:

```text
sync_runs/{runId}
league_state/{leagueIdInterno}
  metadata pequena
  source { providerUpdatedAt, backendUpdatedAt, sheetUpdatedAt, statuses... }
  sections/{nomeDaSecao}
    metadata da seção
    chunks/{0000...}
```

As seções grandes são comprimidas com gzip e divididas em chunks conservadores. Isso evita colocar rosters/free agents/histórico inteiro em um documento único.

### 2.4 API online

`fcc-api` no Cloud Run:

- somente leitura;
- lê Firestore;
- `/health`;
- `/v1/sources` para saúde/freshness;
- `/v1/leagues/{id}` para inspeção shadow;
- `/v1/app-payload` **bloqueado por padrão** na v0.1.

A API pública usa `X-FCC-Key` apenas como proteção inicial do app pessoal. Não deve ser tratada como segredo inviolável, porque chaves dentro de APKs podem ser extraídas. Uma fase posterior pode adicionar App Check/API Gateway.

## 3. Contrato de freshness

Cada liga terá três relógios independentes:

- `providerUpdatedAt`: backend conseguiu consultar o provedor neste instante;
- `backendUpdatedAt`: snapshot válido foi persistido no Firestore;
- `sheetUpdatedAt`: último backup `FULL` concluído com sucesso na planilha.

Nunca usar um horário parcial (ex.: atualização só do player DB) como horário do backup completo.

## 4. Ordem de fallback alvo

Após homologação:

1. backend online;
2. Sync API / Google Sheets;
3. último cache local Android.

Na v0.1, a ordem **não muda**: o app continua no Sync API / Sheets.

## 5. Regras anti-bug

1. **Sem cutover antecipado:** `FCC_ENABLE_APP_CUTOVER=false`.
2. **Identidade rígida:** ID da planilha e da liga precisam coincidir.
3. **Sem UI em trigger:** rotinas automáticas não chamam `SpreadsheetApp.getUi()`.
4. **Locks:** um refresh longo não pode sobrepor outro na mesma planilha.
5. **Verificação pós-refresh:** abas críticas e W atual são verificadas antes de registrar SUCCESS.
6. **Falha explícita:** provider/backend com erro não ganha timestamp falso de sucesso.
7. **Planilha pós-falha não é fallback automático:** se o FULL mais recente falhou, o backend marca `UNSAFE_AFTER_FAILED_FULL`; um refresh in-place pode ter escrito apenas parte das abas.
8. **Último snapshot válido permanece:** falha nova não apaga o estado anterior no Firestore.
9. **Segredos fora de células:** cookies ESPN privados e client key ficam em Script Properties/Secret Manager.
10. **Interface desacoplada:** backend não altera CSS, navegação ou cards; só muda o contrato de dados após paridade.
11. **Dados grandes fora do documento raiz:** evita limite/tamanho inesperado no Firestore.

## 6. Critério para liberar o backend ao app

Todos precisam passar:

- 3 planilhas executando sem intervenção por no mínimo 24 h;
- uma rodada NFL completa monitorada;
- W corrente e preliminares iguais entre backend e planilhas;
- rosters e titulares iguais;
- standings/resultados iguais para semanas concluídas;
- ausência de troca de league ID;
- free agents e transações dentro da tolerância definida;
- timestamps coerentes;
- teste de provider offline -> planilha/cache continua disponível;
- nenhum erro visual na Preview AMOLED.
