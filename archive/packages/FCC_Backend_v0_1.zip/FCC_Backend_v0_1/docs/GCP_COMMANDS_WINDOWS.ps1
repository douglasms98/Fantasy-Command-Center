# FCC 7.x — comandos de referência para PowerShell (NÃO executar sem revisar variáveis)
$PROJECT_ID = "SEU_PROJECT_ID"
$REGION = "southamerica-east1"
$WORKER_SA = "fcc-worker@$PROJECT_ID.iam.gserviceaccount.com"
$API_SA = "fcc-api@$PROJECT_ID.iam.gserviceaccount.com"
$SCHEDULER_SA = "fcc-scheduler@$PROJECT_ID.iam.gserviceaccount.com"

gcloud config set project $PROJECT_ID

gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com firestore.googleapis.com cloudscheduler.googleapis.com secretmanager.googleapis.com sheets.googleapis.com

# Firestore (execute somente se o projeto ainda não tiver o banco default)
gcloud firestore databases create --database="(default)" --location=$REGION --edition=standard --type=firestore-native --delete-protection

# Service accounts
gcloud iam service-accounts create fcc-worker --display-name="FCC Worker"
gcloud iam service-accounts create fcc-api --display-name="FCC Read API"
gcloud iam service-accounts create fcc-scheduler --display-name="FCC Scheduler Invoker"

# Firestore access
gcloud projects add-iam-policy-binding $PROJECT_ID --member="serviceAccount:$WORKER_SA" --role="roles/datastore.user"
gcloud projects add-iam-policy-binding $PROJECT_ID --member="serviceAccount:$API_SA" --role="roles/datastore.viewer"

# Client key for the personal Android API
$CLIENT_KEY = ([guid]::NewGuid().ToString("N") + [guid]::NewGuid().ToString("N"))
$CLIENT_KEY | gcloud secrets create fcc-client-key --data-file=- --replication-policy=automatic
# If the secret already exists, add a new version instead:
# $CLIENT_KEY | gcloud secrets versions add fcc-client-key --data-file=-

gcloud secrets add-iam-policy-binding fcc-client-key --member="serviceAccount:$API_SA" --role="roles/secretmanager.secretAccessor"

# IMPORTANT: before deploy, share the THREE Google Sheets as Viewer with $WORKER_SA.
# Run these commands from the FCC_Backend_v0_1/backend directory.

# Private worker
gcloud run deploy fcc-worker --source . --region=$REGION --no-allow-unauthenticated --service-account=$WORKER_SA --set-env-vars="FCC_ROLE=worker,FCC_ENV=prod,FCC_GCP_PROJECT=$PROJECT_ID,FCC_FIRESTORE_DATABASE=(default),FCC_SEASON=2026,FCC_TIMEZONE=America/Sao_Paulo,FCC_ENABLE_APP_CUTOVER=false"

# Read API. Public HTTP entrance but protected by X-FCC-Key for this personal-app phase.
gcloud run deploy fcc-api --source . --region=$REGION --allow-unauthenticated --service-account=$API_SA --set-env-vars="FCC_ROLE=api,FCC_ENV=prod,FCC_GCP_PROJECT=$PROJECT_ID,FCC_FIRESTORE_DATABASE=(default),FCC_SEASON=2026,FCC_TIMEZONE=America/Sao_Paulo,FCC_ENABLE_APP_CUTOVER=false" --set-secrets="FCC_CLIENT_KEY=fcc-client-key:latest"

$WORKER_URL = gcloud run services describe fcc-worker --region=$REGION --format="value(status.url)"
$API_URL = gcloud run services describe fcc-api --region=$REGION --format="value(status.url)"

# Allow Scheduler identity to invoke only the private worker
gcloud run services add-iam-policy-binding fcc-worker --region=$REGION --member="serviceAccount:$SCHEDULER_SA" --role="roles/run.invoker"

# Every 15 minutes. Cloud Scheduler authenticates to Cloud Run with OIDC.
gcloud scheduler jobs create http fcc-sync-15m --location=$REGION --schedule="*/15 * * * *" --time-zone="America/Sao_Paulo" --uri="$WORKER_URL/internal/sync" --http-method=POST --oidc-service-account-email=$SCHEDULER_SA --oidc-token-audience=$WORKER_URL

# Force first run
gcloud scheduler jobs run fcc-sync-15m --location=$REGION

Write-Host "Worker: $WORKER_URL"
Write-Host "API:    $API_URL"
Write-Host "Client key (store locally; do not commit): $CLIENT_KEY"
Write-Host "Test: Invoke-RestMethod -Headers @{'X-FCC-Key'='$CLIENT_KEY'} -Uri '$API_URL/v1/sources'"
