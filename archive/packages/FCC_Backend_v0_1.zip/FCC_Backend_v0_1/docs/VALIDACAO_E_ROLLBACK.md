# Validação e rollback

## Checklist das planilhas

Para cada uma das três fontes:

- `FCC_Automation_Status` existe e está escondida;
- último `Workflow=FULL` tem status `SUCCESS*`;
- Expected League ID = Actual League ID;
- a semana gravada é a semana NFL corrente;
- abas críticas têm dados;
- a W corrente existe em Weekly Results;
- o próximo gatilho está instalado.

## Checklist do backend shadow

- `fcc-worker /health`: OK;
- Scheduler consegue invocar worker via OIDC;
- `sync_runs` recebe uma entrada por ciclo;
- `league_state` mantém os três IDs internos corretos;
- `/v1/sources` apresenta três relógios coerentes;
- uma falha simulada não apaga o último snapshot válido;
- `/v1/app-payload` retorna CUTOVER_NOT_ENABLED enquanto estiver em shadow.

## Rollback imediato

### Planilhas

- Remova os gatilhos com `fccUninstallSleeperBackupAutomation()` ou `fccUninstallEspnBackupAutomation()`.
- O menu e as rotinas manuais originais continuam disponíveis.

### Backend

- Pause o Scheduler: `gcloud scheduler jobs pause fcc-sync-15m --location=southamerica-east1`.
- Não altere o endpoint do Android.
- Como o cutover está bloqueado, o app continua usando o caminho antigo.

## Sinais que bloqueiam o cutover

- qualquer League ID trocado;
- W atual diferente entre backend e planilha;
- atualização automática falhando em uma das fontes;
- diferença de roster/lineup sem explicação por horário de coleta;
- timestamp dizendo “recente” quando somente uma rotina parcial rodou;
- erro visual na Home, Fontes, Waivers ou Trades;
- backend exigindo alteração de CSS/layout para compensar dados incompatíveis.
