# FCC 7.x — implementação passo a passo

> Siga a ordem. Não aponte o Android para o backend antes da Fase 4.

# Fase 0 — backup antes de mexer

1. Faça uma cópia manual das três planilhas no Drive com sufixo `BACKUP_PRE_BACKEND_YYYYMMDD`.
2. Em cada projeto Apps Script, faça também uma cópia/export do código atual.
3. Não altere IDs das planilhas usadas pelo app.
4. Não recrie `FCC_SYNC_KEY`; a ponte v7.0.1 deve manter a mesma URL `/exec` e a mesma chave do deployment atual.

# Fase 1 — automatizar completamente as planilhas

## 1A. Sleeper PPR

Planilha esperada: `1-d2aBSrL2tsjpSuuIy3LjQPxro_acwKOKF78NTYXjqU`
League ID esperado: `1398756583143477248`

1. Abra a planilha > **Extensões > Apps Script**.
2. No código Sleeper atual, aplique o patch descrito em `apps_script/Sleeper_Trigger_Safety_Patch.md`. Alternativamente compare com `Sleeper_Data_Export_v8_FCC_AUTOMATION_PATCHED.gs`.
3. Crie um novo arquivo no projeto chamado `FCC_Backup_Automation.gs`.
4. Cole `apps_script/Sleeper_Backup_Automation_v1.gs`.
5. Salve.
6. Execute manualmente `fccInstallSleeperBackupAutomation` **uma vez**.
7. Autorize as permissões solicitadas.
8. A instalação executa um FULL imediatamente. Verifique a aba escondida `FCC_Automation_Status`:
   - Workflow = `FULL`
   - Status = `SUCCESS` ou `SUCCESS_WITH_WARNINGS`
   - Expected League ID = Actual League ID = `1398756583143477248`
   - Week = semana NFL atual.
9. Em **Triggers/Gatilhos**, confirme quatro `fccSleeperBackupFull` diários e um `fccSleeperBackupPlayers` semanal.

## 1B. Sleeper SNF

Repita o procedimento na planilha `1qOcny2uvcVow1U7r2oFcXyTM8WSxFlZi2SpgQBupT3g`.

Antes de instalar, confirme que `Info!B4` representa `SUNDAY NIGHT FUMBLE (2026)` e que o League ID resolvido é `1397017429250478080`.

A automação abortará se encontrar o ID da PPR dentro da SNF. Isso é intencional.

## 1C. ESPN

Planilha esperada: `1dMeAjhVJdB8uxyRrB3Zpel5sc8S1z3bTkt7H05zuK8E`
League ID esperado: `1088464775`

1. Abra **Extensões > Apps Script**.
2. Confirme que `ESPN_Data_Export_Extension.gs` está no projeto e que `refreshESPNDashboardData()` funciona manualmente.
3. Aplique `apps_script/ESPN_Trigger_Safety_Patch.md` (ou compare com `ESPN_Data_Export_Extension_FCC_AUTOMATION_PATCHED.gs`) para que o trigger execute sem toast visual.
4. Crie `FCC_Backup_Automation.gs` e cole `apps_script/ESPN_Backup_Automation_v1.gs`.
5. Execute `fccInstallEspnBackupAutomation` uma vez e autorize.
6. Confirme `FCC_Automation_Status` com `FULL / SUCCESS` e league ID correto.
7. Confirme quatro gatilhos diários.

## 1D. Cadência inicial

- Sleeper FULL: aproximadamente 00:20 / 06:20 / 12:20 / 18:20.
- Sleeper Players Database: quarta ~05:10.
- ESPN FULL: aproximadamente 00:35 / 06:35 / 12:35 / 18:35.

Apps Script usa janelas aproximadas para gatilhos baseados em tempo. O horário exato é registrado no log.

## 1E. Ponte atual e tela Fontes

1. Substitua o código do Web App atual por `Fantasy_Command_Center_Sync_API_v7_0_1_BACKEND_BRIDGE.gs`.
2. **Editar deployment existente**, criar nova versão e manter a mesma URL `/exec`.
3. Não execute novamente a geração da `FCC_SYNC_KEY`.
4. No próximo build Android use `Fantasy_Command_Center_2026_v7_0_BACKEND_PREP.html`.
5. A tela **Fontes** exibirá data+hora do último ciclo FULL válido. No futuro, a mesma linha comporta Provedor / Backend / Backup.

## 1F. Gate antes do backend

Deixe rodar por pelo menos 24 h e confirme que cada planilha recebeu ciclos automáticos sem intervenção.

Não prossiga se houver `FAILED`, troca de League ID ou ausência da semana atual em `Weekly Results` / `Data_Weekly_Results`.

# Fase 2 — criar infraestrutura Google Cloud (shadow)

Região recomendada: `southamerica-east1` para Cloud Run, Firestore e Scheduler.

## 2A. Pré-requisitos

1. Instale/atualize Google Cloud CLI.
2. Crie ou selecione um projeto Google Cloud com faturamento habilitado.
3. Faça login: `gcloud auth login`.
4. Defina o projeto: `gcloud config set project SEU_PROJECT_ID`.

## 2B. Ative APIs

Ative:

- Cloud Run
- Cloud Build
- Artifact Registry
- Firestore
- Cloud Scheduler
- Secret Manager
- Google Sheets API

Os comandos prontos para Windows estão em `docs/GCP_COMMANDS_WINDOWS.ps1`.

## 2C. Firestore

Crie o `(default)` em Native mode, Standard, `southamerica-east1`, com delete protection.

Não use uma região diferente sem motivo: manter compute + banco juntos reduz latência e simplifica residência dos dados.

## 2D. Contas de serviço

Crie três identidades:

- `fcc-worker`: escrita Firestore + leitura das planilhas compartilhadas;
- `fcc-api`: leitura Firestore + acesso ao Secret Manager para a client key;
- `fcc-scheduler`: somente invocar o worker privado.

## 2E. Compartilhe as planilhas com o worker

Descubra o e-mail da service account `fcc-worker@SEU_PROJECT_ID.iam.gserviceaccount.com`.

Compartilhe **as três planilhas como Leitor** com esse e-mail. Não dê Editor.

Isso é necessário para o worker ler `FCC_Automation_Status` e medir o freshness do backup.

# Fase 3 — deploy shadow

## 3A. Worker

Entre na pasta `backend/` e implante `fcc-worker` como **não autenticado = NÃO** (`--no-allow-unauthenticated`).

Defina `FCC_ROLE=worker`.

O worker consulta os provedores, grava Firestore e registra `sync_runs`.

## 3B. API

Implante o mesmo código como `fcc-api`, com `FCC_ROLE=api`.

Na v0.1:

- `/health` funciona;
- `/v1/sources` funciona;
- `/v1/leagues/{id}` serve para inspeção;
- `/v1/app-payload` permanece bloqueado porque `FCC_ENABLE_APP_CUTOVER=false`.

Isso é uma trava de segurança contra apontar o app para um contrato ainda não validado.

## 3C. Scheduler

Crie um job a cada 15 minutos chamando `POST /internal/sync` no worker com token OIDC da conta `fcc-scheduler`.

Depois execute o job manualmente uma vez e veja os logs do Cloud Run.

## 3D. Teste de saúde

Confirme no `/v1/sources` que cada liga possui:

- `providerUpdatedAt` recente;
- `backendUpdatedAt` recente;
- `sheetUpdatedAt` correspondente ao último FULL das planilhas;
- statuses OK.

Se `sheetUpdatedAt` ficar vazio, confirme o compartilhamento da planilha com o worker e a aba `FCC_Automation_Status`. Se `sheetStatus=UNSAFE_AFTER_FAILED_FULL`, corrija/rode novamente um FULL com sucesso antes de considerar a planilha um fallback.

# Fase 4 — homologação sem mexer na interface

Durante pelo menos uma rodada completa:

1. mantenha o Android usando o Sync API atual;
2. deixe o backend coletando em paralelo;
3. compare os dados por liga;
4. registre divergências;
5. corrija o normalizador no backend, nunca “compense” com CSS ou lógica visual.

Critérios mínimos estão em `docs/ARQUITETURA.md`.

# Fase 5 — cutover (NÃO fazer ainda)

Somente após a paridade:

1. finalizar o compatibility mapper do `/v1/app-payload` para reproduzir exatamente o contrato usado pela interface;
2. implementar no Android/HTML a cadeia:
   - backend;
   - fallback Sync API/Sheets;
   - cache local;
3. manter o layout e IDs DOM atuais;
4. habilitar `FCC_ENABLE_APP_CUTOVER=true` apenas depois dos testes;
5. gerar APK de homologação separado antes de atualizar o app principal.

# Rollback

Em qualquer problema no backend, **não há rollback visual** nesta fase: basta manter `FCC_ENABLE_APP_CUTOVER=false` e o Android continua no Sync API/Sheets.

Se um gatilho de planilha der problema, execute `fccUninstallSleeperBackupAutomation` ou `fccUninstallEspnBackupAutomation`; o código original e o refresh manual continuam disponíveis.
