/**
 * FCC 7.x — Automação de backup ESPN v1
 * Cole este arquivo NO MESMO projeto Apps Script que contém ESPN_Data_Export_Extension.gs.
 */
const FCC_ESPN_AUTO_VERSION = 'espn-backup-v1.1.0';
const FCC_ESPN_EXPECTED_SHEET = '1dMeAjhVJdB8uxyRrB3Zpel5sc8S1z3bTkt7H05zuK8E';
const FCC_ESPN_EXPECTED_LEAGUE = '1088464775';

function fccEspnStatusSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName('FCC_Automation_Status');
  if (!sh) {
    sh = ss.insertSheet('FCC_Automation_Status');
    sh.getRange(1,1,1,10).setValues([['Run ID','Version','Started At ISO','Finished At ISO','Status','Workflow','Expected League ID','Actual League ID','Week','Message']]);
    sh.setFrozenRows(1);
    sh.hideSheet();
  }
  return sh;
}
function fccEspnLog_(row) {
  const sh = fccEspnStatusSheet_(); sh.appendRow(row);
  if (sh.getLastRow() > 250) sh.deleteRows(2, sh.getLastRow() - 250);
}
function fccEspnValidate_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss.getId() !== FCC_ESPN_EXPECTED_SHEET) throw new Error('FCC_ESPN_WRONG_SPREADSHEET ' + ss.getId());
  const cfg = espnReadConfig_(ss);
  if (String(cfg.leagueId) !== FCC_ESPN_EXPECTED_LEAGUE) throw new Error('FCC_ESPN_LEAGUE_MISMATCH expected=' + FCC_ESPN_EXPECTED_LEAGUE + ' actual=' + cfg.leagueId);
  if (Number(cfg.season) !== 2026) throw new Error('FCC_ESPN_SEASON_MISMATCH expected=2026 actual=' + cfg.season);
  return cfg;
}

function fccEspnVerifyBackup_(week) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const checks = [
    ['Data_Rosters',2], ['Data_Roster_Summary',2], ['Data_Standings',2],
    ['Data_Weekly_Results',2], ['Data_Player_Results',2], ['Data_Free_Agents',2],
    ['Data_Schedule',2], ['Data_Settings',2], ['Data_Scoring',2], ['Data_Users',2],
    ['Data_Transactions',1], ['Data_Status',2]
  ];
  const problems=[], counts={};
  checks.forEach(item=>{
    const sh=ss.getSheetByName(item[0]);
    if(!sh){problems.push(item[0]+': aba ausente');return;}
    const rows=sh.getLastRow(); counts[item[0]]=rows;
    if(rows<item[1])problems.push(item[0]+': somente '+rows+' linha(s)');
  });
  const weekly=ss.getSheetByName('Data_Weekly_Results');
  if(weekly&&weekly.getLastRow()>=2){
    const v=weekly.getDataRange().getDisplayValues(), h=v[0].map(x=>String(x||'').trim()), ix=h.indexOf('Week');
    if(ix>=0&&!v.slice(1).some(r=>Number(r[ix])===Number(week)))problems.push('Data_Weekly_Results: W'+week+' ausente');
  }
  return {ok:problems.length===0,problems:problems,counts:counts};
}

function fccEspnBackupFull() {
  const started=new Date(), runId=Utilities.getUuid(), lock=LockService.getDocumentLock();
  if(!lock.tryLock(5000)){fccEspnLog_([runId,FCC_ESPN_AUTO_VERSION,started.toISOString(),new Date().toISOString(),'SKIPPED','FULL',FCC_ESPN_EXPECTED_LEAGUE,'','','Another run holds lock']);return;}
  let cfg=null, week='';
  try {
    cfg=fccEspnValidate_();
    refreshESPNDashboardData({showToast:false});
    const status=SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Data_Status');
    if(status){
      const values=status.getDataRange().getValues();
      for(let i=1;i<values.length;i++) if(String(values[i][0])==='Analysis Week') week=values[i][1];
    }
    const verify=fccEspnVerifyBackup_(week);
    if(!verify.ok)throw new Error('FCC_BACKUP_VERIFY_FAILED: '+verify.problems.join(' | '));
    const countMsg=Object.keys(verify.counts).map(k=>k+'='+verify.counts[k]).join(', ');
    fccEspnLog_([runId,FCC_ESPN_AUTO_VERSION,started.toISOString(),new Date().toISOString(),'SUCCESS','FULL',FCC_ESPN_EXPECTED_LEAGUE,cfg.leagueId,week,countMsg]);
  } catch(e) {
    fccEspnLog_([runId,FCC_ESPN_AUTO_VERSION,started.toISOString(),new Date().toISOString(),'FAILED','FULL',FCC_ESPN_EXPECTED_LEAGUE,cfg?cfg.leagueId:'',week,String(e)]);
    throw e;
  } finally { lock.releaseLock(); }
}
function fccInstallEspnBackupAutomation() {
  fccEspnValidate_();
  ScriptApp.getProjectTriggers().forEach(t=>{if(t.getHandlerFunction()==='fccEspnBackupFull')ScriptApp.deleteTrigger(t);});
  [0,6,12,18].forEach(h=>ScriptApp.newTrigger('fccEspnBackupFull').timeBased().atHour(h).nearMinute(35).everyDays(1).create());
  fccEspnStatusSheet_();
  fccEspnBackupFull();
}
function fccUninstallEspnBackupAutomation(){ScriptApp.getProjectTriggers().forEach(t=>{if(t.getHandlerFunction()==='fccEspnBackupFull')ScriptApp.deleteTrigger(t);});}
