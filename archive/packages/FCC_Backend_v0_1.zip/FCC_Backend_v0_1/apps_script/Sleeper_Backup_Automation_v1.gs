/**
 * FCC 7.x — Automação de backup Sleeper v1
 * Cole este arquivo NO MESMO projeto Apps Script da planilha Sleeper.
 * Não substitui o código original: chama as funções já existentes, sem UI.
 *
 * Configure UMA VEZ com fccInstallSleeperBackupAutomation().
 */
const FCC_AUTO_VERSION = 'sleeper-backup-v1.1.0';

function fccSleeperBackupConfig_() {
  const id = SpreadsheetApp.getActiveSpreadsheet().getId();
  const map = {
    '1-d2aBSrL2tsjpSuuIy3LjQPxro_acwKOKF78NTYXjqU': { leagueId:'1398756583143477248', label:'Paga PPR' },
    '1qOcny2uvcVow1U7r2oFcXyTM8WSxFlZi2SpgQBupT3g': { leagueId:'1397017429250478080', label:'SUNDAY NIGHT FUMBLE' }
  };
  const cfg = map[id];
  if (!cfg) throw new Error('FCC_AUTOMATION_UNRECOGNIZED_SHEET: ' + id);
  return Object.assign({spreadsheetId:id}, cfg);
}

function fccSleeperStateWeek_() {
  const r = UrlFetchApp.fetch('https://api.sleeper.app/v1/state/nfl', {muteHttpExceptions:true});
  if (r.getResponseCode() < 200 || r.getResponseCode() >= 300) throw new Error('Sleeper state HTTP ' + r.getResponseCode());
  const j = JSON.parse(r.getContentText());
  const w = Number(j.week || j.display_week || 0);
  if (!w || w < 1 || w > 18) throw new Error('Invalid Sleeper week: ' + w);
  return w;
}

function fccAutomationStatusSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName('FCC_Automation_Status');
  if (!sh) {
    sh = ss.insertSheet('FCC_Automation_Status');
    sh.getRange(1,1,1,10).setValues([['Run ID','Version','Started At ISO','Finished At ISO','Status','Workflow','Expected League ID','Actual League ID','Week','Message']]);
    sh.setFrozenRows(1);
    sh.hideSheet();
  }
  return sh;
}

function fccLogAutomation_(row) {
  const sh = fccAutomationStatusSheet_();
  sh.appendRow(row);
  if (sh.getLastRow() > 250) sh.deleteRows(2, sh.getLastRow() - 250);
}

function fccValidateSleeperIdentity_(cfg) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss.getId() !== cfg.spreadsheetId) throw new Error('Spreadsheet ID changed unexpectedly.');
  const actual = String(GetSelectedLeagueId() || '');
  if (actual !== String(cfg.leagueId)) {
    throw new Error('FCC_LEAGUE_MISMATCH expected=' + cfg.leagueId + ' actual=' + actual + '. Aborting before writes.');
  }
  return actual;
}


function fccVerifySleeperBackup_(week) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const checks = [
    ['Rosters', 2], ['Roster Summary', 2], ['Standings', 2],
    ['Weekly Results', 2], ['Player Results', 2], ['Free Agents', 2],
    ['Schedule', 2], ['Transactions', 1], ['Settings', 1], ['Users', 1]
  ];
  const problems = [], counts = {};
  checks.forEach(item => {
    const sh = ss.getSheetByName(item[0]);
    if (!sh) { problems.push(item[0] + ': aba ausente'); return; }
    const rows = sh.getLastRow(); counts[item[0]] = rows;
    if (rows < item[1]) problems.push(item[0] + ': somente ' + rows + ' linha(s)');
  });
  const weekly = ss.getSheetByName('Weekly Results');
  if (weekly && weekly.getLastRow() >= 2) {
    const values = weekly.getDataRange().getDisplayValues();
    const headers = values[0].map(v => String(v || '').trim());
    const wix = headers.indexOf('Week');
    if (wix >= 0) {
      const hasWeek = values.slice(1).some(r => Number(r[wix]) === Number(week));
      if (!hasWeek) problems.push('Weekly Results: W' + week + ' ainda não foi gravada');
    }
  }
  return {ok: problems.length === 0, problems: problems, counts: counts};
}

function fccSleeperBackupPlayers() {
  const started = new Date(), runId = Utilities.getUuid();
  let cfg = null, actual = '', week = '';
  try {
    cfg = fccSleeperBackupConfig_();
    actual = fccValidateSleeperIdentity_(cfg);
    week = fccSleeperStateWeek_();
    UpdatePlayers();
    SpreadsheetApp.flush();
    fccLogAutomation_([runId,FCC_AUTO_VERSION,started.toISOString(),new Date().toISOString(),'SUCCESS','PLAYERS',cfg.leagueId,actual,week,'Players Database refreshed']);
  } catch (e) {
    fccLogAutomation_([runId,FCC_AUTO_VERSION,started.toISOString(),new Date().toISOString(),'FAILED','PLAYERS',cfg ? cfg.leagueId : '',actual,week,String(e)]);
    throw e;
  }
}

function fccSleeperBackupFull() {
  const started = new Date();
  const runId = Utilities.getUuid();
  const lock = LockService.getDocumentLock();
  if (!lock.tryLock(5000)) {
    fccLogAutomation_([runId,FCC_AUTO_VERSION,started.toISOString(),new Date().toISOString(),'SKIPPED','FULL','','','', 'Another run holds the document lock']);
    return;
  }
  let cfg, actual='', week='';
  try {
    cfg = fccSleeperBackupConfig_();
    actual = fccValidateSleeperIdentity_(cfg);
    week = fccSleeperStateWeek_();
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const info = ss.getSheetByName('Info');
    if (!info) throw new Error('Info sheet missing');
    info.getRange('B2').setValue(2026);
    info.getRange('B3').setValue(week);
    SpreadsheetApp.flush();

    let errors = [];
    const e1 = RefreshLeagueSpecificData(cfg.leagueId, week) || [];
    errors = errors.concat(e1);
    const e2 = RefreshDerivedData(cfg.leagueId, week, {skipFinalDependentOutputs:true}) || [];
    errors = errors.concat(e2);

    const part2 = RefreshPlayerResultsManual(errors, {showCompletionAlert:false});
    if (part2 && part2.success === false) throw new Error('Player Results failed: ' + part2.error);
    if (part2 && part2.warnings) errors = errors.concat(part2.warnings);

    const rosters = RefreshCurrentRosters({showAlerts:false,useLock:false,skipSettingsUsersRefresh:true,workflowName:'FCC Auto Full Rosters'});
    if (rosters && rosters.success === false) errors.push('Rosters: ' + rosters.error);

    SpreadsheetApp.flush();
    const verify = fccVerifySleeperBackup_(week);
    if (!verify.ok) throw new Error('FCC_BACKUP_VERIFY_FAILED: ' + verify.problems.join(' | '));
    const status = errors.length ? 'SUCCESS_WITH_WARNINGS' : 'SUCCESS';
    const countMsg = Object.keys(verify.counts).map(k => k + '=' + verify.counts[k]).join(', ');
    const warningMsg = errors.length ? (' | warnings=' + errors.slice(0,6).join(' | ')) : '';
    fccLogAutomation_([runId,FCC_AUTO_VERSION,started.toISOString(),new Date().toISOString(),status,'FULL',cfg.leagueId,actual,week,countMsg + warningMsg]);
  } catch (e) {
    fccLogAutomation_([runId,FCC_AUTO_VERSION,started.toISOString(),new Date().toISOString(),'FAILED','FULL',cfg ? cfg.leagueId : '',actual,week,String(e)]);
    throw e;
  } finally {
    lock.releaseLock();
  }
}

function fccInstallSleeperBackupAutomation() {
  const cfg = fccSleeperBackupConfig_();
  fccValidateSleeperIdentity_(cfg);
  const handlers = new Set(['fccSleeperBackupFull','fccSleeperBackupPlayers']);
  ScriptApp.getProjectTriggers().forEach(t => { if (handlers.has(t.getHandlerFunction())) ScriptApp.deleteTrigger(t); });
  [0,6,12,18].forEach(h => ScriptApp.newTrigger('fccSleeperBackupFull').timeBased().atHour(h).nearMinute(20).everyDays(1).create());
  // Player metadata is large and does not need four daily downloads. Refresh once a week.
  ScriptApp.newTrigger('fccSleeperBackupPlayers').timeBased().onWeekDay(ScriptApp.WeekDay.WEDNESDAY).atHour(5).nearMinute(10).create();
  fccAutomationStatusSheet_();
  fccSleeperBackupFull();
}

function fccUninstallSleeperBackupAutomation() {
  ScriptApp.getProjectTriggers().forEach(t => { if (t.getHandlerFunction() === 'fccSleeperBackupFull' || t.getHandlerFunction() === 'fccSleeperBackupPlayers') ScriptApp.deleteTrigger(t); });
}
