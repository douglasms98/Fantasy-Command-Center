/**
 * =====================================================
 * CONSTANTS - Static configuration and definitions
 * =====================================================
 * This file contains static data definitions used across the application.
 */

/**
 * Get definitions for stat sorting and renaming
 * Based on scoring_settings.csv
 */
function getStatDefinitions() {
  return [
    {key: "pass_yd", label: "Passing Yards", position: "QB"},
    {key: "pass_td", label: "Passing TD", position: "QB"},
    {key: "pass_fd", label: "Passing 1st Down", position: "QB"},
    {key: "pass_2pt", label: "2-Pt Conversion", position: "QB"},
    {key: "pass_int", label: "Pass Intercepted", position: "QB"},
    {key: "pass_int_td", label: "Pick 6 Thrown", position: "QB"},
    {key: "pass_cmp", label: "Pass Completed", position: "QB"},
    {key: "pass_inc", label: "Incomplete Pass", position: "QB"},
    {key: "pass_att", label: "Pass Attempts", position: "QB"},
    {key: "pass_sack", label: "QB Sacked", position: "QB"},
    {key: "pass_cmp_40p", label: "40+ Yard Completion Bonus", position: "QB"},
    {key: "pass_td_40p", label: "40+ Yard Pass TD Bonus", position: "QB"},
    {key: "pass_td_50p", label: "50+ Yard Pass TD Bonus", position: "QB"},
    {key: "rush_yd", label: "Rushing Yards", position: "RB"},
    {key: "rush_td", label: "Rushing TD", position: "RB"},
    {key: "rush_fd", label: "Rushing 1st Down", position: "RB"},
    {key: "rush_2pt", label: "2-Pt Conversion", position: "RB"},
    {key: "rush_att", label: "Rush Attempts", position: "RB"},
    {key: "rush_40p", label: "40+ Yard Rush Bonus", position: "RB"},
    {key: "rush_td_40p", label: "40+ Yard Rush TD Bonus", position: "RB"},
    {key: "rush_td_50p", label: "50+ Yard Rush TD Bonus", position: "RB"},
    {key: "rec", label: "Reception", position: "WR"},
    {key: "rec_yd", label: "Receiving Yards", position: "WR"},
    {key: "rec_td", label: "Receiving TD", position: "WR"},
    {key: "rec_fd", label: "Receiving 1st Down", position: "WR"},
    {key: "rec_2pt", label: "2-Pt Conversion", position: "WR"},
    {key: "rec_0_4", label: "0-4 Yard Reception Bonus", position: "WR"},
    {key: "rec_5_9", label: "5-9 Yard Reception Bonus", position: "WR"},
    {key: "rec_10_19", label: "10-19 Yard Reception Bonus", position: "WR"},
    {key: "rec_20_29", label: "20-29 Yard Reception Bonus", position: "WR"},
    {key: "rec_30_39", label: "30-39 Yard Reception Bonus", position: "WR"},
    {key: "rec_40p", label: "40+ Yard Reception Bonus", position: "WR"},
    {key: "rec_td_40p", label: "40+ Yard Reception TD Bonus", position: "WR"},
    {key: "rec_td_50p", label: "50+ Yard Reception TD Bonus", position: "WR"},
    {key: "bonus_rec_rb", label: "Reception Bonus - RB", position: "WR"},
    {key: "bonus_rec_wr", label: "Reception Bonus - WR", position: "WR"},
    {key: "bonus_rec_te", label: "Reception Bonus - TE", position: "WR"},
    {key: "fgm", label: "FG Made", position: "K"},
    {key: "fgm_0_19", label: "FG Made (0-19 yards)", position: "K"},
    {key: "fgm_20_29", label: "FG Made (20-29 yards)", position: "K"},
    {key: "fgm_30_39", label: "FG Made (30-39 yards)", position: "K"},
    {key: "fgm_40_49", label: "FG Made (40-49 yards)", position: "K"},
    {key: "fgm_50_59", label: "FG Made (50-59 yards)", position: "K"},
    {key: "fgm_50p", label: "FG Made (50+ yards)", position: "K"},
    {key: "fgm_60p", label: "FG Made (60+ yards)", position: "K"},
    {key: "fgm_yds", label: "Points per FG yard", position: "K"},
    {key: "fgm_yds_over_30", label: "Points per FG yard over 30", position: "K"},
    {key: "xpm", label: "PAT Made", position: "K"},
    {key: "fgmiss", label: "FG Missed", position: "K"},
    {key: "fgmiss_0_19", label: "FG Missed (0-19 yards)", position: "K"},
    {key: "fgmiss_20_29", label: "FG Missed (20-29 yards)", position: "K"},
    {key: "fgmiss_30_39", label: "FG Missed (30-39 yards)", position: "K"},
    {key: "fgmiss_40_49", label: "FG Missed (40-49 yards)", position: "K"},
    {key: "fgmiss_50_59", label: "FG Missed (50-59 yards)", position: "K"},
    {key: "fgmiss_50p", label: "FG Missed (50+ yards)", position: "K"},
    {key: "fgmiss_60p", label: "FG Missed (60+ yards)", position: "K"},
    {key: "xpmiss", label: "PAT Missed", position: "K"},
    {key: "def_td", label: "Defense TD", position: "DEF"},
    {key: "pts_allow_0", label: "Points Allowed 0", position: "DEF"},
    {key: "pts_allow_1_6", label: "Points Allowed 1-6", position: "DEF"},
    {key: "pts_allow_7_13", label: "Points Allowed 7-13", position: "DEF"},
    {key: "pts_allow_14_20", label: "Points Allowed 14-20", position: "DEF"},
    {key: "pts_allow_21_27", label: "Points Allowed 21-27", position: "DEF"},
    {key: "pts_allow_28_34", label: "Points Allowed 28-34", position: "DEF"},
    {key: "pts_allow_35p", label: "Points Allowed 35+", position: "DEF"},
    {key: "pts_allow", label: "Points Per Point Allowed", position: "DEF"},
    {key: "yds_allow_0_100", label: "Less Than 100 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_100_199", label: "100-199 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_200_299", label: "200-299 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_300_349", label: "300-349 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_350_399", label: "350-399 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_400_449", label: "400-449 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_450_499", label: "450-499 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_500_549", label: "500-549 Total Yards Allowed", position: "DEF"},
    {key: "yds_allow_550p", label: "550+ Total Yards Allowed", position: "DEF"},
    {key: "yds_allow", label: "Points Per Yard Allowed", position: "DEF"},
    {key: "def_3_and_out", label: "3 and Out", position: "DEF"},
    {key: "def_4_and_stop", label: "4th Down Stop", position: "DEF"},
    {key: "qb_hit", label: "Hit on QB", position: "DEF"},
    {key: "sack", label: "Sacks", position: "DEF"},
    {key: "sack_yd", label: "Sack Yards", position: "DEF"},
    {key: "int", label: "Interceptions", position: "DEF"},
    {key: "int_ret_yd", label: "INT Return Yards", position: "DEF"},
    {key: "fum_rec", label: "Fumble Recovery", position: "DEF"},
    {key: "fum_ret_yd", label: "Fumble Return Yards", position: "DEF"},
    {key: "tkl_loss", label: "Tackle For Loss", position: "DEF"},
    {key: "tkl_ast", label: "Assisted Tackle", position: "DEF"},
    {key: "tkl_solo", label: "Solo Tackle", position: "DEF"},
    {key: "tkl", label: "Tackle", position: "DEF"},
    {key: "safe", label: "Safety", position: "DEF"},
    {key: "ff", label: "Forced Fumble", position: "DEF"},
    {key: "blk_kick", label: "Blocked Kick", position: "DEF"},
    {key: "def_forced_punts", label: "Forced Punt", position: "DEF"},
    {key: "def_pass_def", label: "Pass Defended", position: "DEF"},
    {key: "def_2pt", label: "2-Pt Conversion Returns", position: "DEF"},
    {key: "fg_ret_yd", label: "Missed FG Return Yards", position: "DEF"},
    {key: "blk_kick_ret_yd", label: "Blocked Kick Return Yards", position: "DEF"},
    {key: "def_st_td", label: "Special teams td", position: "DEF"},
    {key: "def_st_ff", label: "Special Teams Forced Fumble", position: "DEF"},
    {key: "def_st_fum_rec", label: "Special Teams Fumble Recovery", position: "DEF"},
    {key: "def_st_tkl_solo", label: "Special Teams Solo Tackle", position: "DEF"},
    {key: "def_pr_yd", label: "Punt Return Yards", position: "DEF"},
    {key: "def_kr_yd", label: "Kick Return Yards", position: "DEF"},
    {key: "st_td", label: "Special teams player TD", position: "MISC"},
    {key: "st_ff", label: "Special Teams Player Forced Fumble", position: "MISC"},
    {key: "st_fum_rec", label: "Special Teams Player Fumble Recovery", position: "MISC"},
    {key: "st_tkl_solo", label: "Special Teams Player Solo Tackle", position: "MISC"},
    {key: "pr_yd", label: "Player Punt Return Yards", position: "MISC"},
    {key: "kr_yd", label: "Player Kick Return Yards", position: "MISC"},
    {key: "fum", label: "Fumble", position: "ALL"},
    {key: "fum_lost", label: "Fumble Lost", position: "ALL"},
    {key: "fum_rec_td", label: "Fumble Recovery TD", position: "ALL"},
    {key: "bonus_rush_yd_100", label: "100-199 Yard Rushing Game", position: "BONUS"},
    {key: "bonus_rush_yd_200", label: "200+ Yard Rushing Game", position: "BONUS"},
    {key: "bonus_rec_yd_100", label: "100-199 Yard Receiving Game", position: "BONUS"},
    {key: "bonus_rec_yd_200", label: "200+ Yard Receiving Game", position: "BONUS"},
    {key: "bonus_pass_yd_300", label: "300-399 Yard Passing Game", position: "BONUS"},
    {key: "bonus_pass_yd_400", label: "400+ Yard Passing Game", position: "BONUS"},
    {key: "bonus_rush_rec_yd_100", label: "100-199 Combined Rush + Rec Yards", position: "BONUS"},
    {key: "bonus_rush_rec_yd_200", label: "200+ Combined Rush + Rec Yards", position: "BONUS"},
    {key: "bonus_pass_cmp_25", label: "25+ pass completions", position: "BONUS"},
    {key: "bonus_rush_att_20", label: "20+ carries", position: "BONUS"},
    {key: "bonus_fd_rb", label: "1st Down Bonus - RB", position: "BONUS"},
    {key: "bonus_fd_wr", label: "1st Down Bonus - WR", position: "BONUS"},
    {key: "bonus_fd_te", label: "1st Down Bonus - TE", position: "BONUS"},
    {key: "bonus_fd_qb", label: "1st Down Bonus - QB", position: "BONUS"},
    {key: "idp_def_td", label: "IDP TD", position: "IDP"},
    {key: "idp_sack", label: "Sack", position: "IDP"},
    {key: "idp_sack_yd", label: "Sack Yards", position: "IDP"},
    {key: "idp_qb_hit", label: "Hit on QB", position: "IDP"},
    {key: "idp_tkl", label: "Tackle", position: "IDP"},
    {key: "idp_tkl_loss", label: "Tackle For Loss", position: "IDP"},
    {key: "idp_blk_kick", label: "Blocked Punt, PAT or FG", position: "IDP"},
    {key: "idp_int", label: "Interception", position: "IDP"},
    {key: "idp_int_ret_yd", label: "INT Return Yards", position: "IDP"},
    {key: "idp_fum_rec", label: "Fumble Recovery", position: "IDP"},
    {key: "idp_fum_ret_yd", label: "Fumble Return Yards", position: "IDP"},
    {key: "idp_ff", label: "Forced Fumble", position: "IDP"},
    {key: "idp_safe", label: "Safety", position: "IDP"},
    {key: "idp_tkl_ast", label: "Assisted Tackle", position: "IDP"},
    {key: "idp_tkl_solo", label: "Solo Tackle", position: "IDP"},
    {key: "idp_pass_def", label: "Pass Defended", position: "IDP"},
    {key: "bonus_tkl_10p", label: "10+ Tackle Bonus", position: "IDP"},
    {key: "bonus_sack_2p", label: "2+ Sack Bonus", position: "IDP"},
    {key: "idp_pass_def_3p", label: "3+ Pass Defended Bonus", position: "IDP"},
    {key: "bonus_def_int_td_50p", label: "50+ Yard Interception Return TD Bonus", position: "IDP"},
    {key: "bonus_def_fum_td_50p", label: "50+ Yard Fumble Return TD Bonus", position: "IDP"}
  ];
}

/**
 * =====================================================
 * UTILITIES - Helper Functions
 * =====================================================
 * General utility functions for parsing, sheet management,
 * player database updates, and other support operations.
 */

/**
 * Script to import Sleeper's Player Database
 * Sleeper API supporting documentation found at https://docs.sleeper.app/
 * Run Script sparingly as it is a larger file size and data does not change often!! 
 */
function UpdatePlayers() {

  // call to sleeper's Players API -  

  var json = fetchSleeperJson("https://api.sleeper.app/v1/players/nfl", {
    workflow: "Update Players Database"
  });

  // API returns a nested json w/ each player id as key
  // loop through each player to create multi-array

  // create empty array
  var keys = []
  // loop using player ID for each array
  for (var key in json) {
    var arr = [key,
      json[key]["player_id"],
      json[key]["position"],
      json[key]["fantasy_positions"],
      json[key]["depth_chart_position"],
      json[key]["first_name"],
      json[key]["last_name"],
      String(json[key]["full_name"] || "").trim() ||
      (
       String(json[key]["first_name"] || "").trim() + " " +
       String(json[key]["last_name"] || "").trim()
      ).trim(),
      json[key]["team"],
      json[key]["years_exp"],
      json[key]["birth_date"],
      json[key]["height"],
      json[key]["weight"],
      json[key]["injury_status"],
      json[key]["injury_body_part"],
      json[key]["injury_notes"]
    ]
    // push results from loop into empty array
    keys.push(arr);
  }

  /* Set Script to retrieve "Players Database" Sheet. 
   * Clear "Players Database" sheet
   * retreive range (2nd row, 1st column, # of keys (player ids), 16 (# of columns of data in our array)
   * set values from array to retreived range
   */

  var ss = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Players Database");
  var headers = ss.getRange('B1:P1').getValues();
  ss.clear();
  ss.getRange('B1:P1').setValues(headers);
  ss.getRange(2, 1, keys.length, 16).setValues(keys);
}

/**
 * Helper function to prevent scientific notation for large numbers
 * Converts large numbers to strings with a leading apostrophe
 */
function preventScientificNotation(data) {
  return data.map(function (row) {
    return row.map(function (cell) {
      // Check if it's a number or string that looks like a large number
      if (cell !== null && cell !== undefined) {
        var cellStr = cell.toString();
        // If it's a large number or an ID-like string
        if ((typeof cell === 'number' && cellStr.length > 11) ||
          (typeof cell === 'string' && cellStr.match(/^\d{12,}$/))) {
          return "'" + cellStr;  // Leading apostrophe forces text format
        }
      }
      return cell;
    });
  });
}

/**
 * Parse JSON with special handling for large numbers to prevent precision loss
 * Uses a custom JSON parser that preserves large numbers as strings
 */
function parseJSONSafely(jsonText) {
  try {
    // For player IDs and other large numbers, we need to modify the JSON text
    // before parsing to ensure they're treated as strings

    // Log sample for debugging
    Logger.log("JSON sample before processing: " + jsonText.substring(0, 300));

    // Method 1: Pre-process the JSON to quote large numbers
    var processedJson = jsonText;

    // Handle arrays of numbers (like player IDs)
    // This regex finds arrays that contain numbers
    processedJson = processedJson.replace(/"(players|starters|taxi|reserve|keepers)":\s*\[([^\]]+)\]/g, function (match, field, arrayContent) {
      // Process each element in the array
      var elements = arrayContent.split(',').map(function (element) {
        var trimmed = element.trim();

        // If it's a number (not already quoted)
        if (/^\d+$/.test(trimmed)) {
          // Always quote it to preserve as string
          return '"' + trimmed + '"';
        }
        return element;
      });

      return '"' + field + '":[' + elements.join(',') + ']';
    });

    // Handle individual large numbers (IDs not in arrays)
    // Match patterns like "user_id":123456789012345
    processedJson = processedJson.replace(/"(\w*_?id\w*)":\s*(\d{10,})([,\s\}])/gi, '"$1":"$2"$3');

    // Handle any remaining large numbers
    processedJson = processedJson.replace(/:(\s*)(\d{15,})([,\s\}])/g, ':"$2"$3');

    // Log sample after processing
    Logger.log("JSON sample after processing: " + processedJson.substring(0, 300));

    return JSON.parse(processedJson);

  } catch (error) {
    Logger.log("Error in parseJSONSafely: " + error.toString());
    Logger.log("Falling back to standard JSON.parse");

    // If our processing breaks the JSON, fall back to standard parsing
    // This is better than failing completely
    try {
      return JSON.parse(jsonText);
    } catch (parseError) {
      throw new Error("Failed to parse JSON: " + parseError.toString());
    }
  }
}

/**
 * Centralized Sleeper API fetch helper.
 * Keeps response-code handling, JSON parsing, and diagnostics consistent.
 *
 * @param {string} url - Full Sleeper API URL.
 * @param {Object=} options - Optional behavior overrides.
 * @return {*} Parsed JSON response.
 */
function fetchSleeperJson(url, options) {
  options = options || {};
  var workflow = options.workflow || "Sleeper API";
  var fetchOptions = options.fetchOptions || {};

  if (fetchOptions.muteHttpExceptions === undefined) {
    fetchOptions.muteHttpExceptions = true;
  }

  try {
    Logger.log(workflow + ": Fetching " + url);
    var response = UrlFetchApp.fetch(url, fetchOptions);
    var responseCode = response.getResponseCode ? response.getResponseCode() : 200;
    var responseText = response.getContentText();

    if (responseCode < 200 || responseCode >= 300) {
      var bodyPreview = responseText ? responseText.substring(0, 300) : "(empty response)";
      var message = options.errorMessage || ("Sleeper API returned HTTP " + responseCode);
      var errorText = message + " for " + url + ". Response: " + bodyPreview;
      recordDiagnostics(workflow, "API Error", null, null, errorText, options.leagueId || "");
      throw new Error(errorText);
    }

    if (!responseText) {
      if (options.allowEmpty) return null;
      throw new Error("Sleeper API returned an empty response for " + url);
    }

    return options.preserveLargeNumbers ? parseJSONSafely(responseText) : JSON.parse(responseText);

  } catch (error) {
    if (options.logFailure !== false) {
      Logger.log(workflow + ": " + error.toString());
    }
    throw error;
  }
}

/**
 * Centralized rate-limit pause wrapper.
 * @param {number=} ms - Milliseconds to sleep.
 */
function sleepForSleeperRateLimit(ms) {
  Utilities.sleep(ms === undefined || ms === null ? 100 : ms);
}

/**
 * Ensure Diagnostics sheet exists with the expected header row.
 * @return {GoogleAppsScript.Spreadsheet.Sheet|null}
 */
function getDiagnosticsSheet() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName("Diagnostics");
    var headers = [
      "Run Timestamp", "Workflow", "Username", "Year", "Through Week",
      "League ID", "Status", "Duration Seconds", "Warnings", "Errors"
    ];

    if (!sheet) {
      sheet = ss.insertSheet("Diagnostics");
      sheet.hideSheet();
    }

    if (sheet.getLastRow() === 0 || sheet.getRange(1, 1).getValue() !== headers[0]) {
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold");
      sheet.setFrozenRows(1);
    }

    return sheet;
  } catch (error) {
    Logger.log("Diagnostics unavailable: " + error.toString());
    return null;
  }
}

/**
 * Append a refresh diagnostic row without interrupting the user workflow.
 */
function recordDiagnostics(workflow, status, startTime, warnings, errors, leagueId) {
  try {
    var sheet = getDiagnosticsSheet();
    if (!sheet) return;

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var username = "";
    var year = "";
    var throughWeek = "";

    if (infoSheet) {
      username = infoSheet.getRange("B1").getValue();
      year = infoSheet.getRange("B2").getValue();
      throughWeek = infoSheet.getRange("B3").getValue();
    }

    var duration = "";
    if (startTime) {
      duration = Math.round(((new Date()) - startTime) / 100) / 10;
    }

    var warningText = Array.isArray(warnings) ? warnings.join("\n") : (warnings || "");
    var errorText = Array.isArray(errors) ? errors.join("\n") : (errors || "");

    sheet.appendRow([
      new Date(),
      workflow,
      username,
      year,
      throughWeek,
      leagueId || "",
      status,
      duration,
      warningText,
      errorText
    ]);
  } catch (error) {
    Logger.log("Could not record diagnostics: " + error.toString());
  }
}

/**
 * Ensure a sheet is large enough before writing a range.
 * Apps Script cannot getRange() outside the current grid dimensions.
 */
function ensureSheetSize(sheet, minRows, minCols) {
  if (!sheet) return;

  minRows = Math.max(1, minRows || 1);
  minCols = Math.max(1, minCols || 1);

  var currentRows = sheet.getMaxRows();
  var currentCols = sheet.getMaxColumns();

  if (currentRows < minRows) {
    sheet.insertRowsAfter(currentRows, minRows - currentRows);
  }

  if (currentCols < minCols) {
    sheet.insertColumnsAfter(currentCols, minCols - currentCols);
  }
}

/**
 * Auto-fit populated columns on a sheet, similar to selecting all columns and double-clicking a separator.
 */
function autoResizeUsedColumns(sheet) {
  try {
    if (!sheet) return;

    var lastCol = sheet.getLastColumn();
    if (lastCol > 0) {
      sheet.autoResizeColumns(1, lastCol);
    }
  } catch (error) {
    Logger.log("Could not auto-resize columns for " + (sheet ? sheet.getName() : "unknown sheet") + ": " + error.toString());
  }
}

/**
 * Auto-fit visible generated output sheets after refreshes finish.
 */
function autoResizeGeneratedOutputSheets(sheetNames) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  sheetNames = sheetNames || [
    "Roster Summary", "Rosters", "Current Rosters", "Standings", "Weekly Results", "Player Results",
    "Awards", "Playoffs", "Transactions", "Free Agents", "Schedule", "Owned Draft Picks", "Draft Result"
  ];

  sheetNames.forEach(function(sheetName) {
    autoResizeUsedColumns(ss.getSheetByName(sheetName));
  });
}

/**
 * Prevent overlapping long-running refresh workflows in the same workbook.
 */
function acquireWorkflowLock(workflowName) {
  var lock = LockService.getDocumentLock();
  if (!lock.tryLock(1000)) {
    SpreadsheetApp.getUi().alert(
      'Refresh already running',
      'Another Sleeper refresh is still running for this workbook. Please wait for the running script banner to disappear, then try again.',
      SpreadsheetApp.getUi().ButtonSet.OK
    );
    recordDiagnostics(workflowName, "Skipped - Already Running");
    return null;
  }
  return lock;
}

/**
 * Helper function to parse JSON data similar to ImportJSON
 */
function parseJSONData(data, query, options) {
  var headers = {};
  var rows = [];

  // Parse options
  var optionsArray = options ? options.split(",") : [];
  var useRawHeaders = optionsArray.includes("rawHeaders");
  var noInherit = optionsArray.includes("noInherit");
  var noTruncate = optionsArray.includes("noTruncate");

  // Parse query
  var queryArray = [];
  if (query) {
    if (Array.isArray(query)) {
      queryArray = query;
    } else if (query.includes(",")) {
      queryArray = query.split(",");
    } else if (query) {
      queryArray = [query];
    }
  }

  // Recursive function to flatten JSON
  function parseObject(obj, path, rowIndex) {
    if (obj === null || obj === undefined) {
      return rowIndex;
    }

    if (Array.isArray(obj)) {
      if (obj.length === 0) {
        return rowIndex;
      }

      // Check if it's an array of objects
      var isObjectArray = obj.some(item => typeof item === 'object' && item !== null && !Array.isArray(item));

      if (isObjectArray) {
        for (var i = 0; i < obj.length; i++) {
          rowIndex = parseObject(obj[i], path, rowIndex);
          if (i < obj.length - 1) rowIndex++;
        }
      } else {
        // Array of primitives - handle special cases for player IDs
        var isPlayerArray = path.toLowerCase().includes('player') ||
          path.toLowerCase().includes('starter') ||
          path.toLowerCase().includes('taxi') ||
          path.toLowerCase().includes('reserve') ||
          path === '/starters' ||
          path === '/players' ||
          path === '/taxi' ||
          path === '/reserve' ||
          path === '/keepers';

        if (isPlayerArray) {
          // For player arrays, ensure each ID is properly formatted
          var formattedArray = obj.map(function (item) {
            if (item !== null && item !== undefined) {
              var itemStr = item.toString();
              // Always preserve player IDs as strings
              return itemStr;
            }
            return "";
          });

          // Join with commas and add leading apostrophe to force text format
          var joinedValue = formattedArray.filter(function (id) { return id !== ""; }).join(",");
          if (joinedValue) {
            addValue(path, "'" + joinedValue, rowIndex);
          } else {
            addValue(path, "", rowIndex);
          }
        } else {
          // Regular array - join normally
          addValue(path, obj.join(","), rowIndex);
        }
      }
    } else if (typeof obj === 'object') {
      var hasData = false;
      for (var key in obj) {
        var newPath = path ? path + "/" + key : "/" + key;

        // Check if we should include this path
        if (queryArray.length === 0 || shouldIncludePath(newPath, queryArray)) {
          var newRowIndex = parseObject(obj[key], newPath, rowIndex);
          if (newRowIndex > rowIndex) hasData = true;
        }
      }
      if (!hasData) {
        // Empty object - ensure we have a row
        if (!rows[rowIndex]) rows[rowIndex] = [];
      }
    } else {
      // Primitive value
      addValue(path, obj, rowIndex);
    }

    return rowIndex;
  }

  function shouldIncludePath(path, queries) {
    if (queries.length === 0) return true;
    return queries.some(q => path.indexOf(q) === 0);
  }

  function addValue(path, value, rowIndex) {
    if (!headers.hasOwnProperty(path)) {
      headers[path] = Object.keys(headers).length;
    }

    if (!rows[rowIndex]) {
      rows[rowIndex] = [];
    }

    // Handle various ID fields and large numbers to prevent scientific notation
    if (value !== null && value !== undefined) {
      var valueStr = value.toString();

      // Check if it's a numeric ID field (by path name or value characteristics)
      var isIdField = path.toLowerCase().includes('_id') ||
        path.toLowerCase().includes('id') ||
        path === '/league_id' ||
        path === '/user_id' ||
        path === '/roster_id' ||
        path === '/owner_id' ||
        path === '/player_id';

      // If it's an ID field or a large number, force it to be a string
      if (isIdField ||
        (typeof value === 'number' && valueStr.length > 11) ||
        (typeof value === 'string' && valueStr.match(/^\d{12,}$/))) {
        value = "'" + valueStr;  // Leading apostrophe forces text format in Sheets
      }
    }

    // Truncate if needed
    if (!noTruncate && value && value.toString().length > 256) {
      value = value.toString().substring(0, 256);
    }

    rows[rowIndex][headers[path]] = value;
  }

  // Parse the data
  if (Array.isArray(data)) {
    var currentRow = 0;
    for (var i = 0; i < data.length; i++) {
      currentRow = parseObject(data[i], "", currentRow);
      if (i < data.length - 1) currentRow++;
    }
  } else {
    parseObject(data, "", 0);
  }

  // Convert headers object to array
  var headerArray = [];
  for (var path in headers) {
    if (!useRawHeaders) {
      // Clean up headers
      var cleanPath = path.substring(1); // Remove leading /
      cleanPath = cleanPath.replace(/[/_]/g, " ");
      cleanPath = toTitleCase(cleanPath);
    } else {
      cleanPath = path;
    }
    headerArray[headers[path]] = cleanPath;
  }

  // Build final result
  var result = [headerArray];

  // Add data rows
  for (var i = 0; i < rows.length; i++) {
    var row = [];
    for (var j = 0; j < headerArray.length; j++) {
      if (rows[i] && rows[i][j] !== undefined) {
        row[j] = rows[i][j];
      } else if (!noInherit && i > 0 && result[i] && result[i][j] !== undefined) {
        // Inherit from previous row
        row[j] = result[i][j];
      } else {
        row[j] = "";
      }
    }
    result.push(row);
  }

  return result;
}

function toTitleCase(text) {
  return text.replace(/\w\S*/g, function (txt) {
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
  });
}

/**
 * Helper function to clear all output sheets
 * Used by Step 1 and Step 2 to ensure clean state
 */
function ClearAllOutputSheets() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheets = [
    "Roster Summary", "Rosters", "Current Rosters", "Schedule", "Transactions", "Standings", "Weekly Results",
    "Draft Result", "Playoffs", "Awards", "Player Results", "Owned Draft Picks", "Users", "Free Agents"
    // NOTE: "Balance" sheet is intentionally excluded
  ];

  sheets.forEach(function (name) {
    try {
      var sheet = ss.getSheetByName(name);
      if (sheet) {
        if (name === "Schedule") {
          // Clear schedule grid
          sheet.getRange("B2:S33").clearContent();
        } else if (name === "Transactions") {
          // Preserve headers, only clear columns A:I (1-9) to preserve user notes
          var lastRow = sheet.getLastRow();
          if (lastRow > 1) {
            sheet.getRange(2, 1, lastRow - 1, 9).clearContent();
          }
        } else if (name === "Users") {
          // Clear rows 1-35 only (preserve data below row 35)
          sheet.getRange("1:35").clearContent();
        } else {
          // Full clear for others (headers are rebuilt by script)
          sheet.clear();
        }
        Logger.log("Cleared " + name);
      }
    } catch (e) {
      Logger.log("Error clearing " + name + ": " + e.toString());
    }
  });

  // Clear Week sheets and Week Data sheets
  for (var i = 1; i <= 18; i++) {
    try {
      // Clear Week X Data sheet (full clear)
      var weekDataSheet = ss.getSheetByName("Week " + i + " Data");
      if (weekDataSheet) weekDataSheet.clear();

      // Clear Week X sheet (partial clear to preserve formulas in 69-169)
      var weekSheet = ss.getSheetByName("Week " + i);
      if (weekSheet) {
        weekSheet.getRange("1:68").clearContent();
        var maxRows = weekSheet.getMaxRows();
        if (maxRows >= 170) {
          weekSheet.getRange("170:" + maxRows).clearContent();
        }
        Logger.log("Cleared Week " + i + " (preserving rows 69-169)");
      }
    } catch (e) {
      Logger.log("Error clearing week " + i + " sheets: " + e.toString());
    }
  }
}

/**
 * Trim all sheets to used range + 1 row/col buffer
 */
function TrimAllSheets() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheets = ss.getSheets();

  sheets.forEach(function (sheet) {
    TrimSheet(sheet);
  });
}

/**
 * Trim a specific sheet to used range + 1 row/col buffer
 * Preserves specific rows for Week sheets
 */
function TrimSheet(sheet) {
  try {
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    var maxRows = sheet.getMaxRows();
    var maxCols = sheet.getMaxColumns();

    // Safety check for Week sheets (Week 1, Week 2, etc. but not Week 1 Data)
    // These sheets have a fixed structure with matchup tables at row 171+
    if (sheet.getName().match(/^Week \d+$/)) {
      // Ensure we keep at least 205 rows for the fixed structure
      if (lastRow < 205) lastRow = 205;
    }

    // Add buffer of 1 row and 1 column
    lastRow += 1;
    lastCol += 1;

    // Trim rows
    if (maxRows > lastRow) {
      sheet.deleteRows(lastRow + 1, maxRows - lastRow);
    }

    // Trim columns
    if (maxCols > lastCol) {
      sheet.deleteColumns(lastCol + 1, maxCols - lastCol);
    }
  } catch (e) {
    Logger.log("Error trimming sheet " + sheet.getName() + ": " + e.toString());
  }
}

/**
 * Build only the essential derived tables from API matchup data
 * This saves 99% of cell usage vs writing full expanded API data
 *
 * Week sheet structure:
 * - Row 1-33: Sleeper matchup data (Roster, Roster_ID, /players, /starters, individual player IDs)
 * - Row 35-67: Points per player
 * - Row 69-101: Starters with positions (formula-driven, NOT written by this function)
 * - Row 103-135: Bench players (formula-driven, NOT written by this function)
 * - Row 137-169: Player positions (formula-driven, NOT written by this function)
 * - Row 171-203: Team/Matchup data (Team Name, Roster ID, Matchup ID)
 */
function buildDerivedWeeklyTables(weekSheet, matchupData, week, userLookup) {
  // matchupData is array of matchup objects from Sleeper API
  // Each object has: roster_id, matchup_id, points, starters, players, players_points

  // Find max number of players across all rosters to determine column count
  var maxPlayers = 0;
  matchupData.forEach(function (matchup) {
    if (matchup.players && matchup.players.length > maxPlayers) {
      maxPlayers = matchup.players.length;
    }
  });

  // Build Table 1 (Row 1-33): Roster, Roster ID, /players, /starters, Player IDs...
  // Row 1 = header, Row 2-33 = data (up to 32 teams)
  var table1 = [["Roster", "Roster_ID", "/players", "/starters"]];

  // Add headers for individual player columns
  for (var i = 1; i <= maxPlayers; i++) {
    table1[0].push("Player " + i);
  }

  // Build Table 2 (Row 35-67): Points, Roster_ID, [blank], [blank], Points per player...
  var table2 = [["Points", "roster_id", "", ""]]; // Headers
  for (var i = 1; i <= maxPlayers; i++) {
    table2[0].push("Points " + i);
  }

  // Build Table 3 (Row 171-203): Team Name, Roster ID, Matchup ID
  var table3 = [["Team Name", "Roster ID", "Matchup ID"]];

  // Process each matchup (team)
  matchupData.forEach(function (matchup) {
    var rosterId = matchup.roster_id || "";
    var matchupId = matchup.matchup_id || "";

    // Robust team name lookup with fallback
    var lookupName = userLookup[rosterId.toString()];
    // Use lookup if it exists and is not just whitespace, otherwise fallback to "Team ID"
    var teamName = (lookupName && lookupName.toString().trim() !== "") ? lookupName : ("Team " + rosterId);

    // Get arrays
    var players = matchup.players || [];
    var starters = matchup.starters || [];
    var playersPoints = matchup.players_points || {};

    // Build comma-separated lists for /players and /starters
    // Add leading apostrophe to force text formatting (prevents scientific notation)
    var playersCommaList = "'" + players.join(",");
    var startersCommaList = "'" + starters.join(",");

    // Build Table 1 row: Roster, Roster ID, /players, /starters, individual player IDs...
    var table1Row = [teamName, rosterId, playersCommaList, startersCommaList];
    players.forEach(function (playerId) {
      table1Row.push(playerId);
    });
    // Pad to maxPlayers columns (4 metadata columns + maxPlayers)
    while (table1Row.length < table1[0].length) {
      table1Row.push("");
    }
    table1.push(table1Row);

    // Build Table 2 row: team name, roster_id, [blank], [blank], points per player...
    var table2Row = [teamName, rosterId, "", ""];
    players.forEach(function (playerId) {
      var points = playersPoints[playerId];
      if (points === null || points === undefined || points === "") {
        table2Row.push(0); // Default to 0 for missing points
      } else {
        table2Row.push(points);
      }
    });
    // Pad to maxPlayers columns
    while (table2Row.length < table2[0].length) {
      table2Row.push("");
    }
    table2.push(table2Row);

    // Build Table 3 row: Team Name, Roster ID, Matchup ID
    table3.push([teamName, rosterId, matchupId]);
  });

  ensureSheetSize(weekSheet, 203, Math.max(table1[0].length, table2[0].length, table3[0].length));

  // Write tables to Week sheet
  // Table 1: Row 1-33 (header at 1, data at 2-33)
  if (table1.length > 0) {
    weekSheet.getRange(1, 1, table1.length, table1[0].length).setValues(table1);
    weekSheet.getRange(1, 1, 1, table1[0].length).setFontWeight("bold"); // Bold header
  }

  // Table 2: Row 35-67 (header at 35, data at 36-67)
  if (table2.length > 0) {
    weekSheet.getRange(35, 1, table2.length, table2[0].length).setValues(table2);
    weekSheet.getRange(35, 1, 1, table2[0].length).setFontWeight("bold"); // Bold header
  }

  // Table 3: Row 171-203 (header at 171, data at 172-203)
  if (table3.length > 0) {
    weekSheet.getRange(171, 1, table3.length, table3[0].length).setValues(table3);
    weekSheet.getRange(171, 1, 1, table3[0].length).setFontWeight("bold"); // Bold header
  }

  // Rows 69-169 are left empty for user's formula-driven tables
  // These formulas will reference the /players and /starters columns from Table 1

  Logger.log("Week " + week + ": Built derived tables - " + (table1.length - 1) + " teams, " + maxPlayers + " max players per team");
}

/**
 * =====================================================
 * LOOKUPS - Lookup Table Functions
 * =====================================================
 * Functions for building lookup tables from various data
 * sources: users, players, scoring stats, projections, etc.
 */

/**
 * Build a lookup object mapping roster_id to display name
 * Based on Info!B5 setting, returns either usernames or team names
 * @return {Object} - Object mapping roster_id to display name
 */
function buildUserLookup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var infoSheet = ss.getSheetByName("Info");
  var userSheet = ss.getSheetByName("Users");

  // Get display preference from Info!B5 (default to "Usernames" if not set)
  var displayPref = infoSheet.getRange("B5").getValue() || "Usernames";
  var useTeamNames = (displayPref === "Team Names");

  // The Users sheet has:
  // 1. Raw API data in rows 1-35 with headers in row 1 (contains /metadata/team_name, /user_id, /display_name)
  // 2. Derived table in rows 72-104, columns A-C: user_id, roster_id, display_name

  // Get the derived table data (rows 73-104, columns A-C: user_id, roster_id, display_name)
  // Row 72 has headers: user_id, roster_id, display_name
  var derivedData = userSheet.getRange("A73:C104").getValues();

  // Build basic roster_id -> username lookup from derived table
  var rosterToUsername = {};
  var rosterToUserId = {};
  derivedData.forEach(function(row) {
    var userId = row[0];
    var rosterId = row[1];
    var username = row[2];
    if (rosterId && username) {
      rosterToUsername[rosterId.toString()] = username;
      rosterToUserId[rosterId.toString()] = userId ? userId.toString() : "";
    }
  });

  // If not using team names, just return the username lookup
  if (!useTeamNames) {
    return rosterToUsername;
  }

  // For team names, we need to look up from the raw API data section
  // Find the column indices in row 1 (API headers)
  var headerRow = userSheet.getRange("1:1").getValues()[0];

  var userIdCol = -1;
  var teamNameCol = -1;

  for (var i = 0; i < headerRow.length; i++) {
    var header = headerRow[i].toString();
    if (header === "/user_id") {
      userIdCol = i;
    } else if (header === "/metadata/team_name") {
      teamNameCol = i;
    }
  }

  Logger.log("buildUserLookup: useTeamNames=" + useTeamNames + ", userIdCol=" + userIdCol + ", teamNameCol=" + teamNameCol);

  // If we can't find team_name column, fall back to usernames
  if (teamNameCol === -1 || userIdCol === -1) {
    Logger.log("buildUserLookup: Could not find required columns, falling back to usernames");
    return rosterToUsername;
  }

  // Get raw API data (rows 2-35, up to 34 users) to build user_id -> team_name lookup
  var rawData = userSheet.getRange(2, 1, 34, Math.max(userIdCol, teamNameCol) + 1).getValues();

  var userIdToTeamName = {};
  rawData.forEach(function(row) {
    var userId = row[userIdCol];
    var teamName = row[teamNameCol];
    if (userId && teamName) {
      userIdToTeamName[userId.toString()] = teamName;
    }
  });

  Logger.log("buildUserLookup: Found " + Object.keys(userIdToTeamName).length + " team names");

  // Build final roster_id -> display lookup
  var userLookup = {};
  Object.keys(rosterToUsername).forEach(function(rosterId) {
    var userId = rosterToUserId[rosterId];
    var teamName = userId ? userIdToTeamName[userId] : null;

    if (teamName) {
      userLookup[rosterId] = teamName;
    } else {
      // Fall back to username if no team name
      userLookup[rosterId] = rosterToUsername[rosterId];
    }
  });

  return userLookup;
}

/**
 * Build a lookup object that translates usernames to preferred display names
 * Used by functions that read data with usernames already embedded (like Player Results)
 * @return {Object} - Object mapping username to preferred display name
 */
function buildUsernameToDisplayLookup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var infoSheet = ss.getSheetByName("Info");
  var userSheet = ss.getSheetByName("Users");

  // Get display preference from Info!B5 (default to "Usernames" if not set)
  var displayPref = infoSheet.getRange("B5").getValue() || "Usernames";
  var useTeamNames = (displayPref === "Team Names");

  // If using usernames, no translation needed - return empty object
  if (!useTeamNames) {
    return {};
  }

  // Find the column indices in row 1 (API headers)
  var headerRow = userSheet.getRange("1:1").getValues()[0];

  var userIdCol = -1;
  var displayNameCol = -1;
  var teamNameCol = -1;

  for (var i = 0; i < headerRow.length; i++) {
    var header = headerRow[i].toString();
    if (header === "/user_id") {
      userIdCol = i;
    } else if (header === "/display_name") {
      displayNameCol = i;
    } else if (header === "/metadata/team_name") {
      teamNameCol = i;
    }
  }

  Logger.log("buildUsernameToDisplayLookup: userIdCol=" + userIdCol + ", displayNameCol=" + displayNameCol + ", teamNameCol=" + teamNameCol);

  // If we can't find required columns, return empty
  if (teamNameCol === -1 || displayNameCol === -1) {
    Logger.log("buildUsernameToDisplayLookup: Could not find required columns");
    return {};
  }

  // Get raw API data (rows 2-35, up to 34 users) to build username -> team_name lookup
  var maxCol = Math.max(userIdCol, displayNameCol, teamNameCol) + 1;
  var rawData = userSheet.getRange(2, 1, 34, maxCol).getValues();

  var lookup = {};
  rawData.forEach(function(row) {
    var username = row[displayNameCol];
    var teamName = row[teamNameCol];
    if (username && teamName) {
      lookup[username.toString()] = teamName.toString();
    }
  });

  Logger.log("buildUsernameToDisplayLookup: created " + Object.keys(lookup).length + " mappings");
  return lookup;
}

/**
 * Build a lookup object for player information
 * @return {Object} - Object mapping player_id to {name, position, team}
 */
function buildPlayerLookup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var playerSheet = ss.getSheetByName("Players Database");

  if (!playerSheet) {
    Logger.log("Players Database sheet not found");
    return {};
  }

  // Players sheet has: B=player_id, C=position, D=fantasy_positions, E=depth_chart_position,
  // F=first_name, G=last_name, H=full_name, I=team, J=years_exp, K=birth_date
  var lastRow = playerSheet.getLastRow();
  if (lastRow < 2) {
    return {};
  }

  var playerData = playerSheet.getRange(1, 2, lastRow, 10).getValues();
  var lookup = {};

  playerData.forEach(function(row) {
    var playerId = row[0];
    if (playerId) {
      lookup[playerId.toString()] = {
        name: String(row[6] || "").trim() ||
         (
          String(row[4] || "").trim() + " " +
          String(row[5] || "").trim()
         ).trim(),  // full_name (column H, index 6 in B:K range, or first and last if blank)
        position: row[1] || "",  // position (column C, index 1)
        fantasyPositions: row[2] || "",  // fantasy_positions (column D, index 2)
        team: row[7] || "",  // team (column I, index 7)
        birthDate: row[9] || ""  // birth_date (column K, index 9)
      };
    }
  });

  return lookup;
}

/**
 * Build a list of scoring stat categories from Settings sheet
 * Returns array of stat names that have non-zero scoring values
 * @return {Array} - Array of stat category names (e.g., ["pass_yd", "pass_td", "rush_yd", ...])
 */
function buildScoringStatsList() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var settingsSheet = ss.getSheetByName("Settings");

  if (!settingsSheet) {
    Logger.log("Settings sheet not found");
    return [];
  }

  // Get headers from row 1
  var lastCol = settingsSheet.getLastColumn();
  if (lastCol === 0) {
    Logger.log("No columns found in Settings sheet");
    return [];
  }

  var headers = settingsSheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var values = settingsSheet.getRange(2, 1, 1, lastCol).getValues()[0];

  var scoringStats = [];

  // Find all /scoring_settings/* columns with non-zero values
  for (var i = 0; i < headers.length; i++) {
    var header = headers[i].toString();
    if (header.startsWith("/scoring_settings/")) {
      var value = values[i];
      // Include stat if value is non-zero (checking for small floating point differences)
      if (value !== null && value !== "" && Math.abs(value) > 0.000001) {
        // Extract stat name from header (e.g., "/scoring_settings/pass_yd" -> "pass_yd")
        var statName = header.replace("/scoring_settings/", "");
        scoringStats.push(statName);
      }
    }
  }

  Logger.log("Found " + scoringStats.length + " scoring stats: " + scoringStats.join(", "));
  return scoringStats;
}

/**
 * Get the list of active roster positions for the league from Settings
 * @return {Array} - Array of position strings (e.g., ["QB", "RB", "WR", "K"])
 */
function getLeagueRosterPositions() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var settingsSheet = ss.getSheetByName("Settings");

  if (!settingsSheet) return [];

  // Get headers from row 1
  var lastCol = settingsSheet.getLastColumn();
  if (lastCol === 0) return [];

  var headers = settingsSheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var values = settingsSheet.getRange(2, 1, 1, lastCol).getValues()[0];

  // Find /roster_positions column
  for (var i = 0; i < headers.length; i++) {
    if (headers[i] === "/roster_positions") {
      var val = values[i];
      if (val) {
        // Value is likely a comma-separated string from the JSON parse
        return val.toString().toUpperCase().split(",").map(function(s) { return s.trim(); });
      }
    }
  }
  
  return [];
}

/**
 * Build a list of scoring stat objects with labels, sorted according to definitions
 * @return {Array} - Array of objects {key: "pass_yd", label: "Passing Yards"}
 */
function buildSortedScoringStats() {
  var scoringStatsRaw = buildScoringStatsList();
  var statDefinitions = getStatDefinitions();
  var scoringStats = []; // Array of {key, label}
  var rosterPositions = getLeagueRosterPositions();
  
  // Create a map for quick lookup of active stats
  var activeStatsMap = {};
  scoringStatsRaw.forEach(function(stat) {
    activeStatsMap[stat] = true;
  });
  
  // Helper to check if a position is active in the league (DEPRECATED: Use isPositionRelevantInLeague)
  // Kept here momentarily if needed, but logic moved to new function

  // Add defined stats in order if they are active
  statDefinitions.forEach(function(def) {
    if (activeStatsMap[def.key]) {
      // Only add if the position is active in the league
      if (isPositionRelevantInLeague(def.position, rosterPositions)) {
        scoringStats.push(def);
      }
      delete activeStatsMap[def.key]; // Remove so we know what's left
    }
  });
  
  // Add any remaining active stats that weren't in definitions (at the end)
  for (var stat in activeStatsMap) {
    scoringStats.push({key: stat, label: stat});
  }
  
  return scoringStats;
}

/**
 * Check if a player position is relevant for the league based on roster settings
 * @param {string} pos - The position to check (e.g., "QB", "RB", "OL")
 * @param {Array} rosterPositions - Array of active roster positions in the league
 * @return {boolean} - True if the position is relevant
 */
function isPositionRelevantInLeague(pos, rosterPositions) {
  if (!pos || pos === "ALL" || pos === "MISC" || pos === "BONUS") return true;
  
  // Strict checks for exclusive positions
  if (pos === "K") return rosterPositions.includes("K");
  if (pos === "DEF") return rosterPositions.includes("DEF");
  
  // IDP check
  if (pos === "IDP" || ["DL", "LB", "DB"].includes(pos)) {
    return rosterPositions.some(function(p) { 
      return ["DL", "LB", "DB", "IDP_FLEX", "LB_DL", "DB_LB", "DL_DB"].includes(p); 
    });
  }
  
  // Offensive positions (check for specific slot OR flex spots)
  // Note: SUPER_FLEX allows almost anything, so if it exists, we usually include all offensive stats
  var hasSuperFlex = rosterPositions.includes("SUPER_FLEX") || rosterPositions.includes("OP");
  var hasFlex = rosterPositions.includes("FLEX");
  var hasRecFlex = rosterPositions.includes("REC_FLEX") || rosterPositions.includes("WRRB_FLEX"); // WR/RB/TE or WR/RB
  
  if (pos === "QB") return rosterPositions.includes("QB") || hasSuperFlex;
  if (pos === "RB") return rosterPositions.includes("RB") || hasFlex || hasRecFlex || hasSuperFlex;
  if (pos === "WR") return rosterPositions.includes("WR") || hasFlex || hasRecFlex || hasSuperFlex;
  if (pos === "TE") return rosterPositions.includes("TE") || hasFlex || hasRecFlex || hasSuperFlex;
  
  // Explicit check for other positions like OL, P, LS - default to false if not handled above
  return false; 
}

/**
 * Check if team defenses are included in roster positions
 * @return {boolean} - True if DEF is in roster positions
 */
function hasTeamDefenses() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var settingsSheet = ss.getSheetByName("Settings");

  if (!settingsSheet) {
    Logger.log("Settings sheet not found");
    return false;
  }

  // Get headers from row 1
  var lastCol = settingsSheet.getLastColumn();
  if (lastCol === 0) {
    return false;
  }

  var headers = settingsSheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var values = settingsSheet.getRange(2, 1, 1, lastCol).getValues()[0];

  // Find /roster_positions column
  for (var i = 0; i < headers.length; i++) {
    var header = headers[i].toString();
    if (header === "/roster_positions") {
      var rosterPositions = values[i];
      if (rosterPositions) {
        // Check if DEF is in the roster positions string
        var rosterStr = rosterPositions.toString().toUpperCase();
        return rosterStr.indexOf("DEF") !== -1;
      }
    }
  }

  return false;
}

/**
 * Get map of scoring multipliers from Settings
 * @return {Object} - Map of stat name to point value (e.g. {"pass_yd": 0.04, "pass_td": 4})
 */
function getScoringMultipliers() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var settingsSheet = ss.getSheetByName("Settings");

  if (!settingsSheet) return {};

  // Get headers from row 1
  var lastCol = settingsSheet.getLastColumn();
  if (lastCol === 0) return {};

  var headers = settingsSheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var values = settingsSheet.getRange(2, 1, 1, lastCol).getValues()[0];

  var multipliers = {};

  // Find all /scoring_settings/* columns
  for (var i = 0; i < headers.length; i++) {
    var header = headers[i].toString();
    if (header.startsWith("/scoring_settings/")) {
      var value = values[i];
      if (value !== null && value !== "") {
        var statName = header.replace("/scoring_settings/", "");
        multipliers[statName] = parseFloat(value) || 0;
      }
    }
  }
  
  return multipliers;
}

/**
 * Calculate fantasy points for a set of stats
 * @param {Object} stats - The player's stats object for the week
 * @param {Object} multipliers - The scoring multipliers map
 * @return {number} - Total fantasy points
 */
function calculateFantasyPoints(stats, multipliers) {
  var total = 0;
  if (!stats) return 0;
  
  for (var statKey in stats) {
    if (multipliers.hasOwnProperty(statKey)) {
      total += (stats[statKey] || 0) * multipliers[statKey];
    }
  }
  
  // Return rounded to 2 decimal places
  return Math.round(total * 100) / 100;
}

/**
 * Fetch weekly stats from Sleeper API for a specific week
 * @param {number} year - The season year
 * @param {number} week - The week number
 * @param {boolean} includeTeamDefenses - Whether to include team defense stats
 * @return {Object} - Object mapping player_id -> stats object
 */
function fetchWeeklyStats(year, week, includeTeamDefenses) {
  try {
    var url = "https://api.sleeper.app/v1/stats/nfl/regular/" + year + "/" + week;
    var statsData = fetchSleeperJson(url, { workflow: "Weekly Stats " + year + " Week " + week });

    // If we don't want team defenses, filter them out
    if (!includeTeamDefenses) {
      var filteredStats = {};
      for (var playerId in statsData) {
        // Team defense IDs start with "TEAM_" (e.g., "TEAM_BUF", "TEAM_LV")
        if (!playerId.startsWith("TEAM_")) {
          filteredStats[playerId] = statsData[playerId];
        }
      }
      Logger.log("Fetched stats for " + Object.keys(filteredStats).length + " players (team defenses excluded)");
      return filteredStats;
    }

    Logger.log("Fetched stats for " + Object.keys(statsData).length + " players (including team defenses)");
    return statsData;

  } catch (e) {
    Logger.log("Error fetching weekly stats: " + e.toString());
    return {};
  }
}

/**
 * Fetch weekly projections from Sleeper API for a specific week
 * @param {number} year - The season year
 * @param {number} week - The week number
 * @return {Object} - Object mapping player_id -> stats object
 */
function fetchWeeklyProjections(year, week) {
  try {
    // API endpoint to fetch all relevant positions
    var url = "https://api.sleeper.app/projections/nfl/" + year + "/" + week + "?order_by=ppr&position[]=DB&position[]=DEF&position[]=DL&position[]=K&position[]=LB&position[]=QB&position[]=RB&position[]=TE&position[]=WR&season_type=regular";
    var projectionsData = fetchSleeperJson(url, { workflow: "Weekly Projections " + year + " Week " + week });

    // Convert array to object keyed by player_id
    var projectionsMap = {};
    if (Array.isArray(projectionsData)) {
      projectionsData.forEach(function(p) {
        if (p.player_id) {
           projectionsMap[p.player_id] = p; 
        }
      });
    } else {
      Logger.log("Projections data is not an array");
    }
    
    Logger.log("Fetched projections for " + Object.keys(projectionsMap).length + " players");
    return projectionsMap;

  } catch (e) {
    Logger.log("Error fetching weekly projections: " + e.toString());
    return {};
  }
}

/**
 * =====================================================
 * MENU AND MAIN WORKFLOWS
 * =====================================================
 * This file contains the main entry points, menu setup, and primary
 * workflow orchestration functions (Step 1, Step 2).
 */

/**
 * Create custom menu when the spreadsheet opens
 */
function onOpen() {
  var ui = SpreadsheetApp.getUi();

  ui.createMenu('🏈 Sleeper Data')
    .addItem('📥 Step 1: Refresh User Info', 'RefreshStep1_UserAndLeagues')
    .addItem('📊 Step 2: Refresh League Info', 'RefreshStep2_LeagueData')
    .addItem('📋 Refresh Rosters', 'RefreshCurrentRosters')
    .addSubMenu(ui.createMenu('⚠️ Alternate Step 2 For Timeouts:')
      .addItem('Batch 1/3: Gather Data', 'LargeLeagueProcessing_StartBatch1')
      .addItem('Batch 2/3: Process Weeks + Derived Data', 'LargeLeagueProcessing_Batch2')
      .addItem('Batch 3/3: Player Results + Awards', 'LargeLeagueProcessing_Batch3'))
    .addSeparator()
    .addItem('👥 Update Players Database', 'UpdatePlayers')
    .addItem('📅 Reset to Default State', 'ResetToDefaultState')
    .addToUi();
}


/**
 * Master Refresh Function - Two Step Process
 * Step 1: Call this first to refresh user and leagues data
 */
function RefreshStep1_UserAndLeagues() {
  var workflowStartTime = new Date();
  var workflowLock = acquireWorkflowLock("Step 1: Refresh User Info");
  if (!workflowLock) return;

  try {
    recordDiagnostics("Step 1: Refresh User Info", "Started", workflowStartTime);

    var ui = SpreadsheetApp.getUi();
    ui.alert('Step 1: Refreshing User and Leagues Data',
      'This will update your user info and available leagues.',
      ui.ButtonSet.OK);

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");

    // Clear the league selection dropdown (B4) so user must re-select
    infoSheet.getRange("B4").clearContent();

    // Get year
    var year = infoSheet.getRange("B2").getValue();
    if (!year) {
      throw new Error("Please enter a year in Info!B2");
    }
    // Sanitize year
    year = year.toString().trim();

    // Clear all output sheets to prevent stale data
    ClearAllOutputSheets();

    // Step 1: Refresh user data
    var userId = RefreshUserData();

    // Step 2: Refresh leagues data
    RefreshLeaguesData(userId, year);

    // Flush all pending changes before showing completion dialog
    SpreadsheetApp.flush();

    TrimAllSheets();

    recordDiagnostics("Step 1: Refresh User Info", "Completed", workflowStartTime);

    ui.alert('Step 1 Complete!',
      'User and leagues data refreshed.\n\n' +
      'Please select your league from the dropdown in Info!B4, then run Step 2.',
      ui.ButtonSet.OK);

  } catch (error) {
    SpreadsheetApp.flush();
    recordDiagnostics("Step 1: Refresh User Info", "Failed", workflowStartTime, null, error.toString());
    SpreadsheetApp.getUi().alert('Error in Step 1', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  } finally {
    workflowLock.releaseLock();
  }
}

/**
 * Step 2: Call this after selecting a league to refresh all league-specific data
 */
function RefreshStep2_LeagueData() {
  var startTime = new Date();
  var leagueId = "";
  var workflowLock = acquireWorkflowLock("Step 2: Refresh League Info");
  if (!workflowLock) return;

  try {
    recordDiagnostics("Step 2: Refresh League Info", "Started", startTime);
    Logger.log("=== STEP 2 START: " + startTime.toISOString() + " ===");

    var ui = SpreadsheetApp.getUi();
    ui.alert('Step 2: Refreshing League Data',
      'This will update all data for your selected league.\n' +
      'This will likely take several minutes to complete.',
      ui.ButtonSet.OK);

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");

    // ===== CLEAR ALL OUTPUT SHEETS FIRST =====
    // This ensures no data from previous leagues remains
    var clearStartTime = new Date();
    Logger.log("TIMER: Starting sheet clearing at " + clearStartTime.toISOString());

    ClearAllOutputSheets();

    var clearEndTime = new Date();
    var clearDuration = (clearEndTime - clearStartTime) / 1000;
    Logger.log("TIMER: Sheet clearing completed in " + clearDuration + " seconds");
    // ===== END CLEARING =====

    // Get current week
    var currentWeek = infoSheet.getRange("B3").getValue();
    if (!currentWeek) {
      throw new Error("Please enter the current week in Info!B3");
    }

    // Get selected league ID
    leagueId = GetSelectedLeagueId();

    // Refresh all league-specific data
    var leagueDataStartTime = new Date();
    Logger.log("TIMER: Starting RefreshLeagueSpecificData at " + leagueDataStartTime.toISOString());
    var errors = RefreshLeagueSpecificData(leagueId, currentWeek);
    var leagueDataEndTime = new Date();
    var leagueDataDuration = (leagueDataEndTime - leagueDataStartTime) / 1000;
    Logger.log("TIMER: RefreshLeagueSpecificData completed in " + leagueDataDuration + " seconds");

    // Refresh derived data (Transactions, Standings, Draft)
    var derivedDataStartTime = new Date();
    Logger.log("TIMER: Starting RefreshDerivedData at " + derivedDataStartTime.toISOString());
    var derivedErrors = RefreshDerivedData(leagueId, currentWeek, { skipFinalDependentOutputs: true });
    errors = errors.concat(derivedErrors);
    var derivedDataEndTime = new Date();
    var derivedDataDuration = (derivedDataEndTime - derivedDataStartTime) / 1000;
    Logger.log("TIMER: RefreshDerivedData completed in " + derivedDataDuration + " seconds");

    // Flush all pending changes before showing completion dialog
    var flushStartTime = new Date();
    Logger.log("TIMER: Starting SpreadsheetApp.flush() at " + flushStartTime.toISOString());
    SpreadsheetApp.flush();
    var flushEndTime = new Date();
    var flushDuration = (flushEndTime - flushStartTime) / 1000;
    Logger.log("TIMER: SpreadsheetApp.flush() completed in " + flushDuration + " seconds");

    var totalEndTime = new Date();
    var totalDuration = (totalEndTime - startTime) / 1000;
    Logger.log("=== STEP 2 PART 1 COMPLETE: Total duration " + totalDuration + " seconds ===");

    // Auto-trigger Player Results refresh (Part 2). The parent Step 2 owns the final user alert.
    var part2Result = RefreshPlayerResultsManual(errors, { showCompletionAlert: false });
    if (part2Result && part2Result.warnings && part2Result.warnings.length > 0) {
      errors = errors.concat(part2Result.warnings);
    }
    if (part2Result && part2Result.success === false) {
      throw new Error("Step 2 Part 2 failed: " + part2Result.error);
    }

    var currentRosterResult = RefreshCurrentRosters({
      showAlerts: false,
      useLock: false,
      skipSettingsUsersRefresh: true,
      workflowName: "Step 2: Refresh Rosters"
    });
    if (currentRosterResult && currentRosterResult.warnings && currentRosterResult.warnings.length > 0) {
      errors = errors.concat(currentRosterResult.warnings);
    }
    if (currentRosterResult && currentRosterResult.success === false) {
      errors.push("Rosters: " + currentRosterResult.error);
    }
    SpreadsheetApp.flush();
    autoResizeGeneratedOutputSheets();
    SpreadsheetApp.flush();

    var finalStatus = errors.length > 0 ? "Completed with Warnings" : "Completed";
    recordDiagnostics("Step 2: Refresh League Info", finalStatus, startTime, errors, null, leagueId);

    var message = 'All league data has been successfully refreshed.\n\n' +
      'Your data is now fully up to date!';

    if (errors.length > 0) {
      message = 'Step 2 completed, but some items need review:\n\n' + errors.join('\n');
    }

    ui.alert('Step 2 Complete!', message, ui.ButtonSet.OK);

  } catch (error) {
    SpreadsheetApp.flush();
    recordDiagnostics("Step 2: Refresh League Info", "Failed", startTime, null, error.toString(), leagueId);
    SpreadsheetApp.getUi().alert('Error in Step 2', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  } finally {
    workflowLock.releaseLock();
  }
}

/**
 * Debug function to check current state
 */
function DebugCheckState() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var leaguesSheet = ss.getSheetByName("Leagues");

    var debugInfo = [];

    // Check Info sheet values
    debugInfo.push("INFO SHEET VALUES");
    debugInfo.push("B1 (Username): " + infoSheet.getRange("B1").getValue());
    debugInfo.push("B2 (Year): " + infoSheet.getRange("B2").getValue());
    debugInfo.push("B3 (Current Week): " + infoSheet.getRange("B3").getValue());
    debugInfo.push("B4 (Selected League): " + infoSheet.getRange("B4").getValue());
    debugInfo.push("C1 (User ID): " + infoSheet.getRange("C1").getValue());

    // Check Leagues sheet
    debugInfo.push("\nLEAGUES SHEET CHECK");
    var headerRow54 = leaguesSheet.getRange("54:54").getValues()[0];
    var dataRow55 = leaguesSheet.getRange("55:55").getValues()[0];

    // Find user_id column
    var userIdCol = -1;
    for (var i = 0; i < headerRow54.length; i++) {
      if (headerRow54[i] === "user_id") {
        userIdCol = i;
        break;
      }
    }

    debugInfo.push("User data headers found: " + (headerRow54.filter(h => h).length > 0 ? "Yes" : "No"));
    debugInfo.push("User ID column index: " + userIdCol);
    if (userIdCol >= 0) {
      debugInfo.push("User ID value: " + dataRow55[userIdCol]);
    }

    // Check league data
    var headerRow1 = leaguesSheet.getRange("1:1").getValues()[0];
    debugInfo.push("League headers found: " + (headerRow1.filter(h => h).length > 0 ? "Yes" : "No"));

    // Check E61
    debugInfo.push("E61 (League ID): " + leaguesSheet.getRange("E61").getValue());
    debugInfo.push("E61 Formula: " + leaguesSheet.getRange("E61").getFormula());

    // Show results
    Logger.log(debugInfo.join("\n"));
    SpreadsheetApp.getUi().alert('Debug Information', debugInfo.join('\n'), SpreadsheetApp.getUi().ButtonSet.OK);

  } catch (error) {
    SpreadsheetApp.getUi().alert('Debug Error', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  }
}

/**
 * Test function to verify sheets are being updated correctly
 */
function VerifyDataRefresh() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var results = [];

    // Check each key sheet
    var sheetsToCheck = [
      { name: "Settings", cell: "A1" },
      { name: "Users", cell: "A1" },
      { name: "Week 1", cell: "A1" },
      { name: "Transactions", cell: "A1" },
      { name: "Standings", cell: "A1" },
      { name: "Draft Result", cell: "A1" }
    ];

    results.push(["Sheet", "Has Data?", "First Cell Value"]);

    sheetsToCheck.forEach(function (sheetInfo) {
      try {
        var sheet = ss.getSheetByName(sheetInfo.name);
        if (sheet) {
          var value = sheet.getRange(sheetInfo.cell).getValue();
          results.push([
            sheetInfo.name,
            value ? "Yes" : "No",
            value ? value.toString().substring(0, 50) : "(empty)"
          ]);
        } else {
          results.push([sheetInfo.name, "Sheet not found", ""]);
        }
      } catch (e) {
        results.push([sheetInfo.name, "Error", e.toString()]);
      }
    });

    // Create or update Debug sheet
    var debugSheet;
    debugSheet = ss.getSheetByName("Debug");
    if (!debugSheet) {
      debugSheet = ss.insertSheet("Debug");
    }

    debugSheet.clear();
    debugSheet.getRange(1, 1, results.length, 3).setValues(results);

    SpreadsheetApp.getActiveSpreadsheet().toast(
      "Verification complete! Check the Debug sheet for results.",
      "Data Verification",
      5
    );

  } catch (error) {
    SpreadsheetApp.getUi().alert('Verification Error', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  }
}

/**
 * Player Results refresh - Part 2 of Step 2
 * Auto-triggered after main Step 2 completes
 */
function RefreshPlayerResultsManual(previousErrors, options) {
  options = options || {};
  var showCompletionAlert = options.showCompletionAlert !== false;
  var workflowStartTime = new Date();
  var leagueId = "";
  try {
    // FCC 7.x: time-driven triggers have no open spreadsheet UI.
    // Only request Ui when an interactive alert is actually required.
    var ui = showCompletionAlert ? SpreadsheetApp.getUi() : null;

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var currentWeek = infoSheet.getRange("B3").getValue();

    if (!currentWeek) {
      throw new Error("Please enter the current week in Info!B3");
    }

    leagueId = GetSelectedLeagueId();
    recordDiagnostics("Step 2 Part 2: Player Results", "Started", workflowStartTime, null, null, leagueId);

    var startTime = workflowStartTime;
    var partWarnings = [];
    Logger.log("=== STEP 2 PART 2 START: Player Results refresh ===");

    RefreshYearlyOutput(currentWeek);
    SpreadsheetApp.flush();

    var playerResultsEndTime = new Date();
    var playerResultsDuration = (playerResultsEndTime - startTime) / 1000;
    Logger.log("TIMER: Player Results completed in " + playerResultsDuration + " seconds");

    // Now refresh Standings, Weekly Results, and Awards (they depend on Player Results)
    Logger.log("TIMER: Refreshing dependent sheets (Standings, Weekly Results, Awards)");

    // Refresh Standings and Weekly Results
    var standingsStartTime = new Date();
    try {
      var calculatedData = CalculateDetailedStandings(currentWeek);

      // Write Standings sheet
      var standingsSheet = ss.getSheetByName("Standings");
      if (standingsSheet && calculatedData.standingsData && calculatedData.standingsData.length > 0) {
        standingsSheet.clear();
        ensureSheetSize(standingsSheet, calculatedData.standingsData.length, calculatedData.standingsData[0].length);
        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, calculatedData.standingsData[0].length).setValues(calculatedData.standingsData);
        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, calculatedData.standingsData[0].length).setHorizontalAlignment("center");
        standingsSheet.autoResizeColumns(1, calculatedData.standingsData[0].length);
      }

      // Write Weekly Results sheet
      var weeklyResultsSheet = ss.getSheetByName("Weekly Results");
      if (weeklyResultsSheet && calculatedData.weeklyResultsData && calculatedData.weeklyResultsData.length > 0) {
        weeklyResultsSheet.clear();
        ensureSheetSize(weeklyResultsSheet, calculatedData.weeklyResultsData.length, calculatedData.weeklyResultsData[0].length);
        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, calculatedData.weeklyResultsData[0].length).setValues(calculatedData.weeklyResultsData);
        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, calculatedData.weeklyResultsData[0].length).setHorizontalAlignment("center");
        weeklyResultsSheet.autoResizeColumns(1, calculatedData.weeklyResultsData[0].length);
      }
      var standingsEndTime = new Date();
      Logger.log("TIMER: Standings/Weekly Results completed in " + ((standingsEndTime - standingsStartTime) / 1000) + " seconds");
    } catch (error) {
      Logger.log("Error refreshing Standings/Weekly Results: " + error.toString());
      partWarnings.push("Standings/Weekly Results: " + error.toString());
    }

    // Refresh Awards
    var awardsStartTime = new Date();
    try {
      var awardsData = CalculateAwards(currentWeek);
      var awardsSheet = ss.getSheetByName("Awards");
      if (awardsSheet && awardsData && awardsData.length > 0) {
        awardsSheet.clear();
        ensureSheetSize(awardsSheet, awardsData.length, awardsData[0].length);
        awardsSheet.getRange(1, 1, awardsData.length, awardsData[0].length).setValues(awardsData);

        // Center align all data
        awardsSheet.getRange(1, 1, awardsData.length, 5).setHorizontalAlignment("center");

        // Format section headers and sub-headers
        for (var i = 0; i < awardsData.length; i++) {
          var cellValue = awardsData[i][0] ? awardsData[i][0].toString() : "";

          // Section headers (INDIVIDUAL PLAYER AWARDS, TEAM AWARDS, SEASON-LONG AWARDS)
          if (cellValue === "INDIVIDUAL PLAYER AWARDS" || cellValue === "TEAM AWARDS" || cellValue === "SEASON-LONG AWARDS") {
            var headerRange = awardsSheet.getRange(i + 1, 1, 1, 5);
            headerRange.merge();
            headerRange.setFontWeight("bold");
            headerRange.setBackground("#4a86e8");
            headerRange.setFontColor("#ffffff");
            headerRange.setHorizontalAlignment("center");
          }

          // Sub-headers (Award, Player, Position, etc.)
          if (cellValue === "Award") {
            awardsSheet.getRange(i + 1, 1, 1, 5).setFontWeight("bold").setBackground("#d9d9d9");
          }
        }

        // Auto-fit columns
        awardsSheet.autoResizeColumns(1, 5);
      }
      var awardsEndTime = new Date();
      Logger.log("TIMER: Awards completed in " + ((awardsEndTime - awardsStartTime) / 1000) + " seconds");
    } catch (error) {
      Logger.log("Error refreshing Awards: " + error.toString());
      partWarnings.push("Awards: " + error.toString());
    }

    SpreadsheetApp.flush();

    var endTime = new Date();
    var duration = (endTime - startTime) / 1000;
    Logger.log("=== STEP 2 PART 2 COMPLETE: Total duration " + duration + " seconds ===");

    TrimAllSheets();
    autoResizeGeneratedOutputSheets();
    recordDiagnostics(
      "Step 2 Part 2: Player Results",
      partWarnings.length > 0 ? "Completed with Warnings" : "Completed",
      workflowStartTime,
      partWarnings,
      null,
      leagueId
    );

    var message = 'All league data has been successfully refreshed.\n\n' +
      'Your data is now fully up to date!';

    if (Array.isArray(previousErrors) && previousErrors.length > 0) {
      message = 'Step 2 completed, but Part 1 had errors:\n\n' + previousErrors.join('\n') + '\n\n' +
        'Part 2 (Player Results) completed successfully.';
    }

    if (showCompletionAlert) {
      ui.alert('Step 2 Complete!', message, ui.ButtonSet.OK);
    }

    return {
      success: true,
      warnings: partWarnings
    };

  } catch (error) {
    SpreadsheetApp.flush();
    recordDiagnostics("Step 2 Part 2: Player Results", "Failed", workflowStartTime, null, error.toString(), leagueId);
    if (showCompletionAlert) {
      SpreadsheetApp.getUi().alert('Error in Step 2 Part 2 (Player Results)', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
    }
    return {
      success: false,
      error: error.toString(),
      warnings: []
    };
  }
}

/**
 * Refresh roster views without running weekly historical outputs.
 */
function RefreshCurrentRosters(options) {
  options = options || {};
  var workflowName = options.workflowName || "Refresh Rosters";
  var showAlerts = options.showAlerts !== false;
  var useLock = options.useLock !== false;
  var skipSettingsUsersRefresh = options.skipSettingsUsersRefresh === true;
  var workflowStartTime = new Date();
  var workflowLock = useLock ? acquireWorkflowLock(workflowName) : null;
  if (useLock && !workflowLock) return;

  var leagueId = "";
  try {
    recordDiagnostics(workflowName, "Started", workflowStartTime);

    // FCC 7.x: avoid getUi() in time-driven backup runs.
    var ui = showAlerts ? SpreadsheetApp.getUi() : null;
    if (showAlerts) {
      ui.alert(
        'Refresh Rosters',
        'This will update roster and team information for the selected league.',
        ui.ButtonSet.OK
      );
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    if (!infoSheet) {
      throw new Error("Info sheet not found");
    }

    leagueId = GetSelectedLeagueId();
    if (!leagueId) {
      throw new Error("Please select a league in Info!B4");
    }

    var year = infoSheet.getRange("B2").getValue();
    if (!year) {
      throw new Error("Please enter a year in Info!B2");
    }

    var warnings = [];

    if (!skipSettingsUsersRefresh) {
      // Keep hidden Settings/Users aligned with the selected league. This fetches league, users, and rosters only.
      var settingsUsersErrors = RefreshSettingsAndUsers(leagueId);
      if (settingsUsersErrors && settingsUsersErrors.length > 0) {
        warnings = warnings.concat(settingsUsersErrors);
      }
    }

    var rosters = fetchSleeperJson("https://api.sleeper.app/v1/league/" + leagueId + "/rosters", {
      workflow: workflowName + " - Rosters",
      preserveLargeNumbers: true,
      leagueId: leagueId
    }) || [];

    if (!Array.isArray(rosters) || rosters.length === 0) {
      hideCurrentRosterOutputSheets();
      SpreadsheetApp.flush();
      recordDiagnostics(workflowName, "Completed - No Rosters", workflowStartTime, null, null, leagueId);
      if (showAlerts) {
        ui.alert(
          'No Rosters',
          'Sleeper did not return roster data for the selected league.\n\n' +
          'The Roster Summary and Rosters tabs have been cleared and hidden.',
          ui.ButtonSet.OK
        );
      }
      return {
        success: true,
        warnings: [],
        noRosterData: true
      };
    }

    var playerLookup = buildPlayerLookup();
    var identityLookup = buildRosterIdentityLookup(rosters);
    var rosterPositions = getLeagueRosterPositions();
    var starterSlots = getStarterSlotLabels(rosterPositions);
    var settingsSheet = ss.getSheetByName("Settings");
    var reserveSlots = parseInt(getSettingValue(settingsSheet, "/settings/reserve_slots"), 10);
    var taxiSlots = parseInt(getSettingValue(settingsSheet, "/settings/taxi_slots"), 10);
    var waiverBudget = parseInt(getSettingValue(settingsSheet, "/settings/waiver_budget"), 10);

    if (isNaN(reserveSlots)) reserveSlots = 0;
    if (isNaN(taxiSlots)) taxiSlots = 0;
    if (isNaN(waiverBudget)) waiverBudget = null;

    var activeRosterLimit = rosterPositions.filter(function(position) {
      position = position ? position.toString().toUpperCase() : "";
      return position !== "IR" && position !== "TAXI";
    }).length;

    var pickCounts = buildFuturePickCountsByRoster(rosters, parseInt(year, 10), leagueId);
    var output = buildCurrentRosterOutput(
      rosters,
      playerLookup,
      identityLookup,
      starterSlots,
      activeRosterLimit,
      reserveSlots,
      taxiSlots,
      waiverBudget,
      pickCounts,
      warnings
    );

    writeCurrentRosterOutput(output.summary, output.detail);
    refreshOwnedDraftPicksOutput();

    SpreadsheetApp.flush();
    TrimSheet(ss.getSheetByName("Roster Summary"));
    TrimSheet(ss.getSheetByName("Rosters"));
    TrimSheet(ss.getSheetByName("Owned Draft Picks"));
    autoResizeGeneratedOutputSheets(["Roster Summary", "Rosters", "Owned Draft Picks"]);

    var status = warnings.length > 0 ? "Completed with Warnings" : "Completed";
    recordDiagnostics(workflowName, status, workflowStartTime, warnings, null, leagueId);

    var message = 'Roster views refreshed.\n\n' +
      'Roster Summary rows: ' + Math.max(0, output.summary.length - 1) + '\n' +
      'Rosters rows: ' + Math.max(0, output.detail.length - 1);

    if (warnings.length > 0) {
      message += '\n\nWarnings:\n' + warnings.join('\n');
    }

    if (showAlerts) {
      ui.alert('Rosters Complete', message, ui.ButtonSet.OK);
    }

    return {
      success: true,
      warnings: warnings,
      summaryRows: Math.max(0, output.summary.length - 1),
      detailRows: Math.max(0, output.detail.length - 1)
    };

  } catch (error) {
    SpreadsheetApp.flush();
    recordDiagnostics(workflowName, "Failed", workflowStartTime, null, error.toString(), leagueId);
    if (showAlerts) {
      SpreadsheetApp.getUi().alert('Error refreshing rosters', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
    }
    return {
      success: false,
      error: error.toString(),
      warnings: []
    };
  } finally {
    if (workflowLock) {
      workflowLock.releaseLock();
    }
  }
}

function writeCurrentRosterOutput(summaryData, detailData) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var summarySheet = getOrCreateVisibleSheet("Roster Summary", 2);
  var detailSheet = getOrCreateVisibleSheet("Rosters", 3, "Current Rosters");

  writeOutputTable(summarySheet, summaryData);
  writeOutputTable(detailSheet, detailData);
}

function hideCurrentRosterOutputSheets() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ["Roster Summary", "Rosters", "Current Rosters"].forEach(function(sheetName) {
    var sheet = ss.getSheetByName(sheetName);
    if (sheet) {
      sheet.clear();
      sheet.hideSheet();
    }
  });
}

function getOrCreateVisibleSheet(name, desiredIndex, legacyName) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(name);

  if (!sheet && legacyName) {
    var legacySheet = ss.getSheetByName(legacyName);
    if (legacySheet) {
      legacySheet.setName(name);
      sheet = legacySheet;
    }
  }

  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (desiredIndex) {
      ss.setActiveSheet(sheet);
      ss.moveActiveSheet(desiredIndex);
    }
  }

  sheet.showSheet();
  return sheet;
}

function writeOutputTable(sheet, data) {
  sheet.clear();
  ensureSheetSize(sheet, data.length, data[0].length);
  sheet.getRange(1, 1, data.length, data[0].length).setValues(data);
  sheet.getRange(1, 1, 1, data[0].length).setFontWeight("bold");
  sheet.setFrozenRows(1);
  sheet.getRange(1, 1, data.length, data[0].length).setHorizontalAlignment("center");
  autoResizeUsedColumns(sheet);
}

function refreshOwnedDraftPicksOutput() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var draftPicksData = ImportDraftPickInventory();
  var draftPicksSheet = ss.getSheetByName("Owned Draft Picks");
  if (draftPicksSheet && draftPicksData && draftPicksData.length > 0) {
    draftPicksSheet.clear();
    ensureSheetSize(draftPicksSheet, draftPicksData.length, draftPicksData[0].length);
    draftPicksSheet.getRange(1, 1, draftPicksData.length, draftPicksData[0].length).setValues(draftPicksData);
    draftPicksSheet.getRange(1, 1, draftPicksData.length, draftPicksData[0].length).setHorizontalAlignment("center");
    draftPicksSheet.getRange(1, 1, 1, draftPicksData[0].length).setFontWeight("bold");
    autoResizeUsedColumns(draftPicksSheet);
  }
}

function buildCurrentRosterOutput(rosters, playerLookup, identityLookup, starterSlots, activeRosterLimit, reserveSlots, taxiSlots, waiverBudget, pickCounts, warnings) {
  var summary = [[
    "Roster ID", "Owner", "Team Name", "Total Players", "Active Players", "Starters", "Bench", "Reserve", "Taxi",
    "Open Active Spots", "Open Reserve Spots", "Open Taxi Spots", "QB", "RB", "WR", "TE", "K", "DEF", "Other",
    "Average Age", "Under 25", "FAAB Remaining", "Waiver Position", "Current Year Picks", "Next Year Picks"
  ]];

  var detail = [[
    "Roster ID", "Owner", "Team Name", "Roster Slot", "Starter Slot", "Player ID", "Player", "Position",
    "Fantasy Positions", "NFL Team", "Age"
  ]];

  rosters.sort(function(a, b) {
    return parseInt(a.roster_id, 10) - parseInt(b.roster_id, 10);
  });

  rosters.forEach(function(roster) {
    var rosterId = roster.roster_id ? roster.roster_id.toString() : "";
    if (!rosterId) {
      warnings.push("Roster missing roster_id");
      return;
    }

    var identity = identityLookup[rosterId] || {
      owner: "Open Roster " + rosterId,
      teamName: "Open Roster " + rosterId
    };

    var players = uniqueStringArray(roster.players || []);
    var starters = uniqueStringArray(roster.starters || []);
    var reserve = uniqueStringArray(roster.reserve || []);
    var taxi = uniqueStringArray(roster.taxi || []);
    var reserveLookup = arrayToLookup(reserve);
    var taxiLookup = arrayToLookup(taxi);
    var starterLookup = arrayToLookup(starters);
    var allPlayers = uniqueStringArray(players.concat(reserve).concat(taxi));
    var activePlayers = players.filter(function(playerId) {
      return !reserveLookup[playerId] && !taxiLookup[playerId];
    });
    var benchPlayers = activePlayers.filter(function(playerId) {
      return !starterLookup[playerId];
    });

    var positionCounts = {
      QB: 0,
      RB: 0,
      WR: 0,
      TE: 0,
      K: 0,
      DEF: 0,
      Other: 0
    };
    var ageTotal = 0;
    var ageCount = 0;
    var under25 = 0;

    allPlayers.forEach(function(playerId) {
      var playerInfo = playerLookup[playerId] || null;
      if (!playerInfo) {
        warnings.push("Missing player metadata for player_id " + playerId);
        playerInfo = {};
      }

      var positionBucket = getPositionBucket(playerInfo.position, playerInfo.fantasyPositions);
      positionCounts[positionBucket]++;

      var age = calculateCurrentAge(playerInfo.birthDate);
      if (age !== "") {
        ageTotal += age;
        ageCount++;
        if (age < 25) under25++;
      }

      var starterIndex = starters.indexOf(playerId);
      var rosterSlot = reserveLookup[playerId] ? "Reserve" : (taxiLookup[playerId] ? "Taxi" : (starterIndex !== -1 ? "Starter" : "Bench"));
      var starterSlot = starterIndex !== -1 ? (starterSlots[starterIndex] || "Starter") : "";

      detail.push([
        rosterId,
        identity.owner,
        identity.teamName,
        rosterSlot,
        starterSlot,
        playerId,
        playerInfo.name || "",
        playerInfo.position || "",
        playerInfo.fantasyPositions || "",
        playerInfo.team || "",
        age
      ]);
    });

    var rosterSettings = roster.settings || {};
    var faabRemaining = waiverBudget === null ? "" : waiverBudget - (parseInt(rosterSettings.waiver_budget_used, 10) || 0);
    var rosterPickCounts = pickCounts[rosterId] || {};
    var averageAge = ageCount > 0 ? Math.round((ageTotal / ageCount) * 10) / 10 : "";

    summary.push([
      rosterId,
      identity.owner,
      identity.teamName,
      allPlayers.length,
      activePlayers.length,
      starters.length,
      benchPlayers.length,
      reserve.length,
      taxi.length,
      activeRosterLimit - activePlayers.length,
      reserveSlots - reserve.length,
      taxiSlots - taxi.length,
      positionCounts.QB,
      positionCounts.RB,
      positionCounts.WR,
      positionCounts.TE,
      positionCounts.K,
      positionCounts.DEF,
      positionCounts.Other,
      averageAge,
      under25,
      faabRemaining,
      rosterSettings.waiver_position || "",
      rosterPickCounts.current || 0,
      rosterPickCounts.next || 0
    ]);
  });

  return {
    summary: summary,
    detail: detail
  };
}

function buildRosterIdentityLookup(rosters) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var usersSheet = ss.getSheetByName("Users");
  var preferredLookup = buildUserLookup();
  var usersById = {};
  var result = {};

  if (usersSheet && usersSheet.getLastRow() >= 2) {
    var lastCol = usersSheet.getLastColumn();
    var headers = usersSheet.getRange(1, 1, 1, lastCol).getValues()[0];
    var userIdCol = findHeaderIndex(headers, "/user_id");
    var displayNameCol = findHeaderIndex(headers, "/display_name");
    var teamNameCol = findHeaderIndex(headers, "/metadata/team_name");

    var rawRows = usersSheet.getRange(2, 1, Math.min(34, usersSheet.getLastRow() - 1), lastCol).getValues();
    rawRows.forEach(function(row) {
      var userId = userIdCol !== -1 ? row[userIdCol] : "";
      if (!userId) return;

      var displayName = displayNameCol !== -1 ? row[displayNameCol] : "";
      var teamName = teamNameCol !== -1 ? row[teamNameCol] : "";
      usersById[userId.toString()] = {
        displayName: displayName ? displayName.toString() : userId.toString(),
        teamName: teamName ? teamName.toString() : (displayName ? displayName.toString() : userId.toString())
      };
    });
  }

  rosters.forEach(function(roster) {
    var rosterId = roster.roster_id ? roster.roster_id.toString() : "";
    if (!rosterId) return;

    var ownerId = roster.owner_id ? roster.owner_id.toString() : "";
    if (!ownerId || !usersById[ownerId]) {
      result[rosterId] = {
        owner: "Open Roster " + rosterId,
        teamName: "Open Roster " + rosterId
      };
      return;
    }

    result[rosterId] = {
      owner: preferredLookup[rosterId] || usersById[ownerId].displayName,
      teamName: usersById[ownerId].teamName
    };
  });

  return result;
}

function buildFuturePickCountsByRoster(rosters, currentYear, leagueId) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var settingsSheet = ss.getSheetByName("Settings");
  if (!settingsSheet) return {};
  if (isNaN(currentYear)) {
    currentYear = parseInt(ss.getSheetByName("Info").getRange("B2").getValue(), 10);
  }

  var settingsHeaders = settingsSheet.getRange(1, 1, 1, settingsSheet.getLastColumn()).getValues()[0];
  var pickTradingCol = findHeaderIndex(settingsHeaders, "/settings/pick_trading");
  var draftRoundsCol = findHeaderIndex(settingsHeaders, "/settings/draft_rounds");

  var counts = {};
  rosters.forEach(function(roster) {
    var rosterId = roster.roster_id ? roster.roster_id.toString() : "";
    if (rosterId) {
      counts[rosterId] = { current: 0, next: 0 };
    }
  });

  if (isNaN(currentYear)) return counts;

  if (pickTradingCol === -1) return counts;

  var pickTradingEnabled = settingsSheet.getRange(2, pickTradingCol + 1).getValue();
  if (pickTradingEnabled !== 1 && pickTradingEnabled !== "1") return counts;

  var draftRounds = 5;
  if (draftRoundsCol !== -1) {
    var rounds = parseInt(settingsSheet.getRange(2, draftRoundsCol + 1).getValue(), 10);
    if (!isNaN(rounds)) draftRounds = rounds;
  }

  var pickInventory = {};
  Object.keys(counts).forEach(function(rosterId) {
    for (var year = currentYear; year <= currentYear + 1; year++) {
      for (var round = 1; round <= draftRounds; round++) {
        pickInventory[year + "-" + round + "-" + rosterId] = {
          season: year,
          owner_id: rosterId
        };
      }
    }
  });

  var tradedPicks = fetchSleeperJson("https://api.sleeper.app/v1/league/" + leagueId + "/traded_picks", {
    workflow: "Rosters - Traded Picks",
    preserveLargeNumbers: true,
    leagueId: leagueId
  }) || [];

  tradedPicks.forEach(function(pick) {
    var key = pick.season + "-" + pick.round + "-" + pick.roster_id;
    if (pickInventory[key]) {
      pickInventory[key].owner_id = pick.owner_id ? pick.owner_id.toString() : pickInventory[key].owner_id;
    }
  });

  for (var key in pickInventory) {
    var pick = pickInventory[key];
    var ownerId = pick.owner_id ? pick.owner_id.toString() : "";
    if (!counts[ownerId]) continue;

    var season = parseInt(pick.season, 10);
    if (season === currentYear) counts[ownerId].current++;
    else if (season === currentYear + 1) counts[ownerId].next++;
  }

  return counts;
}

function getStarterSlotLabels(rosterPositions) {
  return rosterPositions.filter(function(position) {
    position = position ? position.toString().toUpperCase() : "";
    return position !== "BN" && position !== "IR" && position !== "TAXI";
  });
}

function uniqueStringArray(values) {
  var seen = {};
  var result = [];
  (values || []).forEach(function(value) {
    if (value === null || value === undefined || value === "") return;
    var stringValue = value.toString();
    if (!seen[stringValue]) {
      seen[stringValue] = true;
      result.push(stringValue);
    }
  });
  return result;
}

function arrayToLookup(values) {
  var lookup = {};
  (values || []).forEach(function(value) {
    if (value !== null && value !== undefined && value !== "") {
      lookup[value.toString()] = true;
    }
  });
  return lookup;
}

function getPositionBucket(position, fantasyPositions) {
  var raw = (position || fantasyPositions || "").toString().toUpperCase();
  if (raw.indexOf("QB") !== -1) return "QB";
  if (raw.indexOf("RB") !== -1) return "RB";
  if (raw.indexOf("WR") !== -1) return "WR";
  if (raw.indexOf("TE") !== -1) return "TE";
  if (raw.indexOf("DEF") !== -1) return "DEF";
  if (raw.indexOf("K") !== -1) return "K";
  return "Other";
}

function calculateCurrentAge(birthDate) {
  if (!birthDate) return "";

  try {
    var birth = new Date(birthDate);
    if (isNaN(birth.getTime())) return "";

    var today = new Date();
    var age = today.getFullYear() - birth.getFullYear();
    var monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }

    if (age < 0 || age > 100) return "";
    return age;
  } catch (error) {
    return "";
  }
}

function findHeaderIndex(headers, headerName) {
  for (var i = 0; i < headers.length; i++) {
    if (headers[i] && headers[i].toString() === headerName) {
      return i;
    }
  }
  return -1;
}

/**
 * Refresh Player Results sheet by consolidating data from all Week Data sheets
 * Replaces the slow array formula with script-generated data
 * @param {number} currentWeek - The current week number
 */
function RefreshYearlyOutput(currentWeek) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var yearlySheet = ss.getSheetByName("Player Results");

  if (!yearlySheet) {
    Logger.log("Player Results sheet not found");
    return;
  }

  // Consolidated data format (in "Week X Data" sheets):
  // Columns: Owner (A), League (B), Year (C), Week (D), Player_ID (E), Player (F), Position (G), NFL (H), Fantasy (I), Points (J), Opponent (K), Age (L), [scoring stats...]
  // Column count is dynamic based on number of scoring stats in the league

  // Get headers and column count from Week 1 Data sheet (they should all be the same)
  var week1DataSheet = ss.getSheetByName("Week 1 Data");
  var headers = [];
  var numCols = 13; // Default to base 13 columns if Week 1 Data doesn't exist

  if (week1DataSheet && week1DataSheet.getLastRow() > 0) {
    var lastColWeek1 = week1DataSheet.getLastColumn();
    headers = week1DataSheet.getRange(1, 1, 1, lastColWeek1).getValues()[0];
    numCols = headers.length;
    Logger.log("Player Results will have " + numCols + " columns (13 base + " + (numCols - 13) + " stat columns)");
  } else {
    // Fallback headers if Week 1 Data doesn't exist
    headers = ["Owner", "League", "Year", "Week", "Player_ID", "Player", "Position", "NFL", "Fantasy", "Points", "Projected", "Opponent", "Age"];
    Logger.log("Week 1 Data not found, using default 13 columns");
  }

  // Clear existing data in Player Results (only content, not formatting)
  var maxRows = yearlySheet.getMaxRows();
  var maxCols = yearlySheet.getMaxColumns();
  if (maxRows > 0 && maxCols > 0) {
    yearlySheet.getRange(1, 1, maxRows, maxCols).clearContent();
  }

  // Always write header row
  if (headers.length > 0) {
    ensureSheetSize(yearlySheet, 1, headers.length);
    yearlySheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    yearlySheet.getRange(1, 1, 1, headers.length).setFontWeight("bold");
  }

  // Process and write data in batches to avoid timeout
  // Instead of collecting ALL data then writing, we'll write each week as we go
  var currentRow = 2; // Start writing at row 2 (after header)
  var totalRows = 0;

  for (var week = 1; week <= currentWeek; week++) {
    var weekDataSheet = ss.getSheetByName("Week " + week + " Data");
    if (!weekDataSheet) continue;

    var lastRow = weekDataSheet.getLastRow();
    if (lastRow < 2) continue; // No data rows (row 1 is header, 2+ is data)

    // Get all columns dynamically based on the sheet's column count
    var lastColThisWeek = weekDataSheet.getLastColumn();
    var weekData = weekDataSheet.getRange(2, 1, lastRow - 1, lastColThisWeek).getValues();

    // Filter where column J (index 9, "Points") is not null/empty
    var filteredWeekData = [];
    for (var i = 0; i < weekData.length; i++) {
      if (weekData[i][9] !== null && weekData[i][9] !== "" && weekData[i][9] !== undefined) {
        // Trim last 7 characters from League column (index 1) - removes " - 2024" suffix
        if (weekData[i][1] && typeof weekData[i][1] === 'string' && weekData[i][1].length > 7) {
          weekData[i][1] = weekData[i][1].slice(0, -7);
        }
        filteredWeekData.push(weekData[i]);
      }
    }

    // Write this week's data immediately
    if (filteredWeekData.length > 0) {
      ensureSheetSize(yearlySheet, currentRow + filteredWeekData.length - 1, filteredWeekData[0].length);
      yearlySheet.getRange(currentRow, 1, filteredWeekData.length, filteredWeekData[0].length).setValues(filteredWeekData);
      currentRow += filteredWeekData.length;
      totalRows += filteredWeekData.length;
    }
  }

  Logger.log("Player Results updated with " + totalRows + " rows from weeks 1-" + currentWeek);
}

/**
 * =====================================================
 * BATCH PROCESSING - Large League Alternate Step 2
 * =====================================================
 * These functions split Step 2 into 3 smaller batches for large leagues
 * where the full Step 2 would time out.
 */

/**
 * Large League Processing - Batch 1/3
 * Gathers weekly raw data from Sleeper API
 * Used when Step 2 times out due to large league size
 */
function LargeLeagueProcessing_StartBatch1() {
  var workflowStartTime = new Date();
  var leagueId = "";
  var workflowLock = acquireWorkflowLock("Large League Batch 1/3");
  if (!workflowLock) return;

  try {
    recordDiagnostics("Large League Batch 1/3", "Started", workflowStartTime);
    var ui = SpreadsheetApp.getUi();

    // Show explanation dialog
    var response = ui.alert(
      'Large League Processing',
      'This option is for large leagues where Step 2 times out.\n\n' +
      'Processing will be split into 3 batches:\n' +
      '• Batch 1/3: Gather weekly data from Sleeper\n' +
      '• Batch 2/3: Process weeks + generate derived data\n' +
      '• Batch 3/3: Player Results, Awards, and final cleanup\n\n' +
      'Ready to proceed with Batch 1/3?',
      ui.ButtonSet.OK_CANCEL
    );

    if (response !== ui.Button.OK) {
      return; // User cancelled
    }

    // Run Batch 1 (same as Step 2A)
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var currentWeek = infoSheet.getRange("B3").getValue();

    if (!currentWeek) {
      throw new Error("Please enter the current week in Info!B3");
    }

    // Clear all output sheets to ensure a fresh start (matches main Step 2 logic)
    ClearAllOutputSheets();

    leagueId = GetSelectedLeagueId();
    var errors = RefreshWeeklyRawData(leagueId, currentWeek);
    SpreadsheetApp.flush();

    if (errors.length === 0) {
      recordDiagnostics("Large League Batch 1/3", "Completed", workflowStartTime, null, null, leagueId);
      ui.alert(
        'Batch 1/3 Complete',
        'Weekly data has been gathered from Sleeper.\n\n' +
        'Next step: Run "Large League Processing - Batch 2/3" from the Custom Menu.',
        ui.ButtonSet.OK
      );
    } else {
      recordDiagnostics("Large League Batch 1/3", "Completed with Errors", workflowStartTime, null, errors, leagueId);
      ui.alert(
        'Batch 1/3 Completed with Errors',
        'Some data may not have processed properly:\n\n' + errors.join('\n') + '\n\n' +
        'Next step: Run "Large League Processing - Batch 2/3" from the Custom Menu.',
        ui.ButtonSet.OK
      );
    }

  } catch (error) {
    SpreadsheetApp.flush();
    recordDiagnostics("Large League Batch 1/3", "Failed", workflowStartTime, null, error.toString(), leagueId);
    SpreadsheetApp.getUi().alert('Error in Batch 1/3', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  } finally {
    workflowLock.releaseLock();
  }
}

/**
 * Large League Processing - Batch 2/3
 * Processes all weekly data (weeks 1-18) and generates derived data
 * (Transactions, Standings, Draft, Schedule, Playoffs, Owned Draft Picks)
 */
function LargeLeagueProcessing_Batch2() {
  var workflowStartTime = new Date();
  var leagueId = "";
  var workflowLock = acquireWorkflowLock("Large League Batch 2/3");
  if (!workflowLock) return;

  try {
    recordDiagnostics("Large League Batch 2/3", "Started", workflowStartTime);
    var ui = SpreadsheetApp.getUi();

    // Show explanation dialog
    var response = ui.alert(
      'Large League Processing - Batch 2/3',
      'This will process all weekly data and generate derived data:\n' +
      '• Process weeks 1-18\n' +
      '• Transactions, Standings, Draft\n' +
      '• Schedule, Playoffs, Owned Draft Picks\n\n' +
      'Make sure you have completed Batch 1/3 first.\n\n' +
      'Ready to proceed with Batch 2/3?',
      ui.ButtonSet.OK_CANCEL
    );

    if (response !== ui.Button.OK) {
      return; // User cancelled
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var currentWeek = infoSheet.getRange("B3").getValue();

    if (!currentWeek) {
      throw new Error("Please enter the current week in Info!B3");
    }

    leagueId = GetSelectedLeagueId();
    var errors = [];

    // ===== PROCESS WEEKLY DATA (Weeks 1-9) =====
    var weeks1to9StartTime = new Date();
    Logger.log("TIMER: Processing weeks 1-9 at " + weeks1to9StartTime.toISOString());
    try {
      var weekErrors1 = ProcessWeeklyData_Part1(currentWeek);
      errors = errors.concat(weekErrors1);
      var weeks1to9EndTime = new Date();
      Logger.log("TIMER: Weeks 1-9 completed in " + ((weeks1to9EndTime - weeks1to9StartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Weeks 1-9: " + error.toString());
    }

    SpreadsheetApp.flush();

    // ===== PROCESS WEEKLY DATA (Weeks 10-18) =====
    var weeks10to18StartTime = new Date();
    Logger.log("TIMER: Processing weeks 10-18 at " + weeks10to18StartTime.toISOString());
    try {
      var weekErrors2 = ProcessWeeklyData_Part2(currentWeek);
      errors = errors.concat(weekErrors2);
      var weeks10to18EndTime = new Date();
      Logger.log("TIMER: Weeks 10-18 completed in " + ((weeks10to18EndTime - weeks10to18StartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Weeks 10-18: " + error.toString());
    }

    SpreadsheetApp.flush();

    // ===== TRANSACTIONS =====
    var transactionsStartTime = new Date();
    Logger.log("TIMER: Refreshing Transactions at " + transactionsStartTime.toISOString());
    try {
      var transactionsData = ImportSleeperTransactions(leagueId, currentWeek, true);
      var transactionsSheet = ss.getSheetByName("Transactions");
      if (transactionsSheet && transactionsData && transactionsData.length > 0) {
        var rowsToWrite = transactionsData.length;
        var lastRow = transactionsSheet.getLastRow();

      if (lastRow > 0) {
        transactionsSheet.getRange(1, 1, lastRow, 9).clearContent();
      }

      var requiredCols = transactionsData[0].length;
      ensureSheetSize(transactionsSheet, rowsToWrite, requiredCols);

        transactionsSheet.getRange(1, 1, rowsToWrite, requiredCols).setValues(transactionsData);
        transactionsSheet.getRange(1, 1, rowsToWrite, requiredCols).setHorizontalAlignment("center");
        transactionsSheet.autoResizeColumns(1, requiredCols);
      }
      var transactionsEndTime = new Date();
      Logger.log("TIMER: Transactions completed in " + ((transactionsEndTime - transactionsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Transactions: " + error.toString());
    }

    SpreadsheetApp.flush(); // Ensure transactions are written before Standings reads them


    // ===== STANDINGS AND WEEKLY RESULTS =====
    var standingsStartTime = new Date();
    Logger.log("TIMER: Refreshing Standings/Weekly Results at " + standingsStartTime.toISOString());
    try {
      var calculatedData = CalculateDetailedStandings(currentWeek);

      var standingsSheet = ss.getSheetByName("Standings");
      if (standingsSheet && calculatedData.standingsData && calculatedData.standingsData.length > 0) {
        standingsSheet.clear();

        var requiredCols = calculatedData.standingsData[0].length;
        ensureSheetSize(standingsSheet, calculatedData.standingsData.length, requiredCols);

        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, requiredCols).setValues(calculatedData.standingsData);
        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, requiredCols).setHorizontalAlignment("center");
        standingsSheet.autoResizeColumns(1, requiredCols);
      }

      var weeklyResultsSheet = ss.getSheetByName("Weekly Results");
      if (weeklyResultsSheet && calculatedData.weeklyResultsData && calculatedData.weeklyResultsData.length > 0) {
        weeklyResultsSheet.clear();

        var requiredCols = calculatedData.weeklyResultsData[0].length;
        ensureSheetSize(weeklyResultsSheet, calculatedData.weeklyResultsData.length, requiredCols);

        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, requiredCols).setValues(calculatedData.weeklyResultsData);
        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, requiredCols).setHorizontalAlignment("center");
        weeklyResultsSheet.autoResizeColumns(1, requiredCols);
      }
      var standingsEndTime = new Date();
      Logger.log("TIMER: Standings/Weekly Results completed in " + ((standingsEndTime - standingsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Standings/Weekly Results: " + error.toString());
    }

    // ===== DRAFT RESULT =====
    var draftStartTime = new Date();
    Logger.log("TIMER: Refreshing Draft Result at " + draftStartTime.toISOString());
    try {
      var draftData = ImportDraft();
      var draftSheet = ss.getSheetByName("Draft Result");
      if (draftSheet && draftData && draftData.length > 0) {
        draftSheet.clear();

        var requiredCols = draftData[0].length;
        ensureSheetSize(draftSheet, draftData.length, requiredCols);

        draftSheet.getRange(1, 1, draftData.length, requiredCols).setValues(draftData);
        draftSheet.getRange(1, 1, draftData.length, requiredCols).setHorizontalAlignment("center");
        draftSheet.autoResizeColumns(1, requiredCols);
      }
      var draftEndTime = new Date();
      Logger.log("TIMER: Draft Result completed in " + ((draftEndTime - draftStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Draft Result: " + error.toString());
    }

    // ===== SCHEDULE =====
    var settingsSheet = ss.getSheetByName("Settings");
    var playoffStartWeek = settingsSheet.getRange("A6").getValue();
    var regularSeasonEnd = playoffStartWeek ? playoffStartWeek - 1 : 14;

    var scheduleStartTime = new Date();
    Logger.log("TIMER: Refreshing Schedule at " + scheduleStartTime.toISOString());
    try {
      if (!RefreshScheduleData(leagueId, regularSeasonEnd)) {
        errors.push("Schedule: No data refreshed");
      }
      var scheduleEndTime = new Date();
      Logger.log("TIMER: Schedule completed in " + ((scheduleEndTime - scheduleStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Schedule: " + error.toString());
    }

    // ===== PLAYOFFS =====
    var playoffsStartTime = new Date();
    Logger.log("TIMER: Refreshing Playoffs at " + playoffsStartTime.toISOString());
    try {
      if (currentWeek >= playoffStartWeek) {
        if (!ImportPlayoffBrackets(leagueId)) {
          errors.push("Playoffs: No data refreshed");
        }
      } else {
        Logger.log("Playoffs not started yet (current week " + currentWeek + " < playoff start " + playoffStartWeek + ")");
      }
      var playoffsEndTime = new Date();
      Logger.log("TIMER: Playoffs completed in " + ((playoffsEndTime - playoffsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Playoffs: " + error.toString());
    }

    // ===== OWNED DRAFT PICKS =====
    var draftPicksStartTime = new Date();
    Logger.log("TIMER: Refreshing Owned Draft Picks at " + draftPicksStartTime.toISOString());
    try {
      var draftPicksData = ImportDraftPickInventory();
      var draftPicksSheet = ss.getSheetByName("Owned Draft Picks");
      if (draftPicksSheet && draftPicksData && draftPicksData.length > 0) {
        draftPicksSheet.clear();
        ensureSheetSize(draftPicksSheet, draftPicksData.length, draftPicksData[0].length);
        draftPicksSheet.getRange(1, 1, draftPicksData.length, draftPicksData[0].length).setValues(draftPicksData);
        draftPicksSheet.getRange(1, 1, draftPicksData.length, draftPicksData[0].length).setHorizontalAlignment("center");

        if (draftPicksData.length > 1 && draftPicksData[0][0] === "Team") {
          draftPicksSheet.getRange(1, 1, 1, draftPicksData[0].length).setFontWeight("bold");
        }

        draftPicksSheet.autoResizeColumns(1, draftPicksData[0].length);
      }
      var draftPicksEndTime = new Date();
      Logger.log("TIMER: Owned Draft Picks completed in " + ((draftPicksEndTime - draftPicksStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Owned Draft Picks: " + error.toString());
    }

    SpreadsheetApp.flush();
    autoResizeGeneratedOutputSheets(["Transactions", "Standings", "Weekly Results", "Draft Result", "Schedule", "Playoffs", "Owned Draft Picks"]);

    if (errors.length === 0) {
      recordDiagnostics("Large League Batch 2/3", "Completed", workflowStartTime, null, null, leagueId);
      ui.alert(
        'Batch 2/3 Complete',
        'Weekly data and derived data have been processed.\n\n' +
        'Next step: Run "Large League Processing - Batch 3/3" from the Custom Menu.',
        ui.ButtonSet.OK
      );
    } else {
      recordDiagnostics("Large League Batch 2/3", "Completed with Errors", workflowStartTime, null, errors, leagueId);
      ui.alert(
        'Batch 2/3 Completed with Errors',
        'Some data may not have processed properly:\n\n' + errors.join('\n') + '\n\n' +
        'Next step: Run "Large League Processing - Batch 3/3" from the Custom Menu.',
        ui.ButtonSet.OK
      );
    }

  } catch (error) {
    SpreadsheetApp.flush();
    recordDiagnostics("Large League Batch 2/3", "Failed", workflowStartTime, null, error.toString(), leagueId);
    SpreadsheetApp.getUi().alert('Error in Batch 2/3', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  } finally {
    workflowLock.releaseLock();
  }
}

/**
 * Large League Processing - Batch 3/3
 * Generates Player Results, Awards, and performs final cleanup
 * This matches the functionality of RefreshPlayerResultsManual() in Step 2
 */
function LargeLeagueProcessing_Batch3() {
  var workflowStartTime = new Date();
  var workflowLock = acquireWorkflowLock("Large League Batch 3/3");
  if (!workflowLock) return;

  try {
    recordDiagnostics("Large League Batch 3/3", "Started", workflowStartTime);
    var ui = SpreadsheetApp.getUi();

    // Show explanation dialog
    var response = ui.alert(
      'Large League Processing - Batch 3/3',
      'This will generate Player Results and Awards data:\n' +
      '• Player Results (consolidates all weeks)\n' +
      '• Re-run Standings and Weekly Results\n' +
      '• Awards\n' +
      '• Final sheet cleanup\n\n' +
      'Make sure you have completed Batch 1/3 and Batch 2/3 first.\n\n' +
      'Ready to proceed with Batch 3/3 (final step)?',
      ui.ButtonSet.OK_CANCEL
    );

    if (response !== ui.Button.OK) {
      return; // User cancelled
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var currentWeek = infoSheet.getRange("B3").getValue();

    if (!currentWeek) {
      throw new Error("Please enter the current week in Info!B3");
    }

    var errors = [];
    var startTime = new Date();
    Logger.log("=== BATCH 3/3 START: Player Results refresh ===");

    // ===== PLAYER RESULTS =====
    var playerResultsStartTime = new Date();
    Logger.log("TIMER: Refreshing Player Results at " + playerResultsStartTime.toISOString());
    try {
      RefreshYearlyOutput(currentWeek);
      var playerResultsEndTime = new Date();
      Logger.log("TIMER: Player Results completed in " + ((playerResultsEndTime - playerResultsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Player Results: " + error.toString());
    }

    SpreadsheetApp.flush();

    // ===== RE-RUN STANDINGS AND WEEKLY RESULTS =====
    // These depend on Player Results, so we re-run after Player Results completes
    var standingsStartTime = new Date();
    Logger.log("TIMER: Re-refreshing Standings/Weekly Results at " + standingsStartTime.toISOString());
    try {
      var calculatedData = CalculateDetailedStandings(currentWeek);

      var standingsSheet = ss.getSheetByName("Standings");
      if (standingsSheet && calculatedData.standingsData && calculatedData.standingsData.length > 0) {
        standingsSheet.clear();
        ensureSheetSize(standingsSheet, calculatedData.standingsData.length, calculatedData.standingsData[0].length);
        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, calculatedData.standingsData[0].length).setValues(calculatedData.standingsData);
        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, calculatedData.standingsData[0].length).setHorizontalAlignment("center");
        standingsSheet.autoResizeColumns(1, calculatedData.standingsData[0].length);
      }

      var weeklyResultsSheet = ss.getSheetByName("Weekly Results");
      if (weeklyResultsSheet && calculatedData.weeklyResultsData && calculatedData.weeklyResultsData.length > 0) {
        weeklyResultsSheet.clear();
        ensureSheetSize(weeklyResultsSheet, calculatedData.weeklyResultsData.length, calculatedData.weeklyResultsData[0].length);
        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, calculatedData.weeklyResultsData[0].length).setValues(calculatedData.weeklyResultsData);
        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, calculatedData.weeklyResultsData[0].length).setHorizontalAlignment("center");
        weeklyResultsSheet.autoResizeColumns(1, calculatedData.weeklyResultsData[0].length);
      }
      var standingsEndTime = new Date();
      Logger.log("TIMER: Standings/Weekly Results completed in " + ((standingsEndTime - standingsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Standings/Weekly Results re-run: " + error.toString());
    }

    // ===== AWARDS =====
    var awardsStartTime = new Date();
    Logger.log("TIMER: Refreshing Awards at " + awardsStartTime.toISOString());
    try {
      var awardsData = CalculateAwards(currentWeek);
      var awardsSheet = ss.getSheetByName("Awards");
      if (awardsSheet && awardsData && awardsData.length > 0) {
        awardsSheet.clear();
        ensureSheetSize(awardsSheet, awardsData.length, awardsData[0].length);
        awardsSheet.getRange(1, 1, awardsData.length, awardsData[0].length).setValues(awardsData);

        // Center align all data
        awardsSheet.getRange(1, 1, awardsData.length, 5).setHorizontalAlignment("center");

        // Format section headers and sub-headers
        for (var i = 0; i < awardsData.length; i++) {
          var cellValue = awardsData[i][0] ? awardsData[i][0].toString() : "";

          // Section headers (INDIVIDUAL PLAYER AWARDS, TEAM AWARDS, SEASON-LONG AWARDS)
          if (cellValue === "INDIVIDUAL PLAYER AWARDS" || cellValue === "TEAM AWARDS" || cellValue === "SEASON-LONG AWARDS") {
            var headerRange = awardsSheet.getRange(i + 1, 1, 1, 5);
            headerRange.merge();
            headerRange.setFontWeight("bold");
            headerRange.setBackground("#4a86e8");
            headerRange.setFontColor("#ffffff");
            headerRange.setHorizontalAlignment("center");
          }

          // Sub-headers (Award, Player, Position, etc.)
          if (cellValue === "Award") {
            awardsSheet.getRange(i + 1, 1, 1, 5).setFontWeight("bold").setBackground("#d9d9d9");
          }
        }

        // Auto-fit columns
        awardsSheet.autoResizeColumns(1, 5);
      }
      var awardsEndTime = new Date();
      Logger.log("TIMER: Awards completed in " + ((awardsEndTime - awardsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Awards: " + error.toString());
    }

    SpreadsheetApp.flush();

    // ===== FINAL CLEANUP =====
    TrimAllSheets();
    autoResizeGeneratedOutputSheets();

    var endTime = new Date();
    var duration = (endTime - startTime) / 1000;
    Logger.log("=== BATCH 3/3 COMPLETE: Total duration " + duration + " seconds ===");

    if (errors.length === 0) {
      recordDiagnostics("Large League Batch 3/3", "Completed", workflowStartTime);
      ui.alert(
        'Batch 3/3 Complete',
        'Player Results and Awards have been generated.\n\n' +
        'Your league data is now fully refreshed!',
        ui.ButtonSet.OK
      );
    } else {
      recordDiagnostics("Large League Batch 3/3", "Completed with Errors", workflowStartTime, null, errors);
      ui.alert(
        'Batch 3/3 Completed with Errors',
        'Some data may not have processed properly:\n\n' + errors.join('\n'),
        ui.ButtonSet.OK
      );
    }

  } catch (error) {
    SpreadsheetApp.flush();
    recordDiagnostics("Large League Batch 3/3", "Failed", workflowStartTime, null, error.toString());
    SpreadsheetApp.getUi().alert('Error in Batch 3/3', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  } finally {
    workflowLock.releaseLock();
  }
}

/**
 * =====================================================
 * WEEKLY DATA - Weekly Data Processing Functions
 * =====================================================
 * Functions for consolidating weekly matchup data,
 * processing transactions, and managing weekly stats.
 */

/**
 * Consolidate weekly data tables into one unified table with stats
 * Reads from Week X sheet:
 *   - Row 1+: Roster data (A=Roster, B=Roster_ID, C=/players, D=/starters, E+=individual player IDs)
 *   - Row 35+: Player points (A=Points, B=roster_id, C-D=blank, E+=points per player)
 *   - Row 137+: Player positions (formula-driven by user, E+=positions like "RB", "FLEX", etc.)
 *   - Row 171+: Matchup table (A=team name, B=roster_id, C=matchup_id)
 * Writes to "Week X Data" sheet starting at row 1 with columns A:L + dynamic stat columns
 * @param {number} week - The week number to process
 * @param {Array} scoringStats - Pre-built array of scoring stat names (optional, will build if not provided)
 * @param {boolean} includeTeamDef - Whether to include team defenses (optional, will check if not provided)
 * @param {Object} playerLookup - Pre-built player lookup object (optional, will build if not provided)
 * @param {Object} passedStats - Pre-fetched weekly stats object (optional, to avoid re-fetching)
 * @param {Object} passedProjections - Pre-fetched weekly projections object (optional)
 * @param {Object} scoringMultipliers - Pre-fetched scoring multipliers (optional, required if calculating projections)
 */
function ConsolidateWeeklyTables(week, scoringStats, includeTeamDef, playerLookup, passedStats, passedProjections, scoringMultipliers) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var weekSheet = ss.getSheetByName("Week " + week);
  var weekDataSheet = ss.getSheetByName("Week " + week + " Data");
  var infoSheet = ss.getSheetByName("Info");

  if (!weekSheet) {
    Logger.log("Week " + week + " sheet not found");
    return;
  }

  if (!weekDataSheet) {
    Logger.log("Week " + week + " Data sheet not found");
    return;
  }

  if (!infoSheet) {
    Logger.log("Info sheet not found");
    return;
  }

  Logger.log("Starting consolidation for Week " + week);

  // Get league name and year from Info sheet
  var leagueName = infoSheet.getRange("B4").getValue() || "";
  var year = infoSheet.getRange("B2").getValue() || "";

  // PERFORMANCE OPTIMIZATION: Use provided lookups if available, otherwise build them
  // This allows the caller to build once and reuse for multiple weeks
  if (!scoringStats) {
    scoringStats = buildSortedScoringStats();
  }
  if (includeTeamDef === undefined || includeTeamDef === null) {
    includeTeamDef = hasTeamDefenses();
  }
  if (!playerLookup) {
    playerLookup = buildPlayerLookup();
  }
  if (!scoringMultipliers) {
    scoringMultipliers = getScoringMultipliers();
  }

  // Read the tables from Week X sheet
  // Table 1 (Row 1+): Roster, Roster_ID, /players, /starters, player IDs...
  var lastCol = weekSheet.getLastColumn();
  var table1Data = weekSheet.getRange(2, 1, 32, lastCol).getValues(); // 32 teams max, starting from data row (row 1 is header)

  // Table 2 (Row 35+): Points, roster_id, [blank], [blank], points per player...
  var table2Data = weekSheet.getRange(36, 1, 32, lastCol).getValues(); // 32 teams max, starting from data row

  // Table 3 (Row 137+): Player positions (formula-driven by user)
  var table3Data = weekSheet.getRange(138, 1, 32, lastCol).getValues(); // 32 teams max, starting from data row

  // Table 4 (Row 171+): Matchup data (team name, roster_id, matchup_id)
  // Read up to 32 teams
  var matchupData = weekSheet.getRange(172, 1, 32, 3).getValues();

  // Build matchup lookup: roster_id -> {opponent, matchup_id}
  var matchupLookup = {};
  var matchupTeams = {}; // matchup_id -> array of {rosterId, teamName}

  matchupData.forEach(function(row) {
    var teamName = row[0];
    var rosterId = row[1];
    var matchupId = row[2];

    if (rosterId && matchupId) {
      var rosterIdStr = rosterId.toString();
      var matchupIdStr = matchupId.toString();

      if (!matchupTeams[matchupIdStr]) {
        matchupTeams[matchupIdStr] = [];
      }
      matchupTeams[matchupIdStr].push({rosterId: rosterIdStr, teamName: teamName});
    }
  });

  // Build opponent lookup
  for (var matchupId in matchupTeams) {
    var teams = matchupTeams[matchupId];
    if (teams.length === 2) {
      matchupLookup[teams[0].rosterId] = teams[1].teamName;
      matchupLookup[teams[1].rosterId] = teams[0].teamName;
    }
  }

  // Fetch weekly stats from API (if not already passed)
  var weeklyStats = passedStats || fetchWeeklyStats(year, week, includeTeamDef);

  // Fetch weekly projections from API (if not already passed)
  var weeklyProjections = passedProjections || fetchWeeklyProjections(year, week);

  // Build consolidated output
  var outputData = [];

  // Build header row: base columns + PROJECTED + stats
  // Original: "Owner", "League", "Year", "Week", "Player_ID", "Player", "Position", "NFL", "Fantasy", "Points", "Opponent", "Age"
  // New: "Owner", "League", "Year", "Week", "Player_ID", "Player", "Position", "NFL", "Fantasy", "Points", "Projected", "Opponent", "Age"
  var headerRow = ["Owner", "League", "Year", "Week", "Player_ID", "Player", "Position", "NFL", "Fantasy", "Points", "Projected", "Opponent", "Age"];
  
  // Add scoring stat column headers
  scoringStats.forEach(function(statObj) {
    headerRow.push(statObj.label);
  });
  outputData.push(headerRow);

  // Process each team/roster
  for (var i = 0; i < table1Data.length; i++) {
    var owner = table1Data[i][0]; // Column A: Roster (team name)
    var rosterId = table1Data[i][1]; // Column B: Roster_ID
    // Column C: /players (comma-separated list)
    // Column D: /starters (comma-separated list)
    // Columns E+: Individual player IDs

    // Skip if no owner (empty row)
    if (!owner || owner === "") continue;

    var rosterIdStr = rosterId ? rosterId.toString() : "";
    var opponent = matchupLookup[rosterIdStr] || "";

    // Process each player (columns E onwards, which is index 4+)
    // Table 1 has: A=Roster, B=Roster_ID, C=/players, D=/starters, E+=player IDs
    for (var col = 4; col < table1Data[i].length; col++) {
      var playerId = table1Data[i][col];

      // Skip if no player ID
      if (!playerId || playerId === "") continue;

      var playerIdStr = playerId.toString();
      var points = table2Data[i][col];
      var fantasyPosition = table3Data[i][col]; // Fantasy assignment for the week (from user formulas)

      // Default points to 0 if player exists but no points recorded
      if (points === "" || points === null || points === undefined) {
        points = 0;
      }

      // Calculate projected points
      var projPoints = 0;
      if (weeklyProjections[playerIdStr] && weeklyProjections[playerIdStr].stats) {
        projPoints = calculateFantasyPoints(weeklyProjections[playerIdStr].stats, scoringMultipliers);
      }

      // Get player info from lookup
      var playerInfo = playerLookup[playerIdStr] || {
        name: "",
        fantasyPositions: "",
        team: "",
        birthDate: ""
      };

      // Calculate age from birth date
      var age = "";
      if (playerInfo.fantasyPositions === "DEF") {
        age = "0";
      } else if (playerInfo.birthDate) {
        try {
          var birthDate = new Date(playerInfo.birthDate);
          var today = new Date();

          // Calculate age
          var calculatedAge = today.getFullYear() - birthDate.getFullYear();
          var monthDiff = today.getMonth() - birthDate.getMonth();
          if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            calculatedAge--;
          }

          // Adjust for year difference (year from Info sheet vs current year)
          if (year) {
            var yearDiff = today.getFullYear() - parseInt(year);
            calculatedAge = calculatedAge - yearDiff;
          }

          // If age is over 100 or negative, leave blank (likely bad data)
          if (calculatedAge > 100 || calculatedAge < 0) {
            age = "";
          } else {
            age = calculatedAge;
          }
        } catch (e) {
          age = ""; // If date parsing fails, leave blank
        }
      }

      // Create row with base columns including Projected
      var outputRow = [
        owner,                        // Column A: Owner
        leagueName,                   // Column B: League
        year,                         // Column C: Year
        week,                         // Column D: Week
        playerIdStr,                  // Column E: Player_ID
        playerInfo.name,              // Column F: Player
        playerInfo.fantasyPositions,  // Column G: Position (NFL position from Players sheet column D)
        playerInfo.team,              // Column H: NFL (team)
        fantasyPosition || "",        // Column I: Fantasy (weekly fantasy assignment)
        points,                       // Column J: Points (defaults to 0 if blank)
        projPoints,                   // Column K: Projected (calculated)
        opponent,                     // Column L: Opponent
        age                           // Column M: Age
      ];

      // Add stat values for this player
      var playerStats = weeklyStats[playerIdStr] || {};
      scoringStats.forEach(function(statObj) {
        var statValue = playerStats[statObj.key];
        // Default to 0 if stat is missing or undefined
        if (statValue === null || statValue === undefined || statValue === "") {
          outputRow.push(0);
        } else {
          outputRow.push(statValue);
        }
      });

      outputData.push(outputRow);
    }
  }

  // Clear existing data in Week X Data sheet
  var maxRows = weekDataSheet.getMaxRows();
  var maxCols = weekDataSheet.getMaxColumns();
  if (maxRows > 0 && maxCols > 0) {
      // Filter out empty ranges to prevent errors
     weekDataSheet.clear(); 
  }

  // Write consolidated data to Week X Data sheet starting at row 1
  if (outputData.length > 0) {
    // Ensure sheet is large enough
    var requiredRows = outputData.length;
    var requiredCols = outputData[0].length;
    ensureSheetSize(weekDataSheet, requiredRows, requiredCols);

    weekDataSheet.getRange(1, 1, requiredRows, requiredCols).setValues(outputData);

    // Format header row
    weekDataSheet.getRange(1, 1, 1, outputData[0].length).setFontWeight("bold");

    // Center align all data
    weekDataSheet.getRange(1, 1, outputData.length, outputData[0].length).setHorizontalAlignment("center");

    Logger.log("Week " + week + ": Consolidated " + (outputData.length - 1) + " player rows to Week " + week + " Data sheet");
  } else {
    Logger.log("Week " + week + ": No consolidated data generated");
  }
}

/**
 * Step 2B: Process Weekly Data (Weeks 1-9)
 * Slow operation - consolidates raw data, fetches stats, and writes to Week Data sheets
 */
function ProcessWeeklyData_Part1(currentWeek) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var errors = [];
    var year = ss.getSheetByName("Info").getRange("B2").getValue();

    // Build lookups once before processing all weeks
    Logger.log("Building shared lookups (scoring stats, player data, team defense check)...");
    var scoringStats = buildSortedScoringStats();
    var includeTeamDef = hasTeamDefenses();
    var playerLookup = buildPlayerLookup();
    var rosterPositions = getLeagueRosterPositions();
    var scoringMultipliers = getScoringMultipliers();
    Logger.log("Shared lookups built. Processing weeks 1-9...");

    // Initialize Free Agents sheet
    var freeAgentsSheet = ss.getSheetByName("Free Agents");
    var totalFreeAgentsRows = 0;
    
    if (freeAgentsSheet) {
      freeAgentsSheet.clear();
      // Build header row for Free Agents
      var faHeader = ["Week", "Player_ID", "Player", "Position", "NFL Team", "Fantasy Points", "Projected"];
      scoringStats.forEach(function(s) { faHeader.push(s.label); });
      ensureSheetSize(freeAgentsSheet, 1, faHeader.length);
      freeAgentsSheet.getRange(1, 1, 1, faHeader.length).setValues([faHeader]);
      freeAgentsSheet.setFrozenRows(1);
    }

    // Process weeks 1-9
    var endWeek = Math.min(currentWeek, 9);
    for (var week = 1; week <= endWeek; week++) {
      try {
        var weekSheet = ss.getSheetByName("Week " + week);
        if (weekSheet) {
          Logger.log("Processing Week " + week + "...");

          // 1. Fetch Stats & Projections
          var weeklyStats = fetchWeeklyStats(year, week, includeTeamDef);
          var weeklyProjections = fetchWeeklyProjections(year, week);

          // 2. Consolidate Weekly Tables
          try {
            ConsolidateWeeklyTables(week, scoringStats, includeTeamDef, playerLookup, weeklyStats, weeklyProjections, scoringMultipliers);
          } catch (consolidateError) {
            Logger.log("Week " + week + " consolidation error: " + consolidateError.toString());
            errors.push("Week " + week + " consolidation: " + consolidateError.toString());
          }

          // 3. Process Free Agents (if sheet exists)
          if (freeAgentsSheet) {
            // Rebuild ownership lookup from the Week sheet (since we don't have json data here)
            var ownershipLookup = {};
            // Read Table 1: Row 2-33 (approx), Col 1 (Roster), Col 2 (RosterID), Col 5+ (Players)
            var lastCol = weekSheet.getLastColumn();
            var rosterRows = weekSheet.getRange(2, 1, 32, lastCol).getValues();
            
            rosterRows.forEach(function(row) {
              var ownerName = row[0]; // Tab 1 Col A: Roster Name
              var rosterId = row[1];  // Tab 1 Col B: Roster ID
              if (rosterId) {
                 // Players start at index 4 (Col E)
                 for (var c = 4; c < row.length; c++) {
                   var pid = row[c];
                   if (pid) {
                     ownershipLookup[pid.toString()] = { owner: ownerName, rosterId: rosterId };
                   }
                 }
              }
            });

            var faRows = processFreeAgentsForWeek(week, weeklyStats, weeklyProjections, playerLookup, scoringStats, rosterPositions, scoringMultipliers, ownershipLookup);
            
            if (faRows.length > 0) {
              // Bulk write for this week
              var startRow = totalFreeAgentsRows + 2; // +1 for header, +1 for 1-based index
              
              // Ensure sheet matches output dimensions
              var requiredCols = faRows[0].length;
              ensureSheetSize(freeAgentsSheet, startRow + faRows.length - 1, requiredCols);

              freeAgentsSheet.getRange(startRow, 1, faRows.length, faRows[0].length).setValues(faRows);
              totalFreeAgentsRows += faRows.length;
            }
          }

          Logger.log("Week " + week + " processing complete");

          // Small delay to avoid rate limiting
          sleepForSleeperRateLimit(100);
        }
      } catch (error) {
        errors.push("Week " + week + " processing: " + error.toString());
      }
    }

    if (currentWeek <= 9) {
      // Auto-resize Free Agents columns at the end if done
      if (freeAgentsSheet && totalFreeAgentsRows > 0) {
        freeAgentsSheet.autoResizeColumns(1, 7 + scoringStats.length);
      }
      Logger.log("Weekly data processing complete (weeks 1-" + currentWeek + ").");
    } else {
      Logger.log("Part 1 processing complete (weeks 1-9). Run Step 2C to process weeks 10-" + currentWeek + ".");
    }
    return errors;

  } catch (error) {
    throw new Error("Error processing weekly data (Part 1): " + error.toString());
  }
}

/**
 * Step 2C: Process Weekly Data (Weeks 10-18)
 * Slow operation - consolidates raw data, fetches stats, and writes to Week Data sheets
 */
function ProcessWeeklyData_Part2(currentWeek) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var errors = [];
    var year = ss.getSheetByName("Info").getRange("B2").getValue();

    // Build lookups once before processing all weeks
    Logger.log("Building shared lookups (scoring stats, player data, team defense check)...");
    var scoringStats = buildSortedScoringStats();
    var includeTeamDef = hasTeamDefenses();
    var playerLookup = buildPlayerLookup();
    var rosterPositions = getLeagueRosterPositions();
    var scoringMultipliers = getScoringMultipliers();
    Logger.log("Shared lookups built. Processing weeks 10-" + currentWeek + "...");

    // Get Free Agents sheet for appending
    var freeAgentsSheet = ss.getSheetByName("Free Agents");

    // Process weeks 10-18 (or through currentWeek)
    var startWeek = 10;
    for (var week = startWeek; week <= Math.min(currentWeek, 18); week++) {
      try {
        var weekSheet = ss.getSheetByName("Week " + week);
        if (weekSheet) {
          Logger.log("Processing Week " + week + "...");

          // 1. Fetch Stats & Projections
          var weeklyStats = fetchWeeklyStats(year, week, includeTeamDef);
          var weeklyProjections = fetchWeeklyProjections(year, week);

          // 2. Consolidate Weekly Tables
          try {
            ConsolidateWeeklyTables(week, scoringStats, includeTeamDef, playerLookup, weeklyStats, weeklyProjections, scoringMultipliers);
          } catch (consolidateError) {
            Logger.log("Week " + week + " consolidation error: " + consolidateError.toString());
            errors.push("Week " + week + " consolidation: " + consolidateError.toString());
          }

          // 3. Process Free Agents (if sheet exists)
          if (freeAgentsSheet) {
            // Rebuild ownership lookup from the Week sheet
            var ownershipLookup = {};
            var lastCol = weekSheet.getLastColumn();
            var rosterRows = weekSheet.getRange(2, 1, 32, lastCol).getValues();
            
            rosterRows.forEach(function(row) {
              var ownerName = row[0];
              var rosterId = row[1];
              if (rosterId) {
                 for (var c = 4; c < row.length; c++) {
                   var pid = row[c];
                   if (pid) {
                     ownershipLookup[pid.toString()] = { owner: ownerName, rosterId: rosterId };
                   }
                 }
              }
            });

            var faRows = processFreeAgentsForWeek(week, weeklyStats, weeklyProjections, playerLookup, scoringStats, rosterPositions, scoringMultipliers, ownershipLookup);
            
            if (faRows.length > 0) {
              // Append for this week
              var startRow = freeAgentsSheet.getLastRow() + 1;
              
              // Ensure sheet matches output dimensions
              var requiredCols = faRows[0].length;
              ensureSheetSize(freeAgentsSheet, startRow + faRows.length - 1, requiredCols);

              freeAgentsSheet.getRange(startRow, 1, faRows.length, faRows[0].length).setValues(faRows);
            }
          }

          Logger.log("Week " + week + " processing complete");
          
          // Small delay to avoid rate limiting
          sleepForSleeperRateLimit(100);
        }
      } catch (error) {
        errors.push("Week " + week + " processing: " + error.toString());
      }
    }
    
    // Auto-resize Free Agents columns at the very end
    if (freeAgentsSheet && currentWeek >= 10) {
      freeAgentsSheet.autoResizeColumns(1, 7 + scoringStats.length);
    }

    Logger.log("Part 2 processing complete (weeks 10-" + currentWeek + "). All weekly data processing finished.");
    return errors;

  } catch (error) {
    throw new Error("Error processing weekly data (Part 2): " + error.toString());
  }
}

/**
 * LEGACY: Step 4: Refresh League-Specific Data (ALL IN ONE)
 * Updates Settings, Users, and Weekly matchup data
 * WARNING: This function will timeout with large leagues (32 teams Ã— 60 players)
 * Use RefreshWeeklyRawData, ProcessWeeklyData_Part1, and ProcessWeeklyData_Part2 instead
 */
function RefreshLeagueSpecificData(leagueId, currentWeek) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var errors = [];

    // Refresh Settings and Users (shared helper function with timing)
    var settingsUsersStartTime = new Date();
    Logger.log("TIMER: Fetching Settings and Users at " + settingsUsersStartTime.toISOString());
    var settingsUsersErrors = RefreshSettingsAndUsers(leagueId);
    errors = errors.concat(settingsUsersErrors);
    var settingsUsersEndTime = new Date();
    Logger.log("TIMER: Settings and Users completed in " + ((settingsUsersEndTime - settingsUsersStartTime) / 1000) + " seconds");

    // PERFORMANCE OPTIMIZATION: Build lookups once before processing all weeks
    // These are expensive operations that don't need to be repeated for each week
    var lookupsStartTime = new Date();
    Logger.log("TIMER: Building shared lookups at " + lookupsStartTime.toISOString());
    var scoringStats = buildSortedScoringStats();
    var includeTeamDef = hasTeamDefenses();
    var playerLookup = buildPlayerLookup();
    var userLookup = buildUserLookup();
    var rosterPositions = getLeagueRosterPositions(); // For Free Agents filtering
    var scoringMultipliers = getScoringMultipliers(); // For Free Agents points
    var lookupsEndTime = new Date();
    Logger.log("TIMER: Lookups built in " + ((lookupsEndTime - lookupsStartTime) / 1000) + " seconds");

    // Initialize Free Agents sheet
    var freeAgentsSheet = ss.getSheetByName("Free Agents");
    var totalFreeAgentsRows = 0;
    
    if (freeAgentsSheet) {
      freeAgentsSheet.clear();
      // Build header row for Free Agents
      var faHeader = ["Week", "Player_ID", "Player", "Position", "NFL Team", "Fantasy Points", "Projected"];
      scoringStats.forEach(function(s) { faHeader.push(s.label); });
      
      // Ensure sheet matches output dimensions
      var requiredCols = faHeader.length;
      ensureSheetSize(freeAgentsSheet, 1, requiredCols);
      
      freeAgentsSheet.getRange(1, 1, 1, faHeader.length).setValues([faHeader]);
      freeAgentsSheet.setFrozenRows(1);
    } // If not found, we skip Free Agents processing silently (Step 2 shouldn't fail)

    // Refresh Weekly Data (only through current week)
    Logger.log("TIMER: Starting weekly data processing for weeks 1-" + currentWeek);
    for (var week = 1; week <= 18; week++) {
      var weekStartTime = new Date();
      try {
        var weekSheet = ss.getSheetByName("Week " + week);
        if (weekSheet) {
          if (week <= currentWeek) {
            // Clear ONLY the rows that automation writes to (preserve formula rows 69-169)
            // Row 1-33: Roster/player data
            // Row 35-67: Points data
            // Row 171-203: Matchup data
            weekSheet.getRange("1:33").clearContent();
            weekSheet.getRange("35:67").clearContent();
            weekSheet.getRange("171:203").clearContent();

            var weekUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/matchups/" + week;
            var weekData = fetchSleeperJson(weekUrl, {
              workflow: "Step 2 Matchups Week " + week,
              preserveLargeNumbers: true,
              leagueId: leagueId
            });

            // Build derived tables directly from API data on the sheet
            buildDerivedWeeklyTables(weekSheet, weekData, week, userLookup);
            
            // Fetch stats ONCE for this week - used by both Consolidation and Free Agents
            // Note: fetchWeeklyStats signature is (year, week, includeTDef). We need 'year'.
            var year = ss.getSheetByName("Info").getRange("B2").getValue();
            var weeklyStats = fetchWeeklyStats(year, week, includeTeamDef);

            // Fetch projections ONCE for this week - used by both Consolidation and Free Agents
            var weeklyProjections = fetchWeeklyProjections(year, week);

            // Consolidate weekly tables into unified format using PRE-FETCHED stats and projections
            try {
              ConsolidateWeeklyTables(week, scoringStats, includeTeamDef, playerLookup, weeklyStats, weeklyProjections, scoringMultipliers);
            } catch (consolidateError) {
              Logger.log("Week " + week + " consolidation error: " + consolidateError.toString());
            }

            // Process Free Agents for this week (if sheet exists)
            if (freeAgentsSheet) {
              // Build ownership lookup from the 'weekData' (matchups) directly for speed
              var ownershipLookup = {};
              weekData.forEach(function(matchup) {
                 var rId = matchup.roster_id;
                 var ownerName = userLookup[rId] || ("Roster " + rId);
                 var players = matchup.players || [];
                 players.forEach(function(pid) {
                   ownershipLookup[pid] = { owner: ownerName, rosterId: rId };
                 });
              });

              var faRows = processFreeAgentsForWeek(week, weeklyStats, weeklyProjections, playerLookup, scoringStats, rosterPositions, scoringMultipliers, ownershipLookup);
              
              if (faRows.length > 0) {
                // Bulk write for this week
                var startRow = totalFreeAgentsRows + 2; // +1 for header, +1 for 1-based index
                
                // Ensure sheet matches output dimensions
                var requiredCols = faRows[0].length;
                ensureSheetSize(freeAgentsSheet, startRow + faRows.length - 1, requiredCols);

                freeAgentsSheet.getRange(startRow, 1, faRows.length, faRows[0].length).setValues(faRows);
                totalFreeAgentsRows += faRows.length;
              }
            }

            var weekEndTime = new Date();
            Logger.log("TIMER: Week " + week + " (League + FA) completed in " + ((weekEndTime - weekStartTime) / 1000) + " seconds");

            // Small delay to avoid rate limiting
            sleepForSleeperRateLimit(100); 
          } else {
            // Clear future weeks - only automation rows (preserve formulas)
            weekSheet.getRange("1:33").clearContent();
            weekSheet.getRange("35:67").clearContent();
            weekSheet.getRange("171:203").clearContent();
            Logger.log("Cleared Week " + week + " sheet (future week)");
          }
        }
      } catch (error) {
        errors.push("Week " + week + ": " + error.toString());
      }
    }
    
    // Auto-resize Free Agents columns at the end
    if (freeAgentsSheet && totalFreeAgentsRows > 0) {
      freeAgentsSheet.autoResizeColumns(1, 7 + scoringStats.length);
    }

    return errors;

  } catch (error) {
    throw new Error("Error refreshing league data: " + error.toString());
  }
}

/**
 * Step 2A: Gather Weekly Raw Data
 * Fast operation - only fetches and writes raw matchup data from API
 * Does NOT process or consolidate data
 */
function RefreshWeeklyRawData(leagueId, currentWeek) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var errors = [];

    // Refresh Settings and Users (shared helper function)
    var settingsUsersErrors = RefreshSettingsAndUsers(leagueId);
    errors = errors.concat(settingsUsersErrors);

    // Fetch Weekly Matchup Data (only through current week)
    // CRITICAL: We build derived tables directly from API data to save cell space
    // Do NOT write full raw API data (would exceed 10M cell limit)
    Logger.log("Fetching weekly matchup data for weeks 1-" + currentWeek + "...");

    // Build user lookup once for all weeks
    var userLookup = buildUserLookup();

    for (var week = 1; week <= 18; week++) {
      try {
        var weekSheet = ss.getSheetByName("Week " + week);
        if (weekSheet) {
          if (week <= currentWeek) {
            // Clear ONLY the rows that automation writes to (preserve formula rows 69-169)
            // Row 1-33: Roster/player data
            // Row 35-67: Points data
            // Row 171-203: Matchup data
            weekSheet.getRange("1:33").clearContent();
            weekSheet.getRange("35:67").clearContent();
            weekSheet.getRange("171:203").clearContent();

            var weekUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/matchups/" + week;
            var weekData = fetchSleeperJson(weekUrl, {
              workflow: "Batch 1 Matchups Week " + week,
              preserveLargeNumbers: true,
              leagueId: leagueId
            });

            // Build derived tables directly from API data (saves 99% of cell usage)
            buildDerivedWeeklyTables(weekSheet, weekData, week, userLookup);

            Logger.log("Week " + week + " derived tables built");

            // Small delay to avoid rate limiting
            sleepForSleeperRateLimit(100);
          } else {
            // Clear future weeks - only automation rows (preserve formulas)
            weekSheet.getRange("1:33").clearContent();
            weekSheet.getRange("35:67").clearContent();
            weekSheet.getRange("171:203").clearContent();
            Logger.log("Cleared Week " + week + " sheet (future week)");
          }
        }
      } catch (error) {
        errors.push("Week " + week + " raw data: " + error.toString());
      }
    }

    Logger.log("Raw data gathering complete. Run Step 2B to process weeks 1-9.");
    return errors;

  } catch (error) {
    throw new Error("Error gathering weekly raw data: " + error.toString());
  }
}

/**
 * Helper to process Free Agents data for a single week - extracted for performance optimization
 * @param {number} week - The week number
 * @param {Object} weeklyStats - The stats object for this week
 * @param {Object} weeklyProjections - The projections object for this week
 * @param {Object} playerLookup - Player info lookup
 * @param {Array} scoringStats - Array of scoring stat definitions
 * @param {Array} rosterPositions - Active roster positions (for filtering)
 * @param {Object} scoringMultipliers - Scoring multipliers map
 * @param {Object} ownershipLookup - Map of player ownership {playerId: {owner, rosterId}}
 * @return {Array} - Array of data rows for Free Agents sheet
 */
function processFreeAgentsForWeek(week, weeklyStats, weeklyProjections, playerLookup, scoringStats, rosterPositions, scoringMultipliers, ownershipLookup) {
  var weekOutputData = [];
  
  for (var playerId in weeklyStats) {
    var stats = weeklyStats[playerId];
    var playerInfo = playerLookup[playerId] || {
      name: playerId, // Use ID as fallback
      position: "",
      team: ""
    };

    // SAFETY CHECK: Skip players whose position is not relevant to this league
    // This filters out Punters, OL, etc. from Free Agents tab
    if (!isPositionRelevantInLeague(playerInfo.position, rosterPositions)) {
      continue;
    }

    // Check roster status
    var ownership = ownershipLookup[playerId];

    // FILTER: Only show true Free Agents (skip if rostered)
    if (ownership) {
      continue;
    }
    
    // Calculate fantasy points (Actual)
    var fantasyPoints = calculateFantasyPoints(stats, scoringMultipliers);

    // Calculate projected points
    var projPoints = 0;
    if (weeklyProjections && weeklyProjections[playerId] && weeklyProjections[playerId].stats) {
      projPoints = calculateFantasyPoints(weeklyProjections[playerId].stats, scoringMultipliers);
    }

    // Build row: base columns + stat values
    // Header: Week, Player_ID, Player, Position, NFL Team, Fantasy Points, Projected, [Stats]
    var row = [
      week,
      playerId,
      playerInfo.name,
      playerInfo.position,
      playerInfo.team,
      fantasyPoints,
      projPoints
    ];

    // Add stat values in the same order as header
    scoringStats.forEach(function(statObj) {
      var statValue = stats[statObj.key];
      // Use empty string for missing stats instead of 0 to distinguish "didn't play" from "played but got 0"
      row.push(statValue !== undefined && statValue !== null ? statValue : "");
    });

    weekOutputData.push(row);
  }
  
  return weekOutputData;
}

/**
 * =====================================================
 * DERIVED DATA - Transactions, Standings, Draft, Schedule, Playoffs
 * =====================================================
 * Functions that generate derived/aggregated data from raw API data.
 * Includes transactions history, standings calculations, draft results,
 * schedule generation, playoffs, and awards.
 */

/**
 * Custom function to fetch Sleeper transactions for multiple weeks (1 through specified week)
 * Creates separate rows for each player add/drop action
 * @param {string} leagueId - The Sleeper league ID
 * @param {number} throughWeek - The week to fetch through (e.g., 14 means weeks 1-14)
 * @param {boolean} excludeFailed - Whether to exclude failed transactions
 * @return {Array} - 2D array suitable for Google Sheets
 * @customfunction
 */
function ImportSleeperTransactions(leagueId, throughWeek, excludeFailed = true) {
  try {
    var allTransactions = [];

    // Get user lookup (respects Info!B5 display preference)
    var userLookup = buildUserLookup();

    var playerSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Players Database");
    var playerLastRow = playerSheet.getLastRow();
    var playerRange = playerLastRow > 0 ? playerSheet.getRange(1, 2, playerLastRow, 6).getValues() : [];
    var playerLookup = {};
    playerRange.forEach(function (row) {
      if (row[0]) { // if player ID exists
        playerLookup[row[0].toString()] = {
          position: row[1] || "",
          firstName: row[4] || "",
          lastName: row[5] || ""
        };
      }
    });

    // Fetch transactions for each week from 1 to throughWeek
    for (var week = 1; week <= throughWeek; week++) {
      try {
        var url = "https://api.sleeper.app/v1/league/" + leagueId + "/transactions/" + week;
        var weekTransactions = fetchSleeperJson(url, {
          workflow: "Transactions Week " + week,
          preserveLargeNumbers: true,
          leagueId: leagueId
        });

        // Add week number to each transaction for tracking
        weekTransactions.forEach(function (transaction) {
          transaction.week = week;
        });

        // Combine with all transactions
        allTransactions = allTransactions.concat(weekTransactions);

        // Add small delay to avoid hitting API rate limits
        sleepForSleeperRateLimit(0);

      } catch (weekError) {
        // If a specific week fails, continue with other weeks
        console.log("Failed to fetch week " + week + ": " + weekError.toString());
      }
    }

    // Filter out failed transactions if requested
    if (excludeFailed) {
      allTransactions = allTransactions.filter(function (transaction) {
        return transaction.status !== "failed";
      });
    }

    // Sort by created date (most recent first)
    allTransactions.sort(function (a, b) {
      return (b.created || 0) - (a.created || 0);
    });

    // Create headers
    var headers = ["Week", "Transaction ID", "Type", "Date", "User", "Action", "Player", "Position", "Waiver Bid"];
    var result = [headers];

    // Transform the data - create separate row for each player action
    allTransactions.forEach(function (transaction) {
      var baseInfo = {
        week: transaction.week || "",
        transaction_id: transaction.transaction_id ? "'" + transaction.transaction_id.toString() : "",  // Add apostrophe
        type: transaction.type || "",
        date: transaction.created ? new Date(parseInt(transaction.created)).toLocaleDateString("en-US") : "",
        waiver_bid: (transaction.settings && transaction.settings.waiver_bid) ? transaction.settings.waiver_bid : ""
      };

      var hasPlayerActions = false;

      // Debug: Log structure of potential "chopped" transactions
      if (transaction.type === "chopped" || (transaction.metadata && transaction.metadata.type === "chopped")) {
        Logger.log("DEBUG CHOPPED TRANSACTION: " + JSON.stringify(transaction));
      }

      // Create rows for adds
      if (transaction.adds) {
        for (var playerId in transaction.adds) {
          var rosterId = transaction.adds[playerId];
          var teamName = userLookup[rosterId.toString()] || rosterId;
          var playerInfo = playerLookup[playerId.toString()];
          var playerName = "";
          var position = "";

          if (playerInfo && (playerInfo.firstName || playerInfo.lastName)) {
            var first = playerInfo.firstName || "";
            var last = playerInfo.lastName || "";
            playerName = (first + " " + last).trim();
            position = playerInfo.position;
          } else {
            playerName = playerId; // fallback to ID if not found
          }

          result.push([
            baseInfo.week,
            baseInfo.transaction_id,
            baseInfo.type,
            baseInfo.date,
            teamName,
            "add",
            playerName,
            position,
            baseInfo.waiver_bid
          ]);
          hasPlayerActions = true;
        }
      }

      // Create rows for drops
      if (transaction.drops) {
        for (var playerId in transaction.drops) {
          var rosterId = transaction.drops[playerId];

          // Fallback: If rosterId is null (common in system/commissioner drops), try to find it in roster_ids array
          // Chopped transactions often have null in drops map but valid roster_ids
          if (!rosterId && transaction.roster_ids && transaction.roster_ids.length > 0) {
            rosterId = transaction.roster_ids[0];
          }

          var teamName = "";
          if (rosterId) {
            var lookupName = userLookup[rosterId.toString()];
            if (lookupName && lookupName.toString().trim() !== "") {
              teamName = lookupName;
            } else {
              teamName = "Team " + rosterId; // Fallback to explicit Team ID
            }
          }

          // Debug: Log specific resolution for chopped transactions
          if (transaction.type === "chopped") {
            Logger.log("CHOPPED DROP: Player " + playerId + ", RosterID: " + rosterId + ", Lookup: '" + userLookup[rosterId.toString()] + "', Final TeamName: '" + teamName + "'");
          }

          var playerInfo = playerLookup[playerId.toString()];
          var playerName = "";
          var position = "";

          if (playerInfo && (playerInfo.firstName || playerInfo.lastName)) {
            var first = playerInfo.firstName || "";
            var last = playerInfo.lastName || "";
            playerName = (first + " " + last).trim();
            position = playerInfo.position;
          } else {
            playerName = playerId; // fallback to ID if not found
          }

          result.push([
            baseInfo.week,
            baseInfo.transaction_id,
            baseInfo.type,
            baseInfo.date,
            teamName,
            "drop",
            playerName,
            position,
            "" // Empty waiver_bid for drops
          ]);
          hasPlayerActions = true;
        }
      }

      // Create rows for draft pick trades
      if (transaction.draft_picks && transaction.draft_picks.length > 0) {
        transaction.draft_picks.forEach(function (pick) {
          var newOwnerId = pick.owner_id;
          var previousOwnerId = pick.previous_owner_id;
          var rosterOwnerId = pick.roster_id; // The original owner of the pick

          var newTeamName = userLookup[newOwnerId.toString()] || newOwnerId;
          var previousTeamName = userLookup[previousOwnerId.toString()] || previousOwnerId;
          var rosterOwnerName = userLookup[rosterOwnerId.toString()] || rosterOwnerId;

          var pickDescription = pick.season + " Round " + pick.round + " Pick (" + rosterOwnerName + ")";

          // Create a row showing the pick going from previous owner to new owner
          result.push([
            baseInfo.week,
            baseInfo.transaction_id,
            baseInfo.type,
            baseInfo.date,
            newTeamName,
            "add",
            pickDescription,
            "PICK",
            ""
          ]);

          result.push([
            baseInfo.week,
            baseInfo.transaction_id,
            baseInfo.type,
            baseInfo.date,
            previousTeamName,
            "drop",
            pickDescription,
            "PICK",
            ""
          ]);

          hasPlayerActions = true;
        });
      }

      // If no adds or drops, still create a row for the transaction
      if (!hasPlayerActions) {
        var rosterIds = transaction.roster_ids || [];
        var teamNames = rosterIds.map(function (id) {
          return userLookup[id.toString()] || id;
        });

        result.push([
          baseInfo.week,
          baseInfo.transaction_id,
          baseInfo.type,
          baseInfo.date,
          teamNames.join(", "),
          "",
          "",
          "",
          baseInfo.waiver_bid
        ]);
      }
    });

    return result;

  } catch (error) {
    return [["Error: " + error.toString()]];
  }
}

/**
 * Calculate standings and weekly results, writing to separate sheets
 * @param {number} throughWeek - The week to calculate through
 * @return {object} - Object containing standingsData and weeklyResultsData arrays
 */
function CalculateDetailedStandings(throughWeek) {
  try {
    // Get the Player Results data
    var yearlySheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Player Results");
    var dataRange = yearlySheet.getDataRange();
    var data = dataRange.getValues();

    // Build user lookup map for display names early
    var displayLookup = buildUsernameToDisplayLookup();
    // Also build a User ID -> Display Name lookup if needed, but displayLookup is Username -> Display Name
    // The previous error was userLookup is not defined.
    // In ImportSleeperTransactions, userLookup = buildUserLookup() which returns {userid: displayname}
    // Let's use that one here too.
    var userLookup = buildUserLookup();

    // Get playoff start week from Settings
    var settingsSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Settings");
    var playoffStartWeek = settingsSheet.getRange("A6").getValue();
    var regularSeasonEnd = playoffStartWeek ? playoffStartWeek - 1 : 18;

    // Use the earlier of throughWeek or regularSeasonEnd
    var maxWeek = Math.min(throughWeek, regularSeasonEnd);

    // Skip header row and filter to only regular season weeks AND rows with owners
    var filteredData = data.slice(1).filter(function (row) {
      return row[0] && row[0].toString().trim() !== "" && row[3] <= maxWeek;
    });

    // Initialize team stats
    var teamStats = {};

    // Process each row to calculate weekly scores
    filteredData.forEach(function (row) {
      var owner = row[0];        // Column A - Owner
      var week = row[3];         // Column D - Week
      var fantasy = row[8];      // Column I - Fantasy (starting position)
      var points = row[9];       // Column J - Points
      var opponent = row[11];    // Column L - Opponent (shifted by Projected column)

      if (!teamStats[owner]) {
        teamStats[owner] = {
          wins: 0,
          losses: 0,
          totalPoints: 0,
          weeklyScores: {},
          highScores: 0
        };
      }

      if (!teamStats[owner].weeklyScores[week]) {
        teamStats[owner].weeklyScores[week] = {
          points: 0,
          opponent: opponent
        };
      }

      // Add points if player is starting (not on bench)
      if (fantasy && fantasy !== "BN") {
        teamStats[owner].weeklyScores[week].points += parseFloat(points) || 0;
      }
    });

    // Build weekly scores array for ranking
    var weeklyScoresArray = {}; // week -> [{owner, score}]

    Object.keys(teamStats).forEach(function (owner) {
      var team = teamStats[owner];

      Object.keys(team.weeklyScores).forEach(function (week) {
        if (!weeklyScoresArray[week]) {
          weeklyScoresArray[week] = [];
        }
        weeklyScoresArray[week].push({
          owner: owner,
          score: team.weeklyScores[week].points
        });
      });
    });

    // Calculate ranks for each week (1 = highest score)
    var weeklyRanks = {}; // week -> {owner: rank}

    Object.keys(weeklyScoresArray).forEach(function (week) {
      var scores = weeklyScoresArray[week];
      // Sort by score descending
      scores.sort(function (a, b) { return b.score - a.score; });

      weeklyRanks[week] = {};
      scores.forEach(function (entry, index) {
        weeklyRanks[week][entry.owner] = index + 1; // Rank 1, 2, 3, etc.
      });
    });

    // Calculate wins/losses and build detailed results
    var detailedResults = [];

    Object.keys(teamStats).forEach(function (owner) {
      var team = teamStats[owner];

      Object.keys(team.weeklyScores).forEach(function (week) {
        var weekData = team.weeklyScores[week];
        var opponent = weekData.opponent;
        var teamScore = weekData.points;

        // Get opponent's score for this week
        var opponentScore = 0;
        if (teamStats[opponent] && teamStats[opponent].weeklyScores[week]) {
          opponentScore = teamStats[opponent].weeklyScores[week].points;
        }

        // Determine win/loss
        var result = "";
        if (teamScore > opponentScore) {
          team.wins++;
          result = "W";
        } else if (teamScore < opponentScore) {
          team.losses++;
          result = "L";
        } else {
          result = "T";
        }

        // Get rank for this week (1 = highest scorer)
        var rank = weeklyRanks[week] ? weeklyRanks[week][owner] : 0;

        // Count high scores (rank 1)
        if (rank === 1) {
          team.highScores++;
        }

        // Add to total points
        team.totalPoints += teamScore;

        // Calculate margin (positive = win, negative = loss)
        var margin = teamScore - opponentScore;

        // Add detailed row with Rank and Margin (Margin Rank added later)
        detailedResults.push({
          owner: owner,
          week: parseInt(week),
          opponent: opponent,
          teamScore: parseFloat(teamScore.toFixed(2)),
          opponentScore: parseFloat(opponentScore.toFixed(2)),
          result: result,
          rank: rank,
          margin: parseFloat(margin.toFixed(2))
        });
      });
    });

    // Calculate Margin Rank for each week (highest margin = rank 1)
    var weeklyMargins = {}; // week -> [{owner, margin}]

    detailedResults.forEach(function (row) {
      if (!weeklyMargins[row.week]) {
        weeklyMargins[row.week] = [];
      }
      weeklyMargins[row.week].push({
        owner: row.owner,
        margin: row.margin
      });
    });

    var marginRanks = {}; // week -> {owner: marginRank}

    Object.keys(weeklyMargins).forEach(function (week) {
      var margins = weeklyMargins[week];
      // Sort by margin descending (highest margin first)
      margins.sort(function (a, b) { return b.margin - a.margin; });

      marginRanks[week] = {};
      margins.forEach(function (entry, index) {
        marginRanks[week][entry.owner] = index + 1;
      });
    });

    // Add margin rank to each result
    detailedResults.forEach(function (row) {
      row.marginRank = marginRanks[row.week] ? marginRanks[row.week][row.owner] : 0;
    });

    // Calculate "vs the league" record - hypothetical record if each team played every other team every week
    var vsLeagueRecords = {};
    Object.keys(teamStats).forEach(function (owner) {
      vsLeagueRecords[owner] = { wins: 0, losses: 0, ties: 0 };
    });

    // For each week, compare each team's score against every other team
    Object.keys(weeklyScoresArray).forEach(function (week) {
      var weekScores = weeklyScoresArray[week];

      // Compare each team against every other team
      weekScores.forEach(function (team1) {
        weekScores.forEach(function (team2) {
          if (team1.owner !== team2.owner) {
            if (team1.score > team2.score) {
              vsLeagueRecords[team1.owner].wins++;
            } else if (team1.score < team2.score) {
              vsLeagueRecords[team1.owner].losses++;
            } else {
              vsLeagueRecords[team1.owner].ties++;
            }
          }
        });
      });
    });

    // Create summary standings
    var standingsArray = [];
    Object.keys(teamStats).forEach(function (owner) {
      var team = teamStats[owner];
      var vsLeague = vsLeagueRecords[owner];
      var vsLeagueGames = vsLeague.wins + vsLeague.losses + vsLeague.ties;
      var vsLeagueWinPct = vsLeagueGames > 0 ? (vsLeague.wins / vsLeagueGames) : 0;

      standingsArray.push([
        owner,
        team.wins,
        team.losses,
        (team.wins + team.losses),
        team.wins / (team.wins + team.losses) || 0,
        team.totalPoints,
        team.highScores,
        vsLeague.wins,
        vsLeague.losses,
        vsLeagueWinPct
      ]);
    });

    // Sort standings by wins desc, then total points desc
    standingsArray.sort(function (a, b) {
      if (b[1] !== a[1]) {
        return b[1] - a[1];
      }
      return b[5] - a[5];
    });

    // Sort detailed results by week (ascending), then team score (descending)
    detailedResults.sort(function (a, b) {
      if (a.week !== b.week) {
        return a.week - b.week;
      }
      return b.teamScore - a.teamScore;
    });

    // Check for "Chopped" mode via League Settings
    // The presence of "last_chopped_leg" in settings indicates a Guillotine/Chopped league
    var settingsSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Settings");
    var lastChoppedLeg = getSettingValue(settingsSheet, "/settings/last_chopped_leg");
    var isChoppedMode = (lastChoppedLeg !== null && lastChoppedLeg !== undefined && lastChoppedLeg !== "");

    var choppedData = {}; // owner -> choppedWeek

    if (isChoppedMode) {
      Logger.log("CHOPPED MODE DETECTED: Scanning Transactions for elimination data...");
      // For Chopped Leagues: Read Transactions to find elimination weeks
      var transSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Transactions");
      if (transSheet) {
        var transData = transSheet.getDataRange().getValues();
        // Assume Row 1 is headers. Headers: Week, Transaction ID, Type, Date, User, Action, Player...
        // Find columns
        var typeCol = -1;
        var userCol = -1;
        var weekCol = -1;
        var headers = transData[0];

        for (var i = 0; i < headers.length; i++) {
          var h = headers[i].toString().toLowerCase();
          if (h === "type" && typeCol === -1) typeCol = i;
          if (h === "user" && userCol === -1) userCol = i;
          if (h === "week" && weekCol === -1) weekCol = i;
        }

        if (typeCol !== -1 && userCol !== -1 && weekCol !== -1) {
          Logger.log("CHOPPED DEBUG: Found columns - Type:" + typeCol + ", User:" + userCol + ", Week:" + weekCol);
          for (var i = 1; i < transData.length; i++) {
            var row = transData[i];
            var type = row[typeCol] ? row[typeCol].toString().toLowerCase() : "";

            if (type === "chopped") {
              // Get username (Display Name)
              var username = row[userCol] ? row[userCol].toString().trim() : "";
              var week = row[weekCol];

              Logger.log("CHOPPED DEBUG: Row " + (i + 1) + " Content - Type: '" + type + "', User: '" + username + "', Week: " + week);

              if (username !== "") {
                // Store directly by Display Name since teamStats keys are likely Display Names
                choppedData[username] = week;
                Logger.log("Found Chopped Transaction: User [" + username + "] in Week " + week);
              } else {
                Logger.log("Found Chopped Transaction: User [] in Week " + week + " (Values: " + JSON.stringify(row) + ")");
              }
            }
          }
        } else {
          Logger.log("Could not find required columns in Transactions sheet. Headers: " + headers.join(", "));
        }
      } else {
        Logger.log("Transactions sheet not found!");
      }
    }

    // Debug: Log teamStats keys to verify they match Transactions

    // Build Standings sheet data
    var standingsData = [];

    if (isChoppedMode) {
      // CHOPPED STANDINGS
      // Columns: User, Place, Chopped Week, Total Points, High Scores
      standingsData.push(["User", "Place", "Chopped Week", "Total Points", "High Scores"]);

      var choppedStandings = [];

      Object.keys(teamStats).forEach(function (owner) {
        var team = teamStats[owner];
        // Try exact match first
        var choppedWeek = choppedData[owner];

        // If not found, try varying checks (case insensitive?)
        if (!choppedWeek) {
          // Try case-insensitive lookup
          var ownerLower = owner.toLowerCase();
          for (var choppedUser in choppedData) {
            if (choppedUser.toLowerCase() === ownerLower) {
              choppedWeek = choppedData[choppedUser];
              break;
            }
          }
        }

        if (choppedWeek) {
          Logger.log("Matched Team [" + owner + "] to Chopped Week " + choppedWeek);
        } else {
          // Logger.log("No Chopped Week found for Team [" + owner + "]");
        }

        choppedStandings.push({
          owner: owner,
          choppedWeek: choppedWeek, // undefined if active
          totalPoints: team.totalPoints,
          highScores: team.highScores
        });
      });

      // FINAL 2 LOGIC: If only 2 survivors remain, determine winner by points during Championship Period
      var survivors = choppedStandings.filter(function (t) { return !t.choppedWeek; });
      if (survivors.length === 2) {
        // 1. Find last chopped week
        var lastChoppedWeek = 0;
        choppedStandings.forEach(function (t) {
          if (t.choppedWeek && t.choppedWeek > lastChoppedWeek) {
            lastChoppedWeek = t.choppedWeek;
          }
        });

        Logger.log("CHOPPED FINAL 2 DETECTED. Last Chopped Week: " + lastChoppedWeek);

        // 2. Calculate Championship Points (Weeks > lastChoppedWeek)
        survivors.forEach(function (survivor) {
          var champPoints = 0;
          var team = teamStats[survivor.owner];
          if (team && team.weeklyScores) {
            Object.keys(team.weeklyScores).forEach(function (week) {
              if (parseInt(week) > lastChoppedWeek) {
                champPoints += team.weeklyScores[week].points;
              }
            });
          }
          survivor.champPoints = champPoints;
          Logger.log("Survivor [" + survivor.owner + "] Championship Points: " + champPoints);
        });

        // 3. Sort survivors by Championship Points
        survivors.sort(function (a, b) { return b.champPoints - a.champPoints; });

        // 4. Assign "Chopped" status to the runner-up (Index 1)
        var runnerUp = survivors[1];
        var winner = survivors[0];

        // Find max week in data to assign as Chopped Week
        var maxWeekInData = 0;
        Object.keys(weeklyScoresArray).forEach(function (w) {
          if (parseInt(w) > maxWeekInData) maxWeekInData = parseInt(w);
        });

        runnerUp.choppedWeek = maxWeekInData;

        Logger.log("Final 2 Decision: Winner [" + winner.owner + "], Runner-Up [" + runnerUp.owner + "] (Chopped Week " + maxWeekInData + ")");
      }

      // Sort Order for Chopped:
      // 1. Elimination Order (First Chopped = Top). 
      //    So sort by Chopped Week ASCENDING.
      // 2. Survivors (undefined choppedWeek) go to the BOTTOM.
      // 3. Among survivors, sort by Total Points DESC (or whatever makes sense, usually Points).

      choppedStandings.sort(function (a, b) {
        // If both chopped
        if (a.choppedWeek && b.choppedWeek) {
          return a.choppedWeek - b.choppedWeek; // Week 1 before Week 2
        }
        // If only A is chopped, A comes first (smaller index)
        if (a.choppedWeek && !b.choppedWeek) {
          return -1;
        }
        // If only B is chopped, B comes first
        if (!a.choppedWeek && b.choppedWeek) {
          return 1;
        }
        // If neither chopped (Survivors), sort by Total Points DESC
        return b.totalPoints - a.totalPoints;
      });

      // Assign Place
      // If First Chopped = Last Place.
      // Wait, usually "Standings" implies 1st Place is at the top. 
      // But the user specifically asked for "First Chopped (Last Place) at the Top".
      // So we list them in order of elimination.
      // We can just calculate "Place" based on the total number of teams.
      // If 18 teams:
      // Row 1 (Chopped Wk 1) = 18th Place? 
      // Or does User just want to see the order? 
      // "The first entry on the results will be the last place team... and it'll have a column for their place"
      // So yes, reverse place.

      var totalTeams = choppedStandings.length;

      choppedStandings.forEach(function (team, index) {
        // Index 0 = First Chopped = Last Place (e.g. 18th)
        var place = totalTeams - index;
        var choppedDisplay = team.choppedWeek ? "Week " + team.choppedWeek : "-";

        standingsData.push([
          team.owner,
          place,
          choppedDisplay,
          parseFloat(team.totalPoints.toFixed(2)),
          team.highScores
        ]);
      });

    } else {
      // REGULAR STANDINGS
      standingsData.push(["User", "Wins", "Losses", "Games", "Win %", "Total Points", "High Scores", "vs League W", "vs League L", "vs League %"]);
      standingsArray.forEach(function (team) {
        standingsData.push([
          team[0],
          team[1],
          team[2],
          team[3],
          (team[4] * 100).toFixed(1) + "%",
          parseFloat(team[5].toFixed(2)),
          team[6],
          team[7],
          team[8],
          (team[9] * 100).toFixed(1) + "%"
        ]);
      });
    }

    // Build Weekly Results sheet data with new column order
    // Week, User, Team Score, Rank, Opponent, Opp Score, Opp Rank, Result, Margin, Margin Rank
    var weeklyResultsData = [];

    if (isChoppedMode) {
      // Chopped Weekly Results: Week, User, Team Score, Rank
      weeklyResultsData.push(["Week", "User", "Team Score", "Rank"]);
      detailedResults.forEach(function (row) {
        weeklyResultsData.push([
          row.week,
          row.owner,
          row.teamScore,
          row.rank
        ]);
      });
    } else {
      // Regular Weekly Results
      weeklyResultsData.push(["Week", "User", "Team Score", "Rank", "Opponent", "Opp Score", "Opp Rank", "Result", "Margin", "Margin Rank"]);
      detailedResults.forEach(function (row) {
        // Get opponent's rank for this week
        var oppRank = weeklyRanks[row.week] ? weeklyRanks[row.week][row.opponent] : 0;

        weeklyResultsData.push([
          row.week,
          row.owner,
          row.teamScore,
          row.rank,
          row.opponent,
          row.opponentScore,
          oppRank,
          row.result,
          row.margin,
          row.marginRank
        ]);
      });
    }

    // Translate usernames to preferred display names (team names if selected)
    // displayLookup was defined at the top of the function
    if (Object.keys(displayLookup).length > 0) {
      // Translate standings (column 0 = User)
      for (var i = 1; i < standingsData.length; i++) {
        var username = standingsData[i][0];
        if (displayLookup[username]) {
          standingsData[i][0] = displayLookup[username];
        }
      }

      // Translate weekly results (column 1 = User)
      // For Regular mode, also translate Opponent (column 4)
      for (var i = 1; i < weeklyResultsData.length; i++) {
        var username = weeklyResultsData[i][1];
        if (displayLookup[username]) {
          weeklyResultsData[i][1] = displayLookup[username];
        }

        if (!isChoppedMode) {
          var opponent = weeklyResultsData[i][4];
          if (displayLookup[opponent]) {
            weeklyResultsData[i][4] = displayLookup[opponent];
          }
        }
      }
    }

    return {
      standingsData: standingsData,
      weeklyResultsData: weeklyResultsData
    };

  } catch (error) {
    Logger.log("Error in CalculateDetailedStandings: " + error.toString());
    return {
      standingsData: [["Error: " + error.toString()]],
      weeklyResultsData: [["Error: " + error.toString()]]
    };
  }
}

/**
 * Custom function to create a clean draft board from Sleeper draft data
 * Automatically pulls draft ID from Settings sheet
 * Includes auction amounts for auction drafts
 * @return {Array} - 2D array with draft board data
 * @customfunction
 */
function ImportDraft() {
  try {
    // Get draft ID from Settings!A5
    var settingsSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Settings");
    var draftId = settingsSheet.getRange("A5").getValue();

    if (!draftId) {
      return [["Error: No draft ID found in Settings!A5"]];
    }

    // Fetch draft settings
    var settingsUrl = "https://api.sleeper.app/v1/draft/" + draftId;
    var settingsData = fetchSleeperJson(settingsUrl, {
      workflow: "Draft Settings",
      preserveLargeNumbers: true
    });

    // Check if it's an auction draft
    var isAuction = settingsData.type === "auction";

    // Fetch draft picks
    var picksUrl = "https://api.sleeper.app/v1/draft/" + draftId + "/picks";
    var picksData = fetchSleeperJson(picksUrl, {
      workflow: "Draft Picks",
      preserveLargeNumbers: true
    });

    // Get user lookup (respects Info!B5 display preference)
    var userLookup = buildUserLookup();

    // Create headers - add Auction Amount if it's an auction draft
    var headers = ["Round", "Overall Pick", "Player", "Position", "NFL Team", "Drafted By", "Keeper"];
    if (isAuction) {
      headers.push("Auction Amount");
    }
    var result = [headers];

    // Sort picks by overall pick number
    picksData.sort(function (a, b) {
      return a.pick_no - b.pick_no;
    });

    // Process each pick
    picksData.forEach(function (pick) {
      var metadata = pick.metadata || {};

      // Get player name
      var firstName = metadata.first_name || "";
      var lastName = metadata.last_name || "";
      var playerName = (firstName + " " + lastName).trim();
      if (!playerName) {
        playerName = pick.player_id || "Unknown Player";
      }

      // Get position and NFL team
      var position = metadata.position || "";
      var nflTeam = metadata.team || "";

      // Get drafting team name
      var rosterId = pick.roster_id;
      var draftedBy = userLookup[rosterId.toString()] || ("Roster " + rosterId);

      // Check if keeper
      var isKeeper = pick.is_keeper === true ? "Yes" : "";

      // Build row data
      var rowData = [
        pick.round || "",
        pick.pick_no || "",
        playerName,
        position,
        nflTeam,
        draftedBy,
        isKeeper
      ];

      // Add auction amount if it's an auction draft
      if (isAuction) {
        var auctionAmount = metadata.amount || "";
        rowData.push(auctionAmount);
      }

      // Add row to results
      result.push(rowData);
    });

    return result;

  } catch (error) {
    return [["Error: " + error.toString()]];
  }
}

/**
 * Build draft pick inventory showing each team's picks
 * Shows current owner, original roster, round, and year for each pick
 * @return {Array} - 2D array with draft pick inventory
 */
function ImportDraftPickInventory() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var settingsSheet = ss.getSheetByName("Settings");
    var infoSheet = ss.getSheetByName("Info");

    // Check if pick trading is enabled
    var settingsHeaders = settingsSheet.getRange(1, 1, 1, settingsSheet.getLastColumn()).getValues()[0];
    var pickTradingCol = -1;
    var draftRoundsCol = -1;

    for (var i = 0; i < settingsHeaders.length; i++) {
      if (settingsHeaders[i] === "/settings/pick_trading") {
        pickTradingCol = i;
      }
      if (settingsHeaders[i] === "/settings/draft_rounds") {
        draftRoundsCol = i;
      }
    }

    if (pickTradingCol === -1) {
      return [["This league does not allow draft pick trading."]];
    }

    var pickTradingEnabled = settingsSheet.getRange(2, pickTradingCol + 1).getValue();
    if (pickTradingEnabled !== 1 && pickTradingEnabled !== "1") {
      return [["This league does not allow draft pick trading."]];
    }

    // Get number of draft rounds
    var draftRounds = 5; // Default
    if (draftRoundsCol !== -1) {
      var rounds = settingsSheet.getRange(2, draftRoundsCol + 1).getValue();
      if (rounds) {
        draftRounds = parseInt(rounds);
      }
    }

    // Get league ID and current year
    var leagueId = GetSelectedLeagueId();
    var currentYear = infoSheet.getRange("B2").getValue();
    if (!currentYear) {
      return [["Error: Year not set in Info!B2"]];
    }

    // Fetch traded picks
    var tradedUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/traded_picks";
    var tradedPicks = fetchSleeperJson(tradedUrl, {
      workflow: "Traded Picks",
      preserveLargeNumbers: true,
      leagueId: leagueId
    });

    // Get user lookup
    var userLookup = buildUserLookup();

    // Get all rosters from both the raw roster block and derived table.
    // Orphan rosters may not appear in the derived user mapping.
    var usersSheet = ss.getSheetByName("Users");
    var rosterIdSeen = {};
    var allRosterIds = [];

    function addRosterId(rosterId) {
      if (rosterId === null || rosterId === undefined || rosterId === "") return;
      var rosterIdString = rosterId.toString();
      if (!rosterIdSeen[rosterIdString]) {
        rosterIdSeen[rosterIdString] = true;
        allRosterIds.push(rosterIdString);
      }
    }

    if (usersSheet && usersSheet.getLastRow() >= 36) {
      var rosterHeaders = usersSheet.getRange(36, 1, 1, usersSheet.getLastColumn()).getValues()[0];
      var rosterIdCol = findHeaderIndex(rosterHeaders, "/roster_id");
      if (rosterIdCol !== -1) {
        var rawRosterRows = usersSheet.getRange(37, 1, Math.min(32, usersSheet.getLastRow() - 36), rosterHeaders.length).getValues();
        rawRosterRows.forEach(function(row) {
          addRosterId(row[rosterIdCol]);
        });
      }
    }

    // The derived table is in rows 73-104, columns A-C: user_id, roster_id, display_name
    var rosterData = usersSheet.getRange("B73:B104").getValues(); // Column B (roster_id)
    for (var i = 0; i < rosterData.length; i++) {
      addRosterId(rosterData[i][0]);
    }

    // Build complete pick inventory
    // Start with all picks owned by their original roster
    var pickInventory = {}; // key: "season-round-roster_id", value: {season, round, roster_id, owner_id}

    // Initialize all picks for current year and next 2 years
    for (var year = currentYear; year <= currentYear + 2; year++) {
      for (var round = 1; round <= draftRounds; round++) {
        allRosterIds.forEach(function (rosterId) {
          var key = year + "-" + round + "-" + rosterId;
          pickInventory[key] = {
            season: year,
            round: round,
            roster_id: rosterId,
            owner_id: rosterId, // Initially owned by the roster
            original_owner: rosterId
          };
        });
      }
    }

    // Update ownership for traded picks
    tradedPicks.forEach(function (pick) {
      var key = pick.season + "-" + pick.round + "-" + pick.roster_id;

      // Only update if this pick exists in our inventory
      if (pickInventory[key]) {
        // Update the owner_id to reflect the trade
        pickInventory[key].owner_id = pick.owner_id.toString();
      }
    });

    // Convert to array and group by current owner
    var picksByOwner = {}; // owner_id -> array of picks

    for (var key in pickInventory) {
      var pick = pickInventory[key];
      var ownerId = pick.owner_id.toString();

      if (!picksByOwner[ownerId]) {
        picksByOwner[ownerId] = [];
      }

      picksByOwner[ownerId].push(pick);
    }

    // Sort picks by year, then round
    for (var ownerId in picksByOwner) {
      picksByOwner[ownerId].sort(function (a, b) {
        if (a.season !== b.season) {
          return a.season - b.season;
        }
        return a.round - b.round;
      });
    }

    // Build output table (removed Description column)
    var output = [["Team", "Year", "Round", "Original Team"]];

    // Debug: log the number of picks
    Logger.log("Total picks in inventory: " + Object.keys(pickInventory).length);
    Logger.log("Number of owners: " + Object.keys(picksByOwner).length);
    Logger.log("User lookup has " + Object.keys(userLookup).length + " entries");

    // Sort owners by roster_id for consistent ordering
    var sortedOwnerIds = Object.keys(picksByOwner).sort(function (a, b) {
      return parseInt(a) - parseInt(b);
    });

    sortedOwnerIds.forEach(function (ownerId) {
      var ownerName = userLookup[ownerId];

      if (!ownerName) {
        ownerName = "Open Roster " + ownerId;
      }

      var picks = picksByOwner[ownerId];

      picks.forEach(function (pick) {
        var originalTeam = userLookup[pick.original_owner];

        // If we can't find original team name, use roster ID
        if (!originalTeam) {
          originalTeam = "Open Roster " + pick.original_owner;
        }

        output.push([
          ownerName,
          pick.season,
          pick.round,
          originalTeam
        ]);
      });
    });

    Logger.log("Output rows: " + output.length);
    return output;

  } catch (error) {
    return [["Error: " + error.toString()]];
  }
}

/**
 * Alternative version that can be called from RefreshDerivedData
 * @param {string} leagueId - The league ID
 * @param {number} regularSeasonEnd - Last week of regular season
 * @return {boolean} - Success status
 */
function RefreshScheduleData(leagueId, regularSeasonEnd) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var scheduleSheet = ss.getSheetByName("Schedule");

    if (!scheduleSheet) {
      Logger.log("Schedule sheet not found");
      return false;
    }

    // Get roster IDs from Schedule sheet column A
    var lastRow = scheduleSheet.getLastRow();
    if (lastRow < 2) {
      Logger.log("No roster IDs found in Schedule sheet");
      return false;
    }

    // Support up to 32 rosters
    var maxTeams = Math.min(lastRow - 1, 32);
    var rosterIds = scheduleSheet.getRange(2, 1, maxTeams, 1).getValues();

    // Clear existing schedule data (support up to 32 teams)
    scheduleSheet.getRange(2, 2, 32, 18).clearContent();

    // Create a matrix to store matchup IDs
    var scheduleMatrix = [];
    for (var i = 0; i < rosterIds.length; i++) {
      scheduleMatrix[i] = new Array(regularSeasonEnd).fill("");
    }

    // Fetch matchup data for each regular season week
    for (var week = 1; week <= regularSeasonEnd; week++) {
      try {
        var weekUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/matchups/" + week;
        var matchupData = fetchSleeperJson(weekUrl, {
          workflow: "Schedule Matchups Week " + week,
          preserveLargeNumbers: true,
          leagueId: leagueId
        });

        // Create a map of roster_id to matchup_id
        var matchupMap = {};
        matchupData.forEach(function (matchup) {
          if (matchup.roster_id && matchup.matchup_id) {
            matchupMap[matchup.roster_id.toString()] = matchup.matchup_id;
          }
        });

        // Populate the matrix
        for (var i = 0; i < rosterIds.length; i++) {
          var rosterId = rosterIds[i][0];
          if (rosterId && matchupMap[rosterId.toString()]) {
            scheduleMatrix[i][week - 1] = matchupMap[rosterId.toString()];
          }
        }

        sleepForSleeperRateLimit(0);

      } catch (weekError) {
        Logger.log("Error fetching week " + week + " schedule: " + weekError.toString());
      }
    }

    // Write the schedule matrix
    if (scheduleMatrix.length > 0 && scheduleMatrix[0].length > 0) {
      scheduleSheet.getRange(2, 2, scheduleMatrix.length, scheduleMatrix[0].length).setValues(scheduleMatrix);
    }

    return true;

  } catch (error) {
    Logger.log("Error refreshing schedule: " + error.toString());
    return false;
  }
}

/**
 * Import Playoff Brackets from Sleeper API
 * Fetches winners and losers bracket data and displays in Playoffs sheet
 * Includes both tabular results and visual bracket layout
 * @param {string} leagueId - The Sleeper league ID
 * @return {boolean} - Success status
 */
function ImportPlayoffBrackets(leagueId) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var playoffsSheet = ss.getSheetByName("Playoffs");

    if (!playoffsSheet) {
      Logger.log("Playoffs sheet not found");
      return false;
    }

    // Check for "Chopped" mode via League Settings
    // The presence of "last_chopped_leg" in settings indicates a Guillotine/Chopped league
    var settingsSheet = ss.getSheetByName("Settings");
    var lastChoppedLeg = getSettingValue(settingsSheet, "/settings/last_chopped_leg");
    var isChoppedMode = (lastChoppedLeg !== null && lastChoppedLeg !== undefined && lastChoppedLeg !== "");

    Logger.log("Chopped Mode Detection (Playoffs): last_chopped_leg = [" + lastChoppedLeg + "], isChoppedMode = " + isChoppedMode);

    if (isChoppedMode) {
      playoffsSheet.clear();
      playoffsSheet.getRange("A1").setValue("Chopped League - No Playoffs");
      playoffsSheet.getRange("A1").setFontWeight("bold").setFontSize(14);
      Logger.log("Chopped Mode detected - skipping playoff import");
      return true;
    }

    // Get settings for playoff configuration
    var settingsSheet = ss.getSheetByName("Settings");
    var playoffWeekStart = settingsSheet.getRange("A6").getValue();
    var playoffTeams = getSettingValue(settingsSheet, "/settings/playoff_teams");
    var playoffRoundType = getSettingValue(settingsSheet, "/settings/playoff_round_type");
    var playoffType = getSettingValue(settingsSheet, "/settings/playoff_type");

    // Default values if not found
    playoffWeekStart = playoffWeekStart || 15;
    playoffTeams = playoffTeams || 6;

    // Ensure types are integers to prevent logic errors with strict equality checks
    playoffRoundType = parseInt(playoffRoundType);
    if (isNaN(playoffRoundType)) playoffRoundType = 0;
    playoffType = parseInt(playoffType);
    if (isNaN(playoffType)) playoffType = 0;

    // Get user lookup (respects Info!B5 display preference)
    var userLookup = buildUserLookup();

    // Fetch bracket data
    var winnersBracket = [];
    var losersBracket = [];

    try {
      var winnersUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/winners_bracket";
      winnersBracket = fetchSleeperJson(winnersUrl, {
        workflow: "Winners Bracket",
        preserveLargeNumbers: true,
        leagueId: leagueId
      }) || []; // Safety fallback
      Logger.log("Winners bracket fetched: " + winnersBracket.length + " matchups");
    } catch (e) {
      Logger.log("Error fetching winners bracket: " + e.toString());
    }

    sleepForSleeperRateLimit(0);

    try {
      var losersUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/losers_bracket";
      losersBracket = fetchSleeperJson(losersUrl, {
        workflow: "Losers Bracket",
        preserveLargeNumbers: true,
        leagueId: leagueId
      }) || []; // Safety fallback
      Logger.log("Losers bracket fetched: " + losersBracket.length + " matchups");
    } catch (e) {
      Logger.log("Error fetching losers bracket: " + e.toString());
    }

    // Fetch playoff week scores
    var weeklyScores = {};
    var maxRound = Math.max(
      winnersBracket.length > 0 ? Math.max.apply(null, winnersBracket.map(function (m) { return m.r || 0; })) : 0,
      losersBracket.length > 0 ? Math.max.apply(null, losersBracket.map(function (m) { return m.r || 0; })) : 0
    );

    for (var round = 1; round <= maxRound; round++) {
      var week = getPlayoffWeekForRound(round, playoffWeekStart, playoffRoundType);
      if (!weeklyScores[week]) {
        try {
          var weekUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/matchups/" + week;
          var weekData = fetchSleeperJson(weekUrl, {
            workflow: "Playoff Scores Week " + week,
            preserveLargeNumbers: true,
            leagueId: leagueId
          });

          weeklyScores[week] = {};
          weekData.forEach(function (matchup) {
            if (matchup.roster_id) {
              weeklyScores[week][matchup.roster_id.toString()] = matchup.points || 0;
            }
          });
          sleepForSleeperRateLimit(0);
        } catch (e) {
          Logger.log("Error fetching week " + week + " scores: " + e.toString());
        }
      }

      // For 2-week matchups, also fetch the second week
      if (playoffRoundType === 2 || (playoffRoundType === 1 && round === maxRound)) {
        var week2 = week + 1;
        if (!weeklyScores[week2]) {
          try {
            var week2Url = "https://api.sleeper.app/v1/league/" + leagueId + "/matchups/" + week2;
            var week2Data = fetchSleeperJson(week2Url, {
              workflow: "Playoff Scores Week " + week2,
              preserveLargeNumbers: true,
              leagueId: leagueId
            });

            weeklyScores[week2] = {};
            week2Data.forEach(function (matchup) {
              if (matchup.roster_id) {
                weeklyScores[week2][matchup.roster_id.toString()] = matchup.points || 0;
              }
            });
            sleepForSleeperRateLimit(0);
          } catch (e) {
            Logger.log("Error fetching week " + week2 + " scores: " + e.toString());
          }
        }
      }
    }

    // Clear the Playoffs sheet
    playoffsSheet.clear();
    ensureSheetSize(playoffsSheet, 200, 20);

    // Build tabular data
    var tabularData = buildPlayoffTabularData(winnersBracket, losersBracket, userLookup, weeklyScores,
      playoffWeekStart, playoffRoundType, playoffType);

    // Write tabular data starting at row 1
    if (tabularData.length > 0) {
      var numCols = tabularData[0].length;
      ensureSheetSize(playoffsSheet, tabularData.length, numCols);
      playoffsSheet.getRange(1, 1, tabularData.length, numCols).setValues(tabularData);

      // Format header row: bold and center aligned
      var headerRange = playoffsSheet.getRange(1, 1, 1, numCols);
      headerRange.setFontWeight("bold");
      headerRange.setHorizontalAlignment("center");

      // Center align all data rows
      if (tabularData.length > 1) {
        var dataRange = playoffsSheet.getRange(2, 1, tabularData.length - 1, numCols);
        dataRange.setHorizontalAlignment("center");
      }
    }

    // Ensure we have enough rows for the visual bracket to prevent auto-expansion (which inherits formatting)
    // The visual bracket needs space below the tabular data.
    var tabularEndRow = tabularData.length + 3;
    var currentRows = playoffsSheet.getMaxRows();
    var requiredRows = tabularEndRow + 100; // Add robust buffer for visual bracket
    if (currentRows < requiredRows) {
      playoffsSheet.insertRowsAfter(currentRows, requiredRows - currentRows);
    }

    // Build visual bracket with formatting
    var tabularEndRow = tabularData.length + 3;
    formatPlayoffBracket(playoffsSheet, tabularEndRow, winnersBracket, losersBracket, userLookup, weeklyScores,
      playoffWeekStart, playoffRoundType, playoffTeams, playoffType);



    // Auto-resize all columns to fit data
    var maxCols = playoffsSheet.getMaxColumns();
    playoffsSheet.autoResizeColumns(1, maxCols);

    Logger.log("Playoffs sheet updated successfully");
    return true;

  } catch (error) {
    Logger.log("Error importing playoff brackets: " + error.toString());
    return false;
  }
}

/**
 * Refresh derived data (Transactions, Standings, Draft, Schedule)
 */
function RefreshDerivedData(leagueId, currentWeek, options) {
  options = options || {};
  var skipFinalDependentOutputs = options.skipFinalDependentOutputs === true;
  var errors = [];
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // Get playoff start week for schedule
  var settingsSheet = ss.getSheetByName("Settings");
  var playoffStartWeek = settingsSheet.getRange("A6").getValue();
  var regularSeasonEnd = playoffStartWeek ? playoffStartWeek - 1 : 14;

  // SKIP Player Results refresh during Step 2 - it takes 3+ minutes and causes timeouts
  // Users can refresh it manually if needed using the menu
  // var playerResultsStartTime = new Date();
  // Logger.log("TIMER: Refreshing Player Results at " + playerResultsStartTime.toISOString());
  // try {
  //   RefreshYearlyOutput(currentWeek);
  //   var playerResultsEndTime = new Date();
  //   Logger.log("TIMER: Player Results completed in " + ((playerResultsEndTime - playerResultsStartTime) / 1000) + " seconds");
  // } catch (error) {
  //   errors.push("Player Results: " + error.toString());
  // }

  // Refresh Transactions
  var transactionsStartTime = new Date();
  Logger.log("TIMER: Refreshing Transactions at " + transactionsStartTime.toISOString());
  try {
    var transactionsData = ImportSleeperTransactions(leagueId, currentWeek, true);
    var transactionsSheet = ss.getSheetByName("Transactions");
    if (transactionsSheet && transactionsData && transactionsData.length > 0) {
      // Only clear columns A:I
      var rowsToWrite = transactionsData.length;
      var lastRow = transactionsSheet.getLastRow();

      // Clear existing data in columns A:I
      if (lastRow > 0) {
        transactionsSheet.getRange(1, 1, lastRow, 9).clearContent();
      }

      // Write new data
      var requiredCols = transactionsData[0].length;
      ensureSheetSize(transactionsSheet, rowsToWrite, requiredCols);

      transactionsSheet.getRange(1, 1, rowsToWrite, requiredCols).setValues(transactionsData);
      transactionsSheet.getRange(1, 1, rowsToWrite, requiredCols).setHorizontalAlignment("center");
      transactionsSheet.autoResizeColumns(1, requiredCols);
    }
    var transactionsEndTime = new Date();
    Logger.log("TIMER: Transactions completed in " + ((transactionsEndTime - transactionsStartTime) / 1000) + " seconds");
  } catch (error) {
    errors.push("Transactions: " + error.toString());
  }

  if (!skipFinalDependentOutputs) {
    // Refresh Standings and Weekly Results (two separate sheets)
    // NOTE: This depends on Player Results being refreshed first
    var standingsStartTime = new Date();
    Logger.log("TIMER: Refreshing Standings/Weekly Results at " + standingsStartTime.toISOString());
    try {
      var calculatedData = CalculateDetailedStandings(currentWeek);

      // Write Standings sheet
      var standingsSheet = ss.getSheetByName("Standings");
      if (standingsSheet && calculatedData.standingsData && calculatedData.standingsData.length > 0) {
        standingsSheet.clear();

        // Resize if needed
        var requiredCols = calculatedData.standingsData[0].length;
        ensureSheetSize(standingsSheet, calculatedData.standingsData.length, requiredCols);

        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, requiredCols).setValues(calculatedData.standingsData);
        standingsSheet.getRange(1, 1, calculatedData.standingsData.length, requiredCols).setHorizontalAlignment("center");
        standingsSheet.autoResizeColumns(1, requiredCols);
      }

      // Write Weekly Results sheet
      var weeklyResultsSheet = ss.getSheetByName("Weekly Results");
      if (weeklyResultsSheet && calculatedData.weeklyResultsData && calculatedData.weeklyResultsData.length > 0) {
        weeklyResultsSheet.clear();

        // Resize if needed
        var requiredCols = calculatedData.weeklyResultsData[0].length;
        ensureSheetSize(weeklyResultsSheet, calculatedData.weeklyResultsData.length, requiredCols);

        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, requiredCols).setValues(calculatedData.weeklyResultsData);
        weeklyResultsSheet.getRange(1, 1, calculatedData.weeklyResultsData.length, requiredCols).setHorizontalAlignment("center");
        weeklyResultsSheet.autoResizeColumns(1, calculatedData.weeklyResultsData[0].length);
      }
      var standingsEndTime = new Date();
      Logger.log("TIMER: Standings/Weekly Results completed in " + ((standingsEndTime - standingsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Standings/Weekly Results: " + error.toString());
    }
  } else {
    Logger.log("Skipping provisional Standings/Weekly Results; final versions will be generated after Player Results.");
  }

  // Refresh Draft Result
  var draftStartTime = new Date();
  Logger.log("TIMER: Refreshing Draft Result at " + draftStartTime.toISOString());
  try {
    var draftData = ImportDraft();
    var draftSheet = ss.getSheetByName("Draft Result");
    if (draftSheet && draftData && draftData.length > 0) {
      draftSheet.clear();  // Changed from clearContent()
      ensureSheetSize(draftSheet, draftData.length, draftData[0].length);
      draftSheet.getRange(1, 1, draftData.length, draftData[0].length).setValues(draftData);
      draftSheet.getRange(1, 1, draftData.length, draftData[0].length).setHorizontalAlignment("center");
      draftSheet.autoResizeColumns(1, draftData[0].length);
    }
    var draftEndTime = new Date();
    Logger.log("TIMER: Draft Result completed in " + ((draftEndTime - draftStartTime) / 1000) + " seconds");
  } catch (error) {
    errors.push("Draft Result: " + error.toString());
  }

  // Refresh Schedule
  var scheduleStartTime = new Date();
  Logger.log("TIMER: Refreshing Schedule at " + scheduleStartTime.toISOString());
  try {
    if (!RefreshScheduleData(leagueId, regularSeasonEnd)) {
      errors.push("Schedule: No data refreshed");
    }
    var scheduleEndTime = new Date();
    Logger.log("TIMER: Schedule completed in " + ((scheduleEndTime - scheduleStartTime) / 1000) + " seconds");
  } catch (error) {
    errors.push("Schedule: " + error.toString());
  }

  // Refresh Playoffs (only if current week is at or past playoff start)
  var playoffsStartTime = new Date();
  Logger.log("TIMER: Refreshing Playoffs at " + playoffsStartTime.toISOString());
  try {
    if (currentWeek >= playoffStartWeek) {
      if (!ImportPlayoffBrackets(leagueId)) {
        errors.push("Playoffs: No data refreshed");
      }
    }
    var playoffsEndTime = new Date();
    Logger.log("TIMER: Playoffs completed in " + ((playoffsEndTime - playoffsStartTime) / 1000) + " seconds");
  } catch (error) {
    errors.push("Playoffs: " + error.toString());
  }

  if (!skipFinalDependentOutputs) {
    // Refresh Awards (depends on Player Results, Weekly Results, and Standings)
    var awardsStartTime = new Date();
    Logger.log("TIMER: Refreshing Awards at " + awardsStartTime.toISOString());
    try {
      var awardsData = CalculateAwards(currentWeek);
      var awardsSheet = ss.getSheetByName("Awards");
      if (awardsSheet && awardsData && awardsData.length > 0) {
        awardsSheet.clear();
        ensureSheetSize(awardsSheet, awardsData.length, awardsData[0].length);
        awardsSheet.getRange(1, 1, awardsData.length, awardsData[0].length).setValues(awardsData);

        // Center align all data
        awardsSheet.getRange(1, 1, awardsData.length, 5).setHorizontalAlignment("center");

        // Format section headers and sub-headers
        for (var i = 0; i < awardsData.length; i++) {
          var cellValue = awardsData[i][0] ? awardsData[i][0].toString() : "";

          // Section headers (INDIVIDUAL PLAYER AWARDS, TEAM AWARDS, SEASON-LONG AWARDS)
          if (cellValue === "INDIVIDUAL PLAYER AWARDS" || cellValue === "TEAM AWARDS" || cellValue === "SEASON-LONG AWARDS") {
            var headerRange = awardsSheet.getRange(i + 1, 1, 1, 5);
            headerRange.merge();
            headerRange.setFontWeight("bold");
            headerRange.setBackground("#4a86e8");
            headerRange.setFontColor("#ffffff");
            headerRange.setHorizontalAlignment("center");
          }

          // Sub-headers (Award, Player, Position, etc.)
          if (cellValue === "Award") {
            awardsSheet.getRange(i + 1, 1, 1, 5).setFontWeight("bold").setBackground("#d9d9d9");
          }
        }

        // Auto-fit columns
        awardsSheet.autoResizeColumns(1, 5);
      }
      var awardsEndTime = new Date();
      Logger.log("TIMER: Awards completed in " + ((awardsEndTime - awardsStartTime) / 1000) + " seconds");
    } catch (error) {
      errors.push("Awards: " + error.toString());
    }
  } else {
    Logger.log("Skipping provisional Awards; final Awards will be generated after Player Results.");
  }

  // Refresh Owned Draft Picks (if pick trading is enabled)
  var draftPicksStartTime = new Date();
  Logger.log("TIMER: Refreshing Owned Draft Picks at " + draftPicksStartTime.toISOString());
  try {
    var draftPicksData = ImportDraftPickInventory();
    var draftPicksSheet = ss.getSheetByName("Owned Draft Picks");
    if (draftPicksSheet && draftPicksData && draftPicksData.length > 0) {
      draftPicksSheet.clear();
      ensureSheetSize(draftPicksSheet, draftPicksData.length, draftPicksData[0].length);
      draftPicksSheet.getRange(1, 1, draftPicksData.length, draftPicksData[0].length).setValues(draftPicksData);
      draftPicksSheet.getRange(1, 1, draftPicksData.length, draftPicksData[0].length).setHorizontalAlignment("center");

      // Bold header row if it exists
      if (draftPicksData.length > 1 && draftPicksData[0][0] === "Team") {
        draftPicksSheet.getRange(1, 1, 1, draftPicksData[0].length).setFontWeight("bold");
      }

      draftPicksSheet.autoResizeColumns(1, draftPicksData[0].length);
    }
    var draftPicksEndTime = new Date();
    Logger.log("TIMER: Owned Draft Picks completed in " + ((draftPicksEndTime - draftPicksStartTime) / 1000) + " seconds");
  } catch (error) {
    errors.push("Owned Draft Picks: " + error.toString());
  }

  return errors;
}

/**
 * Reset workbook to default state - clears all data without loading
 * This is useful for cleaning up the sheet or preparing for a new season
 */
function ResetToDefaultState() {
  try {
    var ui = SpreadsheetApp.getUi();

    // Confirm with user
    var response = ui.alert(
      'Reset to Default State?',
      'This will clear ALL imported data from the workbook.\n\n' +
      'Are you sure you want to continue?',
      ui.ButtonSet.YES_NO
    );

    if (response !== ui.Button.YES) {
      return;
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var errors = [];

    // NOTE: The "Balance" sheet is intentionally excluded from this reset process.
    // It must remain untouched as it contains manual data.

    // Clear Info sheet (B1:B3)
    try {
      var infoSheet = ss.getSheetByName("Info");
      infoSheet.getRange("B1:B4").clearContent();
      Logger.log("Cleared Info sheet B1:B4");
    } catch (e) {
      errors.push("Info: " + e.toString());
    }

    // Clear Leagues sheet
    try {
      var leaguesSheet = ss.getSheetByName("Leagues");
      leaguesSheet.getRange("A54:IO55").clearContent();
      leaguesSheet.getRange("A1:IO50").clearContent();
      Logger.log("Cleared Leagues sheet");
    } catch (e) {
      errors.push("Leagues: " + e.toString());
    }

    // Clear Settings sheet
    try {
      var settingsSheet = ss.getSheetByName("Settings");
      settingsSheet.getRange("1:2").clearContent();  // Clear rows 1 and 2
      Logger.log("Cleared Settings sheet");
    } catch (e) {
      errors.push("Settings: " + e.toString());
    }

    // Clear Users sheet
    try {
      var usersSheet = ss.getSheetByName("Users");
      // Clear users API data (rows 1-35)
      usersSheet.getRange("1:35").clearContent();
      // Clear rosters API data (rows 36-68, starting at column B)
      usersSheet.getRange("B36:QY68").clearContent();
      Logger.log("Cleared Users sheet");
    } catch (e) {
      errors.push("Users: " + e.toString());
    }

    // Clear all Week sheets (both raw API data and derived data)
    for (var week = 1; week <= 18; week++) {
      try {
        // Clear Week X Data sheet
        var weekDataSheet = ss.getSheetByName("Week " + week + " Data");
        if (weekDataSheet) {
          weekDataSheet.clear();
        }

        var weekSheet = ss.getSheetByName("Week " + week);
        if (weekSheet) {
          // Clear rows 1-68
          weekSheet.getRange("1:68").clearContent();
          // Clear rows 170+ (preserve 69-169)
          var maxRows = weekSheet.getMaxRows();
          if (maxRows >= 170) {
            weekSheet.getRange("170:" + maxRows).clearContent();
          }
          Logger.log("Cleared Week " + week + " sheet (preserving rows 69-169)");
        }
      } catch (e) {
        errors.push("Week " + week + ": " + e.toString());
      }
    }

    // Clear Transactions sheet
    try {
      var transactionsSheet = ss.getSheetByName("Transactions");
      if (transactionsSheet) {
        // Only clear columns A:I
        var lastRow = transactionsSheet.getLastRow();
        if (lastRow > 0) {
          transactionsSheet.getRange(1, 1, lastRow, 9).clearContent();
        }
        Logger.log("Cleared Transactions sheet (columns A:I)");
      }
    } catch (e) {
      errors.push("Transactions: " + e.toString());
    }

    // Clear Standings sheet
    try {
      var standingsSheet = ss.getSheetByName("Standings");
      if (standingsSheet) {
        standingsSheet.clear();
        Logger.log("Cleared Standings sheet");
      }
    } catch (e) {
      errors.push("Standings: " + e.toString());
    }

    // Clear Weekly Results sheet
    try {
      var weeklyResultsSheet = ss.getSheetByName("Weekly Results");
      if (weeklyResultsSheet) {
        weeklyResultsSheet.clear();
        Logger.log("Cleared Weekly Results sheet");
      }
    } catch (e) {
      errors.push("Weekly Results: " + e.toString());
    }

    // Clear Draft Result sheet
    try {
      var draftSheet = ss.getSheetByName("Draft Result");
      if (draftSheet) {
        draftSheet.clear();
        Logger.log("Cleared Draft Result sheet");
      }
    } catch (e) {
      errors.push("Draft Result: " + e.toString());
    }

    // Clear Schedule sheet
    try {
      var scheduleSheet = ss.getSheetByName("Schedule");
      if (scheduleSheet) {
        // Clear for up to 32 teams (rows 2-33) and up to 18 weeks (columns B-S)
        scheduleSheet.getRange("B2:S33").clearContent();
        Logger.log("Cleared Schedule sheet (B2:S33)");
      }
    } catch (e) {
      errors.push("Schedule: " + e.toString());
    }

    // Clear Playoffs sheet
    try {
      var playoffsSheet = ss.getSheetByName("Playoffs");
      if (playoffsSheet) {
        playoffsSheet.clear();
        Logger.log("Cleared Playoffs sheet");
      }
    } catch (e) {
      errors.push("Playoffs: " + e.toString());
    }

    // Clear Awards sheet
    try {
      var awardsSheet = ss.getSheetByName("Awards");
      if (awardsSheet) {
        awardsSheet.clear();
        Logger.log("Cleared Awards sheet");
      }
    } catch (e) {
      errors.push("Awards: " + e.toString());
    }

    // Clear Player Results sheet (FULL CLEAR - headers will be rebuilt)
    try {
      var playerResultsSheet = ss.getSheetByName("Player Results");
      if (playerResultsSheet) {
        playerResultsSheet.clear();
        Logger.log("Cleared Player Results sheet");
      }
    } catch (e) {
      errors.push("Player Results: " + e.toString());
    }

    ["Roster Summary", "Rosters", "Current Rosters"].forEach(function(sheetName) {
      try {
        var rosterOutputSheet = ss.getSheetByName(sheetName);
        if (rosterOutputSheet) {
          rosterOutputSheet.clear();
          Logger.log("Cleared " + sheetName + " sheet");
        }
      } catch (e) {
        errors.push(sheetName + ": " + e.toString());
      }
    });

    // Clear Owned Draft Picks sheet
    try {
      var draftPicksSheet = ss.getSheetByName("Owned Draft Picks");
      if (draftPicksSheet) {
        draftPicksSheet.clear();
        Logger.log("Cleared Owned Draft Picks sheet");
      }
    } catch (e) {
      errors.push("Owned Draft Picks: " + e.toString());
    }

    // Clear Free Agents sheet
    try {
      var freeAgentsSheet = ss.getSheetByName("Free Agents");
      if (freeAgentsSheet) {
        freeAgentsSheet.clear();
        Logger.log("Cleared Free Agents sheet");
      }
    } catch (e) {
      errors.push("Free Agents: " + e.toString());
    }

    // Force recalculation
    SpreadsheetApp.flush();

    // Report results
    if (errors.length === 0) {
      ui.alert(
        'Reset Complete',
        'All data has been cleared.\n\n' +
        'To start fresh:\n' +
        '1. Enter your username in Info!B1\n' +
        '2. Enter the year in Info!B2\n' +
        '3. Enter the current week in Info!B3\n' +
        '4. Run "Refresh Step 1"',
        ui.ButtonSet.OK
      );
    } else {
      ui.alert(
        'Reset Completed with Errors',
        'Some sheets could not be cleared:\n\n' + errors.join('\n'),
        ui.ButtonSet.OK
      );
    }

  } catch (error) {
    SpreadsheetApp.getUi().alert('Error', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  }
}

/**
 * Clear only future week data (weeks after current week)
 * Useful for mid-season cleanup
 */
function ClearFutureWeeks() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var currentWeek = infoSheet.getRange("B3").getValue();

    if (!currentWeek || currentWeek < 1 || currentWeek > 18) {
      throw new Error("Please enter a valid current week (1-18) in Info!B3");
    }

    var cleared = [];

    // Clear weeks after current week
    for (var week = currentWeek + 1; week <= 18; week++) {
      try {
        var weekSheet = ss.getSheetByName("Week " + week);
        if (weekSheet) {
          weekSheet.getRange("1:20").clearContent();  // Only clear rows 1-20
          cleared.push(week);
        }
      } catch (e) {
        Logger.log("Error clearing Week " + week + ": " + e.toString());
      }
    }

    // Get league ID for refreshing derived data
    try {
      var leagueId = GetSelectedLeagueId();

      // Refresh Transactions to only show data through current week
      try {
        var transactionsData = ImportSleeperTransactions(leagueId, currentWeek, true);
        var transactionsSheet = ss.getSheetByName("Transactions");
        if (transactionsSheet && transactionsData && transactionsData.length > 0) {
          // Only clear columns A:I
          var lastRow = transactionsSheet.getLastRow();
          if (lastRow > 0) {
            transactionsSheet.getRange(1, 1, lastRow, 9).clearContent();
          }
          // Write new data
          transactionsSheet.getRange(1, 1, transactionsData.length, transactionsData[0].length).setValues(transactionsData);
        }
      } catch (e) {
        Logger.log("Error updating Transactions: " + e.toString());
      }

      // Refresh Standings to only show data through current week
      try {
        var standingsData = CalculateDetailedStandings(currentWeek);
        var standingsSheet = ss.getSheetByName("Standings");
        if (standingsSheet && standingsData && standingsData.length > 0) {
          standingsSheet.clear();
          standingsSheet.getRange(1, 1, standingsData.length, standingsData[0].length).setValues(standingsData);
        }
      } catch (e) {
        Logger.log("Error updating Standings: " + e.toString());
      }

    } catch (e) {
      Logger.log("Could not refresh derived data: " + e.toString());
    }

    // Show completion message
    var message = "";
    if (cleared.length > 0) {
      message = "Cleared weeks: " + cleared.join(", ") + "\n";
    } else {
      message = "No future weeks to clear\n";
    }
    message += "\nTransactions and Standings updated through week " + currentWeek;

    SpreadsheetApp.getActiveSpreadsheet().toast(
      message,
      "Future Weeks Cleared",
      5
    );

  } catch (error) {
    SpreadsheetApp.getUi().alert('Error', error.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  }
}

/**
 * Helper function to get a setting value from the Settings sheet by header name
 * @param {Sheet} settingsSheet - The Settings sheet
 * @param {string} headerName - The header to search for (e.g., "/settings/playoff_teams")
 * @return {*} - The value or null if not found
 */
function getSettingValue(settingsSheet, headerName) {
  try {
    // Get only the used range instead of entire rows (much faster)
    var lastCol = settingsSheet.getLastColumn();
    if (lastCol < 1) return null;

    var headers = settingsSheet.getRange(1, 1, 1, lastCol).getValues()[0];
    var values = settingsSheet.getRange(2, 1, 1, lastCol).getValues()[0];

    for (var i = 0; i < headers.length; i++) {
      if (headers[i] === headerName) {
        return values[i];
      }
    }
    return null;
  } catch (e) {
    Logger.log("Error getting setting " + headerName + ": " + e.toString());
    return null;
  }
}

/**
 * Calculate which week a playoff round occurs in
 * @param {number} round - The round number (1, 2, 3, etc.)
 * @param {number} playoffWeekStart - The week playoffs start
 * @param {number} playoffRoundType - 0=1 week/round, 1=2 week championship, 2=2 weeks/round
 * @return {number} - The week number
 */
function getPlayoffWeekForRound(round, playoffWeekStart, playoffRoundType) {
  if (playoffRoundType === 0) {
    // 1 week per round
    return playoffWeekStart + (round - 1);
  } else if (playoffRoundType === 1) {
    // 2 week championship only (round 1 and 2 are 1 week each, finals is 2 weeks)
    // This is more complex - need to know total rounds
    return playoffWeekStart + (round - 1);
  } else if (playoffRoundType === 2) {
    // 2 weeks per round
    return playoffWeekStart + ((round - 1) * 2);
  }
  return playoffWeekStart + (round - 1);
}

/**
 * Get total score for a team in a playoff matchup (handles 2-week matchups)
 * @param {number} rosterId - The roster ID
 * @param {number} round - The round number
 * @param {Object} weeklyScores - Object containing scores by week and roster
 * @param {number} playoffWeekStart - The week playoffs start
 * @param {number} playoffRoundType - The playoff round type setting
 * @param {number} maxRound - The maximum round number (for 2-week championship check)
 * @return {number|null} - The total score or null if not yet played
 */
function getPlayoffScore(rosterId, round, weeklyScores, playoffWeekStart, playoffRoundType, maxRound) {
  if (!rosterId) return null;

  var week1 = getPlayoffWeekForRound(round, playoffWeekStart, playoffRoundType);
  var score1 = weeklyScores[week1] && weeklyScores[week1][rosterId.toString()];

  // Check for 2-week matchup
  var is2WeekMatchup = playoffRoundType === 2 || (playoffRoundType === 1 && round === maxRound);

  if (is2WeekMatchup) {
    var week2 = week1 + 1;
    var score2 = weeklyScores[week2] && weeklyScores[week2][rosterId.toString()];

    if (score1 !== undefined && score2 !== undefined) {
      return (parseFloat(score1) || 0) + (parseFloat(score2) || 0);
    } else if (score1 !== undefined) {
      return parseFloat(score1) || 0;
    }
    return null;
  }

  return score1 !== undefined ? (parseFloat(score1) || 0) : null;
}

/**
 * Build the tabular playoff data - one row per team
 * Format: Bracket, Round, Week, Team, Score, Opponent, Opponent Score, Advanced
 */
function buildPlayoffTabularData(winnersBracket, losersBracket, userLookup, weeklyScores,
  playoffWeekStart, playoffRoundType, playoffType) {
  var result = [];

  // Determine max round for 2-week championship check
  var maxRound = Math.max(
    winnersBracket.length > 0 ? Math.max.apply(null, winnersBracket.map(function (m) { return m.r || 0; })) : 0,
    losersBracket.length > 0 ? Math.max.apply(null, losersBracket.map(function (m) { return m.r || 0; })) : 0
  );

  // Filter to only completed matchups (has a winner)
  var completedWinners = winnersBracket.filter(function (m) { return m.w !== null && m.w !== undefined; });
  var completedLosers = losersBracket.filter(function (m) { return m.w !== null && m.w !== undefined; });

  // Sort by round, then by matchup number
  completedWinners.sort(function (a, b) {
    if (a.r !== b.r) return a.r - b.r;
    return (a.m || 0) - (b.m || 0);
  });
  completedLosers.sort(function (a, b) {
    if (a.r !== b.r) return a.r - b.r;
    return (a.m || 0) - (b.m || 0);
  });

  // Header row (8 columns)
  result.push(["Bracket", "Round", "Week", "Team", "Score", "Opponent", "Opponent Score", "Advanced"]);

  // Process Winners bracket - one row per team
  completedWinners.forEach(function (matchup) {
    var rows = buildTeamRows(matchup, "Winners", userLookup, weeklyScores,
      playoffWeekStart, playoffRoundType, maxRound, false);
    result = result.concat(rows);
  });

  // Process Losers bracket - one row per team
  var loserBracketName = playoffType === 0 ? "Losers" : "Consolation";
  var isToiletBowl = playoffType === 0;

  completedLosers.forEach(function (matchup) {
    var rows = buildTeamRows(matchup, loserBracketName, userLookup, weeklyScores,
      playoffWeekStart, playoffRoundType, maxRound, isToiletBowl);
    result = result.concat(rows);
  });

  return result;
}

/**
 * Build two rows (one per team) for a matchup
 * Returns array of two rows: [team1Row, team2Row]
 */
function buildTeamRows(matchup, bracketName, userLookup, weeklyScores,
  playoffWeekStart, playoffRoundType, maxRound, isToiletBowl) {
  var rows = [];
  var round = matchup.r || 0;
  var week = getPlayoffWeekForRound(round, playoffWeekStart, playoffRoundType);

  // Handle 2-week matchups for week display
  var weekDisplay = week;
  var is2WeekMatchup = playoffRoundType === 2 || (playoffRoundType === 1 && round === maxRound);
  if (is2WeekMatchup) {
    weekDisplay = week + "-" + (week + 1);
  }

  var team1Id = matchup.t1;
  var team2Id = matchup.t2;
  var team1Name = team1Id ? (userLookup[team1Id.toString()] || "Roster " + team1Id) : "";
  var team2Name = team2Id ? (userLookup[team2Id.toString()] || "Roster " + team2Id) : "";

  var score1 = getPlayoffScore(team1Id, round, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
  var score2 = getPlayoffScore(team2Id, round, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

  // Determine who advanced
  // In Toilet Bowl (isToiletBowl=true), the loser advances. In others, winner advances.
  var advancerId = isToiletBowl ? matchup.l : matchup.w;

  var team1Advanced, team2Advanced;
  team1Advanced = advancerId && team1Id && advancerId.toString() === team1Id.toString() ? "Yes" : "No";
  team2Advanced = advancerId && team2Id && advancerId.toString() === team2Id.toString() ? "Yes" : "No";

  // Team 1 row
  rows.push([
    bracketName,
    round,
    weekDisplay,
    team1Name,
    score1 !== null ? score1.toFixed(2) : "",
    team2Name,
    score2 !== null ? score2.toFixed(2) : "",
    team1Advanced
  ]);

  // Team 2 row
  rows.push([
    bracketName,
    round,
    weekDisplay,
    team2Name,
    score2 !== null ? score2.toFixed(2) : "",
    team1Name,
    score1 !== null ? score1.toFixed(2) : "",
    team2Advanced
  ]);

  return rows;
}

/**
 * Get placement label from placement number
 */
function getPlacementLabel(p, isLosersBracket, isToiletBowl, playoffTeams) {
  // For winners bracket, p values are actual placements (3rd, 5th)
  // For losers bracket, we need to calculate based on playoff teams
  // In a 6-team playoff:
  //   - Winners bracket: 1st, 2nd (championship), 3rd, 5th (placement games)
  //   - Losers bracket (Consolation): 7th, 8th (final), 9th, 11th (placement games)
  //   - Losers bracket (Toilet Bowl): 7th, 8th (final), 9th, 11th (placement games) - but p=3 is 9th place game, p=5 is 11th place game

  if (!isLosersBracket) {
    // Winners bracket - use p directly
    if (p === 1) return "1st Place";
    if (p === 2) return "2nd Place";
    if (p === 3) return "3rd Place";
    if (p === 5) return "5th Place";
    if (p >= 4) return p + "th Place";
    return "";
  }

  // Losers bracket - calculate actual placement
  // playoffTeams is the number of teams in playoffs (typically 6)
  // Teams not in playoffs start at position playoffTeams + 1 (7th for 6-team playoffs)
  var nonPlayoffStart = (playoffTeams || 6) + 1;  // e.g., 7 for 6-team playoffs

  if (isToiletBowl) {
    // Toilet Bowl (Loser advances)
    // p=5 are R1 winners (safe) -> 7th Place
    // p=3 are R2 winners (safe) -> 9th Place
    if (p === 5) return getOrdinal(nonPlayoffStart) + " Place";
    if (p === 3) return getOrdinal(nonPlayoffStart + 2) + " Place";
  }

  // p=1 is the losers bracket final (7th/8th place game)
  // p=3 is the first placement game (9th/10th place game)
  // p=5 is the second placement game (11th/12th place game)

  if (p === 1) {
    // Final game - winner gets nonPlayoffStart position
    return getOrdinal(nonPlayoffStart) + " Place";
  } else if (p === 3) {
    // First placement game - winner gets nonPlayoffStart + 2
    return getOrdinal(nonPlayoffStart + 2) + " Place";
  } else if (p === 5) {
    // Second placement game - winner gets nonPlayoffStart + 4
    return getOrdinal(nonPlayoffStart + 4) + " Place";
  }

  // Fallback
  return getOrdinal(p) + " Place";
}

/**
 * Get ordinal suffix for a number (1st, 2nd, 3rd, etc.)
 */
function getOrdinal(n) {
  var s = ["th", "st", "nd", "rd"];
  var v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

/**
 * Build the visual bracket and apply formatting
 * This writes data and then applies cell borders/formatting to create a proper bracket
 */
function buildPlayoffVisualBracket(winnersBracket, losersBracket, userLookup, weeklyScores,
  playoffWeekStart, playoffRoundType, playoffTeams, playoffType) {
  // Return empty array - the visual bracket will be built separately with formatting
  // by the formatPlayoffBracket function called from ImportPlayoffBrackets
  return [];
}

/**
 * Build and format the visual playoff bracket with proper cell borders
 * @param {Sheet} sheet - The Playoffs sheet
 * @param {number} startRow - Row to start the visual bracket
 * @param {Array} winnersBracket - Winners bracket data from API
 * @param {Array} losersBracket - Losers bracket data from API
 * @param {Object} userLookup - Roster ID to username mapping
 * @param {Object} weeklyScores - Scores by week and roster
 * @param {number} playoffWeekStart - First playoff week
 * @param {number} playoffRoundType - Playoff round type setting
 * @param {number} playoffTeams - Number of playoff teams
 * @param {number} playoffType - 0=Toilet Bowl, 1=Consolation
 */
function formatPlayoffBracket(sheet, startRow, winnersBracket, losersBracket, userLookup, weeklyScores,
  playoffWeekStart, playoffRoundType, playoffTeams, playoffType) {

  var maxRound = winnersBracket.length > 0 ?
    Math.max.apply(null, winnersBracket.map(function (m) { return m.r || 0; })) : 0;

  // ===== WINNERS BRACKET =====
  var currentRow = startRow;

  // Reset formatting for the visual area to prevent color bleeding
  // Clear any existing backgrounds or borders from previous runs
  var maxRows = sheet.getMaxRows();
  var maxCols = sheet.getMaxColumns();
  if (maxRows > startRow) {
    sheet.getRange(startRow, 1, maxRows - startRow + 1, 11).setBackground(null).setBorder(false, false, false, false, false, false);
  }

  // Set explicit column widths for the bracket
  sheet.setColumnWidths(1, 1, 160); // Team 1 Name
  sheet.setColumnWidths(2, 1, 50);  // Team 1 Score
  sheet.setColumnWidths(3, 1, 20);  // Connector
  sheet.setColumnWidths(4, 1, 160); // Team 2 Name
  sheet.setColumnWidths(5, 1, 50);  // Team 2 Score
  sheet.setColumnWidths(6, 1, 20);  // Connector
  sheet.setColumnWidths(7, 1, 160); // Team 3 Name (Championship)
  sheet.setColumnWidths(8, 1, 50);  // Team 3 Score
  sheet.setColumnWidths(9, 1, 20);  // Connector
  sheet.setColumnWidths(10, 1, 160); // Champion Name
  sheet.setColumnWidths(11, 1, 20);  // Buffer

  // Title
  sheet.getRange(currentRow, 1).setValue("WINNERS BRACKET");
  sheet.getRange(currentRow, 1, 1, 11).merge();
  sheet.getRange(currentRow, 1).setFontWeight("bold").setFontSize(14).setHorizontalAlignment("center");
  sheet.getRange(currentRow, 1, 1, 11).setBackground("#1a472a");  // Dark green
  sheet.getRange(currentRow, 1, 1, 11).setFontColor("#ffffff");
  currentRow += 2;

  // Round headers
  var headerRow = currentRow;
  for (var r = 1; r <= maxRound; r++) {
    var col = 1 + (r - 1) * 3;  // Columns 1, 4, 7 for rounds 1, 2, 3
    var week = getPlayoffWeekForRound(r, playoffWeekStart, playoffRoundType);
    var is2Week = playoffRoundType === 2 || (playoffRoundType === 1 && r === maxRound);

    var roundName = "Round " + r;
    if (r === maxRound) roundName = "Championship";
    else if (r === maxRound - 1 && maxRound > 1) roundName = "Semifinals";

    var weekLabel = is2Week ? "(Week " + week + "-" + (week + 1) + ")" : "(Week " + week + ")";

    sheet.getRange(headerRow, col).setValue(roundName);
    sheet.getRange(headerRow, col).setFontWeight("bold").setHorizontalAlignment("center");
    sheet.getRange(headerRow + 1, col).setValue(weekLabel);
    sheet.getRange(headerRow + 1, col).setFontSize(9).setHorizontalAlignment("center").setFontColor("#666666");
  }
  currentRow += 3;

  // Build bracket structure based on number of teams (Winners bracket: isLosersBracket = false)
  currentRow = buildBracketWithFormatting(sheet, currentRow, winnersBracket, userLookup, weeklyScores,
    playoffWeekStart, playoffRoundType, maxRound, false, playoffTeams, false);

  currentRow += 3;

  // ===== LOSERS BRACKET =====
  var loserMaxRound = losersBracket.length > 0 ?
    Math.max.apply(null, losersBracket.map(function (m) { return m.r || 0; })) : 0;

  // playoffType: 0 = Toilet Bowl (loser advances), 1 = Consolation (winner advances)
  var isToiletBowl = playoffType === 0;
  var loserTitle = isToiletBowl ? "TOILET BOWL" : "CONSOLATION BRACKET";

  // Title
  sheet.getRange(currentRow, 1).setValue(loserTitle);
  sheet.getRange(currentRow, 1, 1, 11).merge();
  sheet.getRange(currentRow, 1).setFontWeight("bold").setFontSize(14).setHorizontalAlignment("center");
  if (isToiletBowl) {
    sheet.getRange(currentRow, 1, 1, 11).setBackground("#4a1a1a");  // Dark red for Toilet Bowl
  } else {
    sheet.getRange(currentRow, 1, 1, 11).setBackground("#2a4a2a");  // Dark green for Consolation Bracket
  }
  sheet.getRange(currentRow, 1, 1, 11).setFontColor("#ffffff");
  currentRow += 2;

  // Round headers for losers bracket
  headerRow = currentRow;
  for (var r = 1; r <= loserMaxRound; r++) {
    var col = 1 + (r - 1) * 3;
    var week = getPlayoffWeekForRound(r, playoffWeekStart, playoffRoundType);
    var is2Week = playoffRoundType === 2 || (playoffRoundType === 1 && r === loserMaxRound);

    var roundName = "Round " + r;
    if (r === loserMaxRound) roundName = "Final";

    var weekLabel = is2Week ? "(Week " + week + "-" + (week + 1) + ")" : "(Week " + week + ")";

    sheet.getRange(headerRow, col).setValue(roundName);
    sheet.getRange(headerRow, col).setFontWeight("bold").setHorizontalAlignment("center");
    sheet.getRange(headerRow + 1, col).setValue(weekLabel);
    sheet.getRange(headerRow + 1, col).setFontSize(9).setHorizontalAlignment("center").setFontColor("#666666");
  }
  currentRow += 3;

  // Build losers bracket (isLosersBracket = true)
  buildBracketWithFormatting(sheet, currentRow, losersBracket, userLookup, weeklyScores,
    playoffWeekStart, playoffRoundType, loserMaxRound, isToiletBowl, playoffTeams, true);
}

/**
 * Build bracket matching the exact layout from Playoffs Example.xlsx
 * With color highlighting for advancing teams and champion display
 *
 * Key insight: Top section flows DOWN (bye->matchup), Bottom section flows UP (matchup->bye)
 * This creates a symmetrical bracket centered on the championship
 *
 * @param {boolean} isToiletBowl - true for Toilet Bowl (loser advances), false for Winners/Consolation (winner advances)
 * @param {boolean} isLosersBracket - true if this is the losers/consolation bracket (for color coding)
 */
function buildBracketWithFormatting(sheet, startRow, bracketData, userLookup, weeklyScores,
  playoffWeekStart, playoffRoundType, maxRound, isToiletBowl, playoffTeams, isLosersBracket) {

  // Define highlight colors
  var winnerHighlight = "#d4edda";  // Light green for winners
  var toiletBowlHighlight = "#f8d7da";  // Light red for toilet bowl advancers (losers)

  // Helper function to determine if a team advances
  function doesTeamAdvance(matchup, teamId) {
    if (!matchup || !teamId) return false;

    // Use scores if available to be robust against API inconsistencies (especially in Toilet Bowl)
    var r = matchup.r || 0;
    var s1 = getPlayoffScore(matchup.t1, r, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
    var s2 = getPlayoffScore(matchup.t2, r, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

    if (s1 !== null && s2 !== null && s1 !== s2) {
      var advancerId = isToiletBowl ? ((s1 < s2) ? matchup.t1 : matchup.t2) : ((s1 > s2) ? matchup.t1 : matchup.t2);
      return advancerId && advancerId.toString() === teamId.toString();
    }

    // Fallback to API fields if scores unavailable or tied
    var advancerId = isToiletBowl ? matchup.l : matchup.w;
    return advancerId && advancerId.toString() === teamId.toString();
  }

  // Helper function to get highlight color
  function getHighlightColor() {
    if (isLosersBracket && isToiletBowl) {
      return toiletBowlHighlight;  // Red for toilet bowl
    }
    return winnerHighlight;  // Green for winners/consolation
  }

  // Helper function to apply advancing team formatting
  function formatAdvancingTeam(row, col) {
    sheet.getRange(row, col).setFontWeight("bold");
    sheet.getRange(row, col, 1, 2).setBackground(getHighlightColor());
  }

  // Create lookup for matchups by matchup number
  var matchupLookup = {};
  bracketData.forEach(function (m) {
    matchupLookup[m.m] = m;
  });

  // Group matchups by round
  var matchupsByRound = {};
  for (var r = 1; r <= maxRound; r++) {
    matchupsByRound[r] = bracketData.filter(function (m) { return m.r === r; });
  }

  var round2Matchups = (matchupsByRound[2] || []).filter(function (m) { return !m.p || m.p === 1; });
  var championshipMatchups = (matchupsByRound[maxRound] || []).filter(function (m) { return !m.p || m.p === 1; });
  var placementMatchups = bracketData.filter(function (m) { return m.p && m.p > 1; });

  // Sort round 2 by matchup number
  round2Matchups.sort(function (a, b) { return a.m - b.m; });

  // Helper: set bottom border
  function setBottom(row, col, numCols, color, style) {
    sheet.getRange(row, col, 1, numCols || 1).setBorder(null, null, true, null, null, null,
      color || "#000000", style || SpreadsheetApp.BorderStyle.THIN);
  }

  // Helper: set right border
  function setRight(row, col, color, style) {
    sheet.getRange(row, col).setBorder(null, null, null, true, null, null,
      color || "#000000", style || SpreadsheetApp.BorderStyle.THIN);
  }

  // Helper: set bottom+right border
  function setBottomRight(row, col, color, style) {
    sheet.getRange(row, col).setBorder(null, null, true, true, null, null,
      color || "#000000", style || SpreadsheetApp.BorderStyle.THIN);
  }

  // Get semifinals
  var semi1 = round2Matchups[0]; // Top Semi (Seed 1's side)
  var semi2 = round2Matchups[1]; // Bottom Semi (Seed 2's side)
  var championship = championshipMatchups[0];

  // Helper to normalize matchup: returns { byeTeam: string|null, r1Matchup: object|null, r1Winner: string|null }
  // Ensures we know WHO is the bye and WHO came from R1, regardless of t1/t2 position
  function getSemiParticipants(semiMatchup) {
    if (!semiMatchup) return { byeTeam: null, r1Matchup: null, r1Winner: null, byeIsT1: false };

    var t1 = semiMatchup.t1;
    var t2 = semiMatchup.t2;
    var t1From = semiMatchup.t1_from; // {w: 1} or {l: 1} or null
    var t2From = semiMatchup.t2_from;

    var byeTeam = null;
    var r1Matchup = null;
    var r1Winner = null;
    var byeIsT1 = false;

    // Detect Source
    // If t1 has NO source but t2 DOES, t1 is Bye.
    // If t2 has NO source but t1 DOES, t2 is Bye.
    // (Standard 6-team bracket logic)

    if (t1 && !t1From && t2From) {
      // T1 is Bye
      byeTeam = t1;
      byeIsT1 = true;
      if (t2From.w) {
        r1Matchup = matchupLookup[t2From.w];
        r1Winner = t2;
      }
    } else if (t2 && !t2From && t1From) {
      // T2 is Bye
      byeTeam = t2;
      byeIsT1 = false;
      if (t1From.w) {
        r1Matchup = matchupLookup[t1From.w];
        r1Winner = t1;
      }
    } else {
      // No standard bye found (maybe 4 team or 8 team bracket, or both from R1)
      // Fallback: Assume T1 is "Top/Bye Slot" equivalent for visual purposes if forced
      // But for 6-team formatting, we really expect one Bye.
      // If both from R1, this logic needs to be robust. 
      // For now, if both have sources, treat NEITHER as Bye (will be blank name + BYE label potentially if we don't handle it)
      // But standard code assumes Bye.
      // If we have a 4-team bracket (No R1), t1_from/t2_from are null.
      // Then both are "Byes"?? No, they just start here.
      if (!t1From && !t2From) {
        // First round of a bracket (e.g. 4 teams).
        // No "Bye" visually, just 2 teams. 
        // This function is for 6-team style rendering where Semi follows R1.
        // We will output nulls.
      }
    }
    return { byeTeam: byeTeam, r1Matchup: r1Matchup, r1Winner: r1Winner, byeIsT1: byeIsT1 };
  }

  var s1Data = getSemiParticipants(semi1);
  var s2Data = getSemiParticipants(semi2);

  // =====================================================
  // TOP SECTION (Semifinal 1) - flows DOWN
  // Visual expectation:
  // Row 17: Bye Name
  // Row 19: Semi Slot 1 (Linked to Bye)
  // Row 21: Semi Slot 2 (Linked to R1 Matchup)
  // =====================================================
  var r = startRow;

  // Row 0 (17): Bye team name
  if (s1Data.byeTeam) {
    sheet.getRange(r, 1).setValue(userLookup[s1Data.byeTeam.toString()] || "TBD");
  }
  setBottom(r, 1, 2);

  // Row 1 (18): connectors
  setRight(r + 1, 2);
  setBottom(r + 1, 3);

  // Row 2 (19): BYE label and Semi Slot 1 (The Bye Team)
  sheet.getRange(r + 2, 1).setValue("BYE");
  sheet.getRange(r + 2, 1).setFontColor("#999999").setFontStyle("italic");
  setBottom(r + 2, 1, 2);
  setBottomRight(r + 2, 2);
  setRight(r + 2, 3);

  if (semi1) {
    // Top Slot (Row 19) gets the Bye Team
    var topTeamId = s1Data.byeTeam; // Or semi1.t1 if normal fallback?
    // If no explicit bye (e.g. 8 team bracket), this slot takes semi1.t1
    if (!topTeamId && semi1.t1 && !s1Data.r1Winner) topTeamId = semi1.t1; // Fallback

    if (topTeamId) {
      sheet.getRange(r + 2, 4).setValue(userLookup[topTeamId.toString()] || "TBD");
      // Add score
      var score = getPlayoffScore(topTeamId, 2, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
      if (score !== null) sheet.getRange(r + 2, 5).setValue(score);
      // Highlight if advances
      if (doesTeamAdvance(semi1, topTeamId)) {
        formatAdvancingTeam(r + 2, 4);
      }
    }
    setBottom(r + 2, 4, 2);
  }

  // Row 3 (20): connectors
  setRight(r + 3, 5);
  setBottom(r + 3, 6);

  // Row 4 (21): R1 Matchup (Team 1) and Semi Slot 2 (R1 Winner/Challenger)
  // This slot (Row 21, Col D) is where the R1 Winner goes.
  if (s1Data.r1Matchup) {
    // Fill visual R1 Bracket
    var m = s1Data.r1Matchup;
    var t1Name = m.t1 ? (userLookup[m.t1.toString()] || "TBD") : "TBD";
    var t1Score = getPlayoffScore(m.t1, 1, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

    sheet.getRange(r + 4, 1).setValue(t1Name);
    if (t1Score !== null) sheet.getRange(r + 4, 2).setValue(t1Score);
    if (doesTeamAdvance(m, m.t1)) formatAdvancingTeam(r + 4, 1);
  }
  setBottom(r + 4, 1, 2);

  if (semi1) {
    // Bottom Slot (Row 21) gets the R1 Winner (or Challenger)
    var botTeamId = s1Data.r1Winner;
    // Fallback if structure is weird (e.g. 8 teams both from R1) -> Use t2?
    if (!botTeamId && semi1.t2 && semi1.t2 !== s1Data.byeTeam) botTeamId = semi1.t2;

    if (botTeamId) {
      sheet.getRange(r + 4, 4).setValue(userLookup[botTeamId.toString()] || "TBD");
      var score = getPlayoffScore(botTeamId, 2, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
      if (score !== null) sheet.getRange(r + 4, 5).setValue(score);
      if (doesTeamAdvance(semi1, botTeamId)) {
        formatAdvancingTeam(r + 4, 4);
      }
    }
    setBottom(r + 4, 4, 2);
    setBottomRight(r + 4, 5);
    setRight(r + 4, 6);
  }

  // Row 5 (22): connectors
  setRight(r + 5, 2);
  setBottomRight(r + 5, 3);

  // Row 6 (23): R1 Matchup (Team 2)
  if (s1Data.r1Matchup) {
    var m = s1Data.r1Matchup;
    var t2Name = m.t2 ? (userLookup[m.t2.toString()] || "TBD") : "TBD";
    var t2Score = getPlayoffScore(m.t2, 1, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

    sheet.getRange(r + 6, 1).setValue(t2Name);
    if (t2Score !== null) sheet.getRange(r + 6, 2).setValue(t2Score);
    if (doesTeamAdvance(m, m.t2)) formatAdvancingTeam(r + 6, 1);
  }
  setBottom(r + 6, 1, 2);
  setBottomRight(r + 6, 2);

  // =====================================================
  // VERTICAL CONNECTOR (Col F)
  // =====================================================
  setRight(r + 5, 6);
  setRight(r + 6, 6);
  setRight(r + 7, 6);
  setRight(r + 8, 6);

  // =====================================================
  // CHAMPIONSHIP - centered between sections
  // Based on template rows 24-26
  // =====================================================
  // Row 7 (24): G:championship team 1 with top gold border, H:right (medium gold)
  if (championship) {
    sheet.getRange(r + 7, 7).setValue(championship.t1 ? (userLookup[championship.t1.toString()] || "TBD") : "TBD");
    // Add score for championship team 1
    var champ1Score = getPlayoffScore(championship.t1, 3, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
    if (champ1Score !== null) sheet.getRange(r + 7, 8).setValue(champ1Score);
    // Check if championship.t1 wins
    if (doesTeamAdvance(championship, championship.t1)) {
      formatAdvancingTeam(r + 7, 7);
    }
    // Top golden border on G24:H24
    sheet.getRange(r + 7, 7, 1, 2).setBorder(true, null, null, null, null, null, "#d4af37", SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
    setRight(r + 7, 8, "#d4af37", SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
  }

  // Row 8 (25): H:right (medium gold)
  setRight(r + 8, 8, "#d4af37", SpreadsheetApp.BorderStyle.SOLID_MEDIUM);

  // Row 9 (26): G:championship team 2 with bottom, H:bottom+right (medium gold)
  if (championship) {
    sheet.getRange(r + 9, 7).setValue(championship.t2 ? (userLookup[championship.t2.toString()] || "TBD") : "TBD");
    // Add score for championship team 2
    var champ2Score = getPlayoffScore(championship.t2, 3, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
    if (champ2Score !== null) sheet.getRange(r + 9, 8).setValue(champ2Score);
    // Check if championship.t2 wins
    if (doesTeamAdvance(championship, championship.t2)) {
      formatAdvancingTeam(r + 9, 7);
    }
    setBottom(r + 9, 7, 2, "#d4af37", SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
    setBottomRight(r + 9, 8, "#d4af37", SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
  }

  // Continue vertical connector (column F) from row 26 down to row 29
  setRight(r + 9, 6);
  setRight(r + 10, 6);
  setRight(r + 11, 6);

  // =====================================================
  // CHAMPIONSHIP (Rows 24-26)
  // =====================================================
  // ... (Existing code for champ seems fine as it uses t1/t2 directly from champ matchup) ...
  // Actually, we must ensure champ matchup output matches what users expect. 
  // Standard Sleeper: Champ t1 comes from Semi 1? Champ t2 from Semi 2?
  // Usually M_Champ.t1_from = {w: Semi1_ID} etc.
  // We'll rely on t1/t2 order in the API for now, but drawing logic is below.

  // =====================================================
  // BOTTOM SECTION (Semifinal 2) - flows UP
  // Visual layout requirements:
  // Row 28 (r+11): Semi Slot 1 (Linked to R1 Matchup)  <-- THIS IS THE TOP SLOT OF BOTTOM SECTION
  // Row 30 (r+13): Semi Slot 2 (Linked to Bye)         <-- THIS IS THE BOTTOM SLOT OF BOTTOM SECTION
  // Row 32 (r+15): Bye Name
  // =====================================================

  // Logic Fix: Previous code put Bye Team in Row 28 (Top) but label in Row 30 (Bottom).
  // We MUST put R1 Winner in Row 28 (Top) and Bye Team in Row 30 (Bottom).

  // Row 9 (26): R1 Matchup Team 1 (Col A)
  // Note: Championship team 2 is also on this row in Col G (handled by keep section if we don't overwrite it)
  // We need to be careful not to touch Col G here if we can avoid it, OR re-write it.
  // The original code handled Champ writing before Bottom Section.
  // We are rewriting Bottom Section logic now.

  // R1 Matchup for Semi 2
  if (s2Data.r1Matchup) {
    var m = s2Data.r1Matchup;
    var t1Name = m.t1 ? (userLookup[m.t1.toString()] || "TBD") : "TBD";
    var t1Score = getPlayoffScore(m.t1, 1, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

    sheet.getRange(r + 9, 1).setValue(t1Name);
    if (t1Score !== null) sheet.getRange(r + 9, 2).setValue(t1Score);
    if (doesTeamAdvance(m, m.t1)) formatAdvancingTeam(r + 9, 1);
  }
  setBottom(r + 9, 1, 2);

  // Row 10 (27): connectors
  setRight(r + 10, 2);
  setBottom(r + 10, 3);

  // Row 11 (28): R1 Matchup Team 2 (Col A) AND Semi Slot 1 (R1 Winner) (Col D)
  if (s2Data.r1Matchup) {
    var m = s2Data.r1Matchup;
    var t2Name = m.t2 ? (userLookup[m.t2.toString()] || "TBD") : "TBD";
    var t2Score = getPlayoffScore(m.t2, 1, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

    sheet.getRange(r + 11, 1).setValue(t2Name);
    if (t2Score !== null) sheet.getRange(r + 11, 2).setValue(t2Score);
    if (doesTeamAdvance(m, m.t2)) formatAdvancingTeam(r + 11, 1);
  }
  setBottom(r + 11, 1, 2);
  setBottomRight(r + 11, 2);
  setRight(r + 11, 3);

  if (semi2) {
    // Semi Slot 1 (Row 28) - This is visually connected to R1.
    // So we put result.r1Winner here.
    var topTeamId = s2Data.r1Winner;
    if (!topTeamId && semi2.t2 && semi2.t2 !== s2Data.byeTeam) topTeamId = semi2.t2; // Fallback

    if (topTeamId) {
      sheet.getRange(r + 11, 4).setValue(userLookup[topTeamId.toString()] || "TBD");
      var score = getPlayoffScore(topTeamId, 2, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
      if (score !== null) sheet.getRange(r + 11, 5).setValue(score);
      if (doesTeamAdvance(semi2, topTeamId)) {
        formatAdvancingTeam(r + 11, 4);
      }
    }
    setBottom(r + 11, 4, 2);
  }

  // Row 12 (29): connectors
  setRight(r + 12, 5);
  setBottomRight(r + 12, 6);

  // Row 13 (30): Bye Name (Col A) AND Semi Slot 2 (Bye Team) (Col D)
  if (s2Data.byeTeam) {
    sheet.getRange(r + 13, 1).setValue(userLookup[s2Data.byeTeam.toString()] || "TBD");
  }
  setBottom(r + 13, 1, 2);

  if (semi2) {
    // Semi Slot 2 (Row 30) - This is visually connected to Bye.
    // So we put result.byeTeam here.
    var botTeamId = s2Data.byeTeam;
    if (!botTeamId && semi2.t1 && !s2Data.r1Winner) botTeamId = semi2.t1; // Fallback

    if (botTeamId) {
      sheet.getRange(r + 13, 4).setValue(userLookup[botTeamId.toString()] || "TBD");
      var score = getPlayoffScore(botTeamId, 2, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
      if (score !== null) sheet.getRange(r + 13, 5).setValue(score);
      if (doesTeamAdvance(semi2, botTeamId)) {
        formatAdvancingTeam(r + 13, 4);
      }
    }
    setBottom(r + 13, 4, 2);
    setBottomRight(r + 13, 5);
  }

  // Row 14 (31): connectors
  setRight(r + 14, 2);
  setBottomRight(r + 14, 3);

  // Row 15 (32): BYE label (Col A)
  sheet.getRange(r + 15, 1).setValue("BYE");
  sheet.getRange(r + 15, 1).setFontColor("#999999").setFontStyle("italic");
  setBottom(r + 15, 1, 2);
  setBottomRight(r + 15, 2);

  // =====================================================
  // CHAMPION/WINNER DISPLAY
  // =====================================================
  var championRow = r + 10;  // Position it next to the championship matchup

  if (championship && championship.w) {
    // Determine champion based on scores to be safe (Sleeper API can be inconsistent with w/l in Toilet Bowl)
    var finalScore1 = getPlayoffScore(championship.t1, maxRound, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
    var finalScore2 = getPlayoffScore(championship.t2, maxRound, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

    var championId;

    // If scores exist and are not tied, use scores to determine result
    if (finalScore1 !== null && finalScore2 !== null && finalScore1 !== finalScore2) {
      // Toilet Bowl: Loser of the game (lower score) is the "Biggest Loser"
      // Winners/Consolation: Winner of the game (higher score) is the Champion
      championId = isToiletBowl ? ((finalScore1 < finalScore2) ? championship.t1 : championship.t2) : ((finalScore1 > finalScore2) ? championship.t1 : championship.t2);
    } else {
      // Fallback to API 'w' field (Sleeper often puts the "Bracket Winner" in 'w', even for Toilet Bowl)
      championId = championship.w;
    }

    var championName = championId ? (userLookup[championId.toString()] || "Roster " + championId) : "TBD";

    var championCol = 10;  // Column J, to the right of championship

    var championLabel;
    if (isLosersBracket) {
      championLabel = isToiletBowl ? "BIGGEST LOSER" : "CONSOLATION WINNER";
    } else {
      championLabel = "CHAMPION";
    }

    sheet.getRange(championRow, championCol).setValue(championLabel);
    sheet.getRange(championRow, championCol, 1, 2).merge();
    sheet.getRange(championRow, championCol).setFontSize(10).setFontWeight("bold").setHorizontalAlignment("center");

    if (isLosersBracket && isToiletBowl) {
      sheet.getRange(championRow, championCol).setFontColor("#8B4513");  // Brown for toilet bowl
    } else if (isLosersBracket) {
      sheet.getRange(championRow, championCol).setFontColor("#28a745");  // Green for consolation
    } else {
      sheet.getRange(championRow, championCol).setFontColor("#d4af37");  // Gold for champion
    }

    sheet.getRange(championRow + 1, championCol).setValue(championName);
    sheet.getRange(championRow + 1, championCol, 1, 2).merge();
    sheet.getRange(championRow + 1, championCol).setFontSize(12).setFontWeight("bold").setHorizontalAlignment("center");

    if (isLosersBracket && isToiletBowl) {
      sheet.getRange(championRow + 1, championCol).setBackground("#f8d7da");  // Light red background
      sheet.getRange(championRow + 1, championCol, 1, 2).setBorder(
        true, true, true, true, null, null, "#8B4513", SpreadsheetApp.BorderStyle.SOLID_MEDIUM
      );
    } else if (isLosersBracket) {
      sheet.getRange(championRow + 1, championCol).setBackground("#d4edda");  // Light green background
      sheet.getRange(championRow + 1, championCol, 1, 2).setBorder(
        true, true, true, true, null, null, "#28a745", SpreadsheetApp.BorderStyle.SOLID_MEDIUM
      );
    } else {
      sheet.getRange(championRow + 1, championCol).setBackground("#fffacd");  // Light gold background
      sheet.getRange(championRow + 1, championCol, 1, 2).setBorder(
        true, true, true, true, null, null, "#d4af37", SpreadsheetApp.BorderStyle.SOLID_MEDIUM
      );
    }
  }

  // =====================================================
  // PLACEMENT GAMES - at the bottom
  // Template rows 33-35
  // =====================================================
  var placementRow = r + 16;

  placementMatchups.sort(function (a, b) { return a.p - b.p; });

  placementMatchups.forEach(function (pm) {
    var pmCol = pm.r === 2 ? 4 : 7;  // 5th place in col D, 3rd place in col G

    // Label - pass isLosersBracket, isToiletBowl, and playoffTeams for correct placement calculation
    sheet.getRange(placementRow, pmCol).setValue(getPlacementLabel(pm.p, isLosersBracket, isToiletBowl, playoffTeams));
    sheet.getRange(placementRow, pmCol).setFontSize(9).setFontColor("#666666");

    // Calculate scores for highlighting and display
    var score1 = getPlayoffScore(pm.t1, pm.r, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);
    var score2 = getPlayoffScore(pm.t2, pm.r, weeklyScores, playoffWeekStart, playoffRoundType, maxRound);

    // Team 1
    sheet.getRange(placementRow + 1, pmCol).setValue(pm.t1 ? (userLookup[pm.t1.toString()] || "TBD") : "TBD");
    if (score1 !== null) sheet.getRange(placementRow + 1, pmCol + 1).setValue(score1);

    // Team 2
    sheet.getRange(placementRow + 2, pmCol).setValue(pm.t2 ? (userLookup[pm.t2.toString()] || "TBD") : "TBD");
    if (score2 !== null) sheet.getRange(placementRow + 2, pmCol + 1).setValue(score2);

    // Determine winner based on scores (highest score always wins placement games)
    var winner = 0; // 0=none, 1=t1, 2=t2
    if (score1 !== null && score2 !== null && score1 !== score2) {
      winner = (score1 > score2) ? 1 : 2;
    } else if (pm.w) {
      // Fallback to API if scores missing/tied
      if (pm.t1 && pm.w.toString() === pm.t1.toString()) winner = 1;
      if (pm.t2 && pm.w.toString() === pm.t2.toString()) winner = 2;
    }

    if (winner === 1) {
      sheet.getRange(placementRow + 1, pmCol).setFontWeight("bold");
      sheet.getRange(placementRow + 1, pmCol, 1, 2).setBackground(winnerHighlight);
    } else if (winner === 2) {
      sheet.getRange(placementRow + 2, pmCol).setFontWeight("bold");
      sheet.getRange(placementRow + 2, pmCol, 1, 2).setBackground(winnerHighlight);
    }

    // Full outside border on the 2x2 team cells (D34:E35 or G34:H35)
    sheet.getRange(placementRow + 1, pmCol, 2, 2).setBorder(true, true, true, true, null, null,
      "#000000", SpreadsheetApp.BorderStyle.THIN);
  });

  return placementRow + 4;
}

/**
 * Calculate Awards - Individual Player Awards, Team Awards, and Season-Long Awards
 * @param {number} throughWeek - The week to calculate through
 * @return {Array} - 2D array with awards data formatted for display
 */
function CalculateAwards(throughWeek) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();

    // Get username to display name lookup for translating owner names
    var displayLookup = buildUsernameToDisplayLookup();

    // Helper function to translate username to display name
    function translateName(username) {
      if (!username) return username;
      return displayLookup[username] || username;
    }

    // Get Player Results data for individual player awards
    var playerResultsSheet = ss.getSheetByName("Player Results");
    var playerData = playerResultsSheet.getDataRange().getValues();

    // Get Weekly Results data for team awards
    var weeklyResultsSheet = ss.getSheetByName("Weekly Results");
    var weeklyData = weeklyResultsSheet.getDataRange().getValues();

    // Get playoff start week from Settings
    var settingsSheet = ss.getSheetByName("Settings");
    var playoffStartWeek = settingsSheet.getRange("A6").getValue();
    var regularSeasonEnd = playoffStartWeek ? playoffStartWeek - 1 : 18;
    var maxWeek = Math.min(throughWeek, regularSeasonEnd);

    // Check for "Chopped" mode via League Settings
    var lastChoppedLeg = getSettingValue(settingsSheet, "/settings/last_chopped_leg");
    var isChoppedMode = (lastChoppedLeg !== null && lastChoppedLeg !== undefined && lastChoppedLeg !== "");

    var awardsData = [];

    // ========================================
    // INDIVIDUAL PLAYER AWARDS BY POSITION
    // ========================================
    awardsData.push(["INDIVIDUAL PLAYER AWARDS", "", "", "", ""]);
    awardsData.push(["Award", "Player", "Position", "Owner", "Points"]);

    // Column indices for Player Results: A=Owner, D=Week, F=Player, G=Position, I=Fantasy, J=Points
    // Skip header row, filter by week and started players (not BN)
    var filteredPlayerData = playerData.slice(1).filter(function (row) {
      return row[3] <= maxWeek && row[8] && row[8] !== "BN";
    });

    // Track highest scorer by position
    var positionHighScores = {};

    // Abstract slot definitions (Slot -> Eligible Positions)
    var slotDefinitions = {
      "FLEX": ["RB", "WR", "TE"],
      "SUPER_FLEX": ["QB", "RB", "WR", "TE"],
      "REC_FLEX": ["WR", "TE"],
      "IDP_FLEX": ["DL", "LB", "DB"],
      "WRRB": ["WR", "RB"],
      "WRTE": ["WR", "TE"],
      "RBTE": ["RB", "TE"]
    };

    // Get active positions from settings
    var rosterPositions = getLeagueRosterPositions();
    var uniquePositions = [];
    var activeSlots = [];

    // Abstract slots to ignore for positional awards but track for Slot Awards
    var ignoreSlots = Object.keys(slotDefinitions).concat(["BN", "QR"]); // QR is rarely used but we can skip it for now

    rosterPositions.forEach(function (pos) {
      // Add to unique positions if it's a real position (not in ignoreSlots)
      if (ignoreSlots.indexOf(pos) === -1 && uniquePositions.indexOf(pos) === -1) {
        uniquePositions.push(pos);
        positionHighScores[pos] = { player: "", owner: "", points: 0, week: 0 };
      }

      // Add to activeSlots if it's a defined abstract slot
      if (slotDefinitions.hasOwnProperty(pos) && activeSlots.indexOf(pos) === -1) {
        activeSlots.push(pos);
      }
    });

    // Initialize trackers for active slots
    var slotHighScores = {};
    activeSlots.forEach(function (slot) {
      slotHighScores[slot] = { player: "", owner: "", points: 0, week: 0 };
    });

    // Always include standard positions if data exists, even if not in roster
    // But for now, rely on Settings. IDP positions like LB, DL, DB will be caught here.

    // Also track highest bench scorer
    var benchHighScore = { player: "", owner: "", position: "", week: 0, points: 0 };

    // Process player data for position awards
    filteredPlayerData.forEach(function (row) {
      var owner = row[0];
      var week = row[3];
      var player = row[5];
      var position = row[6]; // NFL Position
      var fantasy = row[8];
      var points = parseFloat(row[9]) || 0;

      // 1. Check Standard Position High Scores
      if (positionHighScores.hasOwnProperty(position) && points > positionHighScores[position].points) {
        positionHighScores[position] = {
          player: player,
          owner: owner,
          week: week,
          points: points
        };
      }

      // 2. Check Abstract Slot High Scores
      activeSlots.forEach(function (slot) {
        // eligiblePositions is array like ["RB", "WR", "TE"]
        var eligiblePositions = slotDefinitions[slot];
        if (eligiblePositions.indexOf(position) !== -1) {
          if (points > slotHighScores[slot].points) {
            slotHighScores[slot] = {
              player: player,
              owner: owner,
              week: week,
              points: points
            };
          }
        }
      });
    });

    // Track highest bench score separately (need to filter BN players)
    var benchData = playerData.slice(1).filter(function (row) {
      return row[3] <= maxWeek && row[8] === "BN";
    });

    benchData.forEach(function (row) {
      var owner = row[0];
      var week = row[3];
      var player = row[5];
      var position = row[6];
      var points = parseFloat(row[9]) || 0;

      if (points > benchHighScore.points) {
        benchHighScore = {
          player: player,
          owner: owner,
          position: position,
          week: week,
          points: points
        };
      }
    });

    // Add position awards to output
    // Sort uniquePositions manually to keep standard order first, then IDP
    var standardOrder = ["QB", "RB", "WR", "TE", "K", "DEF"];
    uniquePositions.sort(function (a, b) {
      var idxA = standardOrder.indexOf(a);
      var idxB = standardOrder.indexOf(b);
      if (idxA !== -1 && idxB !== -1) return idxA - idxB;
      if (idxA !== -1) return -1;
      if (idxB !== -1) return 1;
      return a.localeCompare(b);
    });

    uniquePositions.forEach(function (pos) {
      var award = positionHighScores[pos];
      if (award.player) {
        awardsData.push([
          "Highest " + pos + " Score",
          award.player + " (Week " + award.week + ")",
          pos,
          translateName(award.owner),
          award.points
        ]);
      }
    });

    // Add Slot Awards to output (after standard positions)
    activeSlots.forEach(function (slot) {
      var award = slotHighScores[slot];
      if (award.player) {
        awardsData.push([
          "Highest " + slot + " Score",
          award.player + " (Week " + award.week + ")",
          slot,
          translateName(award.owner),
          award.points
        ]);
      }
    });


    // Add bench award
    if (benchHighScore.player) {
      awardsData.push([
        "Highest Bench Score",
        benchHighScore.player + " (Week " + benchHighScore.week + ")",
        benchHighScore.position,
        translateName(benchHighScore.owner),
        benchHighScore.points.toFixed(2)
      ]);
    }

    // ========================================
    // TEAM AWARDS (from Weekly Results)
    // ========================================
    awardsData.push(["", "", "", "", ""]);
    awardsData.push(["TEAM AWARDS", "", "", "", ""]);
    awardsData.push(["Award", "Team", "Week", "Details", "Score/Margin"]);

    // Column indices for Weekly Results: A=Week, B=User, C=Team Score, D=Rank, E=Opponent, F=Opp Score, G=Opp Rank, H=Result, I=Margin, J=Margin Rank
    var weeklyFiltered = weeklyData.slice(1).filter(function (row) {
      return row[0] <= maxWeek;
    });

    // Initialize team award tracking
    var highestTeamScore = { user: "", week: 0, score: 0, opponent: "" };
    var lowestTeamScore = { user: "", week: 0, score: Infinity, opponent: "" };
    var biggestBlowout = { user: "", week: 0, margin: 0, opponent: "", score: 0, oppScore: 0 };
    var closestWin = { user: "", week: 0, margin: Infinity, opponent: "", score: 0, oppScore: 0 };
    var highestScoringLoss = { user: "", week: 0, score: 0, opponent: "", oppScore: 0 };
    var lowestScoringWin = { user: "", week: 0, score: Infinity, opponent: "", oppScore: 0 };

    weeklyFiltered.forEach(function (row) {
      var week = row[0];
      var user = row[1];
      var teamScore = parseFloat(row[2]) || 0;
      var opponent = row[4];
      var oppScore = parseFloat(row[5]) || 0;
      var result = row[7];
      var margin = parseFloat(row[8]) || 0;

      // Highest team score
      if (teamScore > highestTeamScore.score) {
        highestTeamScore = { user: user, week: week, score: teamScore, opponent: opponent };
      }

      // Lowest team score
      if (teamScore < lowestTeamScore.score) {
        lowestTeamScore = { user: user, week: week, score: teamScore, opponent: opponent };
      }

      // Biggest blowout (highest positive margin for a win)
      if (result === "W" && margin > biggestBlowout.margin) {
        biggestBlowout = { user: user, week: week, margin: margin, opponent: opponent, score: teamScore, oppScore: oppScore };
      }

      // Closest win (smallest positive margin for a win)
      if (result === "W" && margin < closestWin.margin && margin > 0) {
        closestWin = { user: user, week: week, margin: margin, opponent: opponent, score: teamScore, oppScore: oppScore };
      }

      // Highest scoring loss
      if (result === "L" && teamScore > highestScoringLoss.score) {
        highestScoringLoss = { user: user, week: week, score: teamScore, opponent: opponent, oppScore: oppScore };
      }

      // Lowest scoring win
      if (result === "W" && teamScore < lowestScoringWin.score) {
        lowestScoringWin = { user: user, week: week, score: teamScore, opponent: opponent, oppScore: oppScore };
      }
    });

    // Add team awards to output
    awardsData.push([
      "Highest Team Score",
      highestTeamScore.user,
      highestTeamScore.week,
      "vs " + highestTeamScore.opponent,
      highestTeamScore.score.toFixed(2)
    ]);

    awardsData.push([
      "Lowest Team Score",
      lowestTeamScore.user,
      lowestTeamScore.week,
      "vs " + lowestTeamScore.opponent,
      lowestTeamScore.score.toFixed(2)
    ]);

    if (!isChoppedMode) {
      awardsData.push([
        "Biggest Blowout",
        biggestBlowout.user,
        biggestBlowout.week,
        biggestBlowout.score.toFixed(2) + " - " + biggestBlowout.oppScore.toFixed(2) + " vs " + biggestBlowout.opponent,
        "+" + biggestBlowout.margin.toFixed(2)
      ]);

      if (closestWin.margin < Infinity) {
        awardsData.push([
          "Closest Win",
          closestWin.user,
          closestWin.week,
          closestWin.score.toFixed(2) + " - " + closestWin.oppScore.toFixed(2) + " vs " + closestWin.opponent,
          "+" + closestWin.margin.toFixed(2)
        ]);
      }

      awardsData.push([
        "Highest Scoring Loss",
        highestScoringLoss.user,
        highestScoringLoss.week,
        highestScoringLoss.score.toFixed(2) + " - " + highestScoringLoss.oppScore.toFixed(2) + " vs " + highestScoringLoss.opponent,
        highestScoringLoss.score.toFixed(2)
      ]);

      if (lowestScoringWin.score < Infinity) {
        awardsData.push([
          "Lowest Scoring Win",
          lowestScoringWin.user,
          lowestScoringWin.week,
          lowestScoringWin.score.toFixed(2) + " - " + lowestScoringWin.oppScore.toFixed(2) + " vs " + lowestScoringWin.opponent,
          lowestScoringWin.score.toFixed(2)
        ]);
      }
    }

    // ========================================
    // SEASON-LONG AWARDS
    // ========================================
    awardsData.push(["", "", "", "", ""]);
    awardsData.push(["SEASON-LONG AWARDS", "", "", "", ""]);
    awardsData.push(["Award", "Team", "Value", "Details", ""]);

    // Aggregate weekly data by user
    var userStats = {};
    weeklyFiltered.forEach(function (row) {
      var user = row[1];
      var teamScore = parseFloat(row[2]) || 0;
      var oppScore = parseFloat(row[5]) || 0;

      if (!userStats[user]) {
        userStats[user] = {
          weeklyScores: [],
          totalPointsAgainst: 0
        };
      }

      userStats[user].weeklyScores.push(teamScore);
      userStats[user].totalPointsAgainst += oppScore;
    });

    // Calculate consistency (standard deviation) and boom/bust
    var mostConsistent = { user: "", stdDev: Infinity, avgScore: 0 };
    var mostBoomBust = { user: "", stdDev: 0, avgScore: 0 };
    var mostPointsAgainst = { user: "", pointsAgainst: 0 };

    Object.keys(userStats).forEach(function (user) {
      var stats = userStats[user];
      var scores = stats.weeklyScores;

      if (scores.length > 0) {
        // Calculate average
        var avg = scores.reduce(function (a, b) { return a + b; }, 0) / scores.length;

        // Calculate standard deviation
        var squaredDiffs = scores.map(function (score) {
          return Math.pow(score - avg, 2);
        });
        var avgSquaredDiff = squaredDiffs.reduce(function (a, b) { return a + b; }, 0) / scores.length;
        var stdDev = Math.sqrt(avgSquaredDiff);

        // Most consistent (lowest std dev)
        if (stdDev < mostConsistent.stdDev) {
          mostConsistent = { user: user, stdDev: stdDev, avgScore: avg };
        }

        // Most boom/bust (highest std dev)
        if (stdDev > mostBoomBust.stdDev) {
          mostBoomBust = { user: user, stdDev: stdDev, avgScore: avg };
        }
      }

      // Most points against
      if (stats.totalPointsAgainst > mostPointsAgainst.pointsAgainst) {
        mostPointsAgainst = { user: user, pointsAgainst: stats.totalPointsAgainst };
      }
    });

    if (!isChoppedMode) {
      awardsData.push([
        "Most Points Against",
        translateName(mostPointsAgainst.user),
        mostPointsAgainst.pointsAgainst.toFixed(2),
        "Total points scored by opponents",
        ""
      ]);
    }

    awardsData.push([
      "Most Consistent",
      translateName(mostConsistent.user),
      "Std Dev: " + mostConsistent.stdDev.toFixed(2),
      "Avg: " + mostConsistent.avgScore.toFixed(2) + " (Lowest variance)",
      ""
    ]);

    awardsData.push([
      "Most Boom/Bust",
      translateName(mostBoomBust.user),
      "Std Dev: " + mostBoomBust.stdDev.toFixed(2),
      "Avg: " + mostBoomBust.avgScore.toFixed(2) + " (Highest variance)",
      ""
    ]);

    // Best Record vs Field - Calculate from weekly scores (independent of Standings sheet format)
    var vsFieldStats = {}; // user -> {wins, losses, ties}

    // Initialize stats for all users found in weekly data
    Object.keys(userStats).forEach(function (user) {
      vsFieldStats[user] = { wins: 0, losses: 0, ties: 0 };
    });

    // Group scores by week to compare everyone against everyone
    var scoresByWeek = {};
    weeklyFiltered.forEach(function (row) {
      var week = row[0];
      var user = row[1];
      var score = parseFloat(row[2]) || 0;

      if (!scoresByWeek[week]) scoresByWeek[week] = [];
      scoresByWeek[week].push({ user: user, score: score });
    });

    // Calculate records
    Object.keys(scoresByWeek).forEach(function (week) {
      var weekScores = scoresByWeek[week];
      for (var i = 0; i < weekScores.length; i++) {
        for (var j = 0; j < weekScores.length; j++) {
          if (i !== j) {
            var u1 = weekScores[i];
            var u2 = weekScores[j];
            if (u1.score > u2.score) {
              vsFieldStats[u1.user].wins++;
            } else if (u1.score < u2.score) {
              vsFieldStats[u1.user].losses++;
            } else {
              vsFieldStats[u1.user].ties++;
            }
          }
        }
      }
    });

    // Find best record
    var bestVsField = { user: "", wins: 0, losses: 0, winPct: 0 };
    Object.keys(vsFieldStats).forEach(function (user) {
      var s = vsFieldStats[user];
      var total = s.wins + s.losses + s.ties;
      var pct = total > 0 ? (s.wins / total) : 0;

      if (pct > bestVsField.winPct) {
        bestVsField = { user: user, wins: s.wins, losses: s.losses, winPct: pct };
      }
    });

    awardsData.push([
      "Best Record vs Field",
      translateName(bestVsField.user),
      bestVsField.wins + "-" + bestVsField.losses,
      (bestVsField.winPct * 100).toFixed(1) + "% win rate vs all teams all weeks",
      ""
    ]);


    return awardsData;

  } catch (error) {
    Logger.log("Error in CalculateAwards: " + error.toString());
    return [["Error: " + error.toString()]];
  }
}

/**
 * =====================================================
 * USER & LEAGUE DATA - User/League Refresh Functions
 * =====================================================
 * Functions for refreshing user information, league data,
 * and league-specific settings from the Sleeper API.
 */

/**
 * Step 1: Refresh User Data
 * This updates the user info in Leagues!A54 and waits for C1 to calculate
 */
function RefreshUserData() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var leaguesSheet = ss.getSheetByName("Leagues");

    // Get username from Info!B1
    var username = infoSheet.getRange("B1").getValue();
    if (!username) {
      throw new Error("Please enter a username in Info!B1");
    }

    // Sanitize username
    username = username.toString().trim();

    Logger.log("Fetching user data for username: " + username);

    // Clear the user data area
    leaguesSheet.getRange("A54:IO55").clearContent();

    // Fetch user data directly using UrlFetchApp
    var url = "https://api.sleeper.app/v1/user/" + username;
    Logger.log("User API URL: " + url);

    try {
      var userData = fetchSleeperJson(url, {
        workflow: "Step 1 User",
        preserveLargeNumbers: true,
        errorMessage: "User not found. Please check the username."
      });

      Logger.log("User data retrieved: " + JSON.stringify(userData));

      // Convert the user data to the format ImportJSON would create
      // ImportJSON converts headers to Title Case by default
      var headers = [];
      var values = [];

      // Process keys to match ImportJSON behavior
      var keys = Object.keys(userData).sort();

      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        // Convert to title case like ImportJSON does
        var titleCaseKey = key.replace(/_/g, " ").replace(/\w\S*/g, function (txt) {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
        headers.push(titleCaseKey);

        // Handle large numbers like user_id
        var value = userData[key];
        if (typeof value === 'number' && value.toString().length > 11) {
          value = "'" + value.toString();
        } else if (typeof value === 'string' && value.match(/^\d{12,}$/)) {
          value = "'" + value;
        }
        values.push(value);
      }

      Logger.log("Headers: " + headers.join(", "));
      Logger.log("Looking for 'User Id' at index: " + headers.indexOf("User Id"));

      // Write headers and values
      if (headers.length > 0) {
        leaguesSheet.getRange(54, 1, 1, headers.length).setValues([headers]);
        leaguesSheet.getRange(55, 1, 1, values.length).setValues([values]);
      }

      // Force recalculation and wait for B7 formula to update
      SpreadsheetApp.flush();
      sleepForSleeperRateLimit(0); // Recalculate without changing current user-visible pacing

      // Verify C1 has a value
      var userId = infoSheet.getRange("C1").getValue();
      Logger.log("User ID from C1: " + userId);

      if (!userId || userId.toString().trim() === "") {
        // Try to get user_id directly from the original data
        userId = userData.user_id;
        Logger.log("Using user_id directly from API: " + userId);

        if (!userId) {
          throw new Error("User ID not found in API response");
        }
      }

      return userId.toString();

    } catch (fetchError) {
      Logger.log("Fetch error: " + fetchError.toString());
      throw new Error("Failed to fetch user data: " + fetchError.toString());
    }

  } catch (error) {
    throw new Error("Error refreshing user data: " + error.toString());
  }
}

/**
 * Step 2: Refresh Leagues Data
 * This populates the leagues list for the user
 */
function RefreshLeaguesData(userId, year) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var leaguesSheet = ss.getSheetByName("Leagues");

    // Validate inputs
    if (!userId || userId.toString().trim() === "") {
      throw new Error("Invalid user ID: '" + userId + "'");
    }
    if (!year || year.toString().trim() === "") {
      throw new Error("Invalid year: '" + year + "'");
    }

    // Sanitize inputs to remove any invisible characters (newlines, spaces)
    // This fixes "Address unavailable" errors caused by copy-pasted values
    var cleanUserId = userId.toString().trim();
    var cleanYear = year.toString().trim();

    // Clear the leagues data area (but not the formulas in IP column)
    leaguesSheet.getRange("A1:IO50").clearContent();

    // Fetch leagues data
    var url = "https://api.sleeper.app/v1/user/" + cleanUserId + "/leagues/nfl/" + cleanYear;
    Logger.log("Leagues API URL (Sanitized): " + url);

    try {
      var leaguesData = fetchSleeperJson(url, {
        workflow: "Step 1 Leagues",
        preserveLargeNumbers: true,
        errorMessage: "Unable to fetch leagues. This usually means the user has no leagues for " + year + " or the user ID is incorrect."
      });
      Logger.log("Number of leagues found: " + leaguesData.length);

      if (!leaguesData || leaguesData.length === 0) {
        throw new Error("No leagues found for this user and year");
      }

      // Process the data with noInherit option behavior
      var result = parseJSONData(leaguesData, "", "noInherit");

      // Write the data
      if (result.length > 0) {
        var maxCols = Math.max(...result.map(row => row.length));
        var dataRange = leaguesSheet.getRange(1, 1, result.length, maxCols);

        // Pad rows to have same number of columns
        for (var i = 0; i < result.length; i++) {
          while (result[i].length < maxCols) {
            result[i].push("");
          }
        }

        dataRange.setValues(result);
        Logger.log("Leagues data written: " + result.length + " rows");
      }

      // Force recalculation of formulas
      SpreadsheetApp.flush();
      sleepForSleeperRateLimit(0);

      return true;

    } catch (fetchError) {
      Logger.log("Fetch error details: " + fetchError.toString());
      throw new Error("Failed to fetch leagues: " + fetchError.toString());
    }

  } catch (error) {
    throw new Error("Error refreshing leagues data: " + error.toString());
  }
}

/**
 * Step 3: Get Selected League ID
 * This assumes the user has already selected a league in B3
 */
function GetSelectedLeagueId() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var infoSheet = ss.getSheetByName("Info");
    var leaguesSheet = ss.getSheetByName("Leagues");

    // Check if league is selected
    var selectedLeague = infoSheet.getRange("B4").getValue();
    if (!selectedLeague) {
      throw new Error("Please select a league from the dropdown in Info!B4");
    }

    // Get league ID from E61
    SpreadsheetApp.flush();
    sleepForSleeperRateLimit(0);

    var leagueId = leaguesSheet.getRange("E61").getValue();
    if (!leagueId) {
      throw new Error("League ID not found. Please verify league selection.");
    }

    return leagueId;

  } catch (error) {
    throw new Error("Error getting league ID: " + error.toString());
  }
}

/**
 * Helper function to refresh Settings and Users/Rosters sheets
 * Shared by multiple refresh workflows to avoid code duplication
 * @param {string} leagueId - The league ID
 * @return {Array} - Array of error messages (empty if no errors)
 */
function RefreshSettingsAndUsers(leagueId) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var errors = [];

  // Refresh Settings
  try {
    Logger.log("Refreshing Settings...");
    var settingsSheet = ss.getSheetByName("Settings");
    settingsSheet.getRange("1:1").clearContent();

    var url = "https://api.sleeper.app/v1/league/" + leagueId;
    var settingsData = fetchSleeperJson(url, {
      workflow: "League Settings",
      preserveLargeNumbers: true,
      leagueId: leagueId
    });

    var result = parseJSONData([settingsData], "", "rawHeaders");
    if (result.length > 0) {
      result = preventScientificNotation(result);
      settingsSheet.getRange(1, 1, result.length, result[0].length).setValues(result);
    }
    Logger.log("Settings refreshed successfully");
  } catch (error) {
    errors.push("Settings: " + error.toString());
  }

  // Refresh Users
  try {
    Logger.log("Refreshing Users and Rosters...");
    var usersSheet = ss.getSheetByName("Users");

    // Clear and update users data (rows 1-35)
    usersSheet.getRange("1:35").clearContent();
    var usersUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/users";
    var usersData = fetchSleeperJson(usersUrl, {
      workflow: "League Users",
      preserveLargeNumbers: true,
      leagueId: leagueId
    });

    var usersResult = parseJSONData(usersData, "", "rawHeaders,noInherit");
    if (usersResult.length > 0) {
      usersResult = preventScientificNotation(usersResult);
      usersSheet.getRange(1, 1, usersResult.length, usersResult[0].length).setValues(usersResult);
    }

    // Clear and update rosters data (rows 36-68, starting at column B)
    // Row 36 has headers, rows 37-68 have roster data (32 rosters max)
    usersSheet.getRange("B36:QY68").clearContent();
    var rostersUrl = "https://api.sleeper.app/v1/league/" + leagueId + "/rosters";
    var rostersData = fetchSleeperJson(rostersUrl, {
      workflow: "League Rosters",
      preserveLargeNumbers: true,
      leagueId: leagueId
    });

    // Apply the query filters
    var queryPaths = ["/taxi", "/starters", "/settings", "/roster_id", "/reserve",
      "/players", "/player_map", "/owner_id", "/league_id",
      "/keepers", "/co_owners"];
    var rostersResult = parseJSONData(rostersData, queryPaths, "rawHeaders,noInherit");
    if (rostersResult.length > 0) {
      rostersResult = preventScientificNotation(rostersResult);
      // Write rosters data starting at B36 (row 36, column 2)
      usersSheet.getRange(36, 2, rostersResult.length, rostersResult[0].length).setValues(rostersResult);
    }
    Logger.log("Users and Rosters refreshed successfully");
  } catch (error) {
    errors.push("Users: " + error.toString());
  }

  return errors;
}
