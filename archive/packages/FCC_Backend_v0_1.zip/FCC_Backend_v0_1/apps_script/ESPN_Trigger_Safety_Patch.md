# Patch de segurança — ESPN para gatilho automático

O atualizador completo continua idêntico em lógica e escrita de dados. A única mudança é permitir `showToast:false` quando executado por trigger:

```javascript
function refreshESPNDashboardData(options) {
  options = options || {};
  const showToast = options.showToast !== false;
  // ... código existente ...
  if (showToast) ss.toast(...);
}
```

O menu manual chama sem argumentos e continua exibindo o toast. A automação chama `refreshESPNDashboardData({showToast:false})`.
