# Patch obrigatório — Sleeper Data Export para gatilhos automáticos

O código original chama `SpreadsheetApp.getUi()` mesmo em rotinas disparadas sem interface. Para permitir gatilhos por tempo, a versão `Sleeper_Data_Export_v8_FCC_AUTOMATION_PATCHED.gs` altera **somente** dois pontos:

1. `RefreshPlayerResultsManual`: `getUi()` só é criado se `showCompletionAlert` for verdadeiro.
2. `RefreshCurrentRosters`: `getUi()` só é criado se `showAlerts` for verdadeiro.

Nenhum cálculo, coluna, aba ou regra de fantasy foi alterado.

## Patch manual equivalente

```javascript
// RefreshPlayerResultsManual
var ui = showCompletionAlert ? SpreadsheetApp.getUi() : null;

// RefreshCurrentRosters
var ui = showAlerts ? SpreadsheetApp.getUi() : null;
```

Depois, mantenha `Sleeper_Backup_Automation_v1.gs` como um arquivo adicional no mesmo projeto Apps Script.
