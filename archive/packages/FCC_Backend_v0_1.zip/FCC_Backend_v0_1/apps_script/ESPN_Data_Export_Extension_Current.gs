/**
 * ESPN Data Export Extension
 * --------------------------
 * Add this file to the SAME Apps Script project that already contains ImportJSON.
 * It does not modify ImportJSON and does not replace the original CSG formulas.
 *
 * Goal: create a normalized Data_* layer close to Sleeper Data Export v8:
 * Data_Info, Data_Rosters, Data_Roster_Summary, Data_Standings,
 * Data_Weekly_Results, Data_Player_Results, Data_Transactions,
 * Data_Free_Agents, Data_Schedule, Data_Settings, Data_Scoring,
 * Data_Users, Data_Draft_Result and Data_Status.
 *
 * Main action: ESPN Data -> Atualizar base do Dashboard
 */

const ESPN_EXPORT = {
  base: 'https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/',
  leagueSettingsSheet: 'League Settings',
  seasonCell: 'C1',
  leagueIdCell: 'C2',
  maxFreeAgents: 1200,

  defaultPosition: {
    0: '',
    1: 'QB',
    2: 'RB',
    3: 'WR',
    4: 'TE',
    5: 'K',
    16: 'D/ST'
  },

  lineupSlot: {
    0: 'QB',
    1: 'TQB',
    2: 'RB',
    3: 'RB/WR',
    4: 'WR',
    5: 'WR/TE',
    6: 'TE',
    7: 'OP',
    16: 'D/ST',
    17: 'K',
    20: 'BN',
    21: 'IR',
    23: 'FLEX'
  },

  proTeam: {
    0: '',
    1: 'ATL',
    2: 'BUF',
    3: 'CHI',
    4: 'CIN',
    5: 'CLE',
    6: 'DAL',
    7: 'DEN',
    8: 'DET',
    9: 'GB',
    10: 'TEN',
    11: 'IND',
    12: 'KC',
    13: 'LV',
    14: 'LAR',
    15: 'MIA',
    16: 'MIN',
    17: 'NE',
    18: 'NO',
    19: 'NYG',
    20: 'NYJ',
    21: 'PHI',
    22: 'ARI',
    23: 'PIT',
    24: 'LAC',
    25: 'SF',
    26: 'SEA',
    27: 'TB',
    28: 'WAS',
    29: 'CAR',
    30: 'JAX',
    33: 'BAL',
    34: 'HOU'
  },

  // ESPN football stat IDs used to mirror the most useful Sleeper columns.
  stat: {
    passYds: 3,
    passTD: 4,
    pass2pt: 19,
    passInt: 20,
    rushAtt: 23,
    rushYds: 24,
    rushTD: 25,
    rush2pt: 26,
    rec: 53,          // falls back to 41
    recAlt: 41,
    recYds: 42,
    recTD: 43,
    rec2pt: 44,
    targets: 58,
    fumLost: 72,
    fg50p: 74,
    fg40_49: 77,
    fgUnder40: 80,
    fgMade: 83,
    fgMiss: 85,
    patMade: 86,
    patMiss: 88
  }
};


function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('🏈 ESPN Data')
    .addItem('Atualizar base do Dashboard', 'refreshESPNDashboardData')
    .addSeparator()
    .addItem('Atualizar somente Free Agents', 'refreshESPNFreeAgents')
    .addItem('Atualizar somente Transações', 'refreshESPNTransactions')
    .addToUi();
}


/**
 * Main updater.
 * Keeps the original CSG tabs untouched and rebuilds only Data_* tabs.
 */
function refreshESPNDashboardData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cfg = espnReadConfig_(ss);

  espnSetStatus_(ss, 'Atualização', 'EM ANDAMENTO', new Date());

  const core = espnFetchLeague_(
    cfg,
    ['mSettings', 'mTeam', 'mRoster', 'mStandings', 'mStatus', 'mSchedule', 'mDraftDetail'],
    {}
  );

  const currentWeek = Number(
    (core.status && (core.status.currentMatchupPeriod || core.status.latestScoringPeriod)) ||
    core.scoringPeriodId ||
    1
  );

  const weekData = [];
  const playerRows = [];
  const weeklyRows = [];

  // Include the current week so the dashboard can show W4 projections while W1-W3 are historical.
  for (let week = 1; week <= currentWeek; week++) {
    const box = espnFetchLeague_(
      cfg,
      ['mBoxscore', 'mMatchupScore'],
      { scoringPeriodId: week, matchupPeriodId: week }
    );
    weekData.push({ week: week, data: box });
  }

  const maps = espnBuildMaps_(core);

  espnWriteInfo_(ss, cfg, core, currentWeek);
  espnWriteUsers_(ss, core);
  espnWriteRosters_(ss, core, maps);
  espnWriteSchedule_(ss, core, maps);
  espnWriteSettings_(ss, core);
  espnWriteScoring_(ss, core);
  espnWriteDraft_(ss, core, maps);

  const results = espnBuildWeeklyAndPlayerResults_(cfg, core, weekData, maps);
  espnWriteTable_(ss, 'Data_Weekly_Results', results.weekly.headers, results.weekly.rows);
  espnWriteTable_(ss, 'Data_Player_Results', results.players.headers, results.players.rows);

  const standings = espnBuildStandings_(core, maps, results.weekly.rows);
  espnWriteTable_(ss, 'Data_Standings', standings.headers, standings.rows);

  const rosterSummary = espnBuildRosterSummary_(core, maps);
  espnWriteTable_(ss, 'Data_Roster_Summary', rosterSummary.headers, rosterSummary.rows);

  // These use their own filtered calls.
  const freeAgents = espnGetFreeAgents_(cfg, currentWeek);
  espnWriteTable_(ss, 'Data_Free_Agents', freeAgents.headers, freeAgents.rows);

  const transactions = espnGetTransactions_(cfg, currentWeek, maps, freeAgents.playerIndex);
  espnWriteTable_(ss, 'Data_Transactions', transactions.headers, transactions.rows);

  // Update status after all dependent sheets are written.
  espnWriteStatus_(ss, cfg, currentWeek, {
    rosters: results.players.rows.length,
    freeAgents: freeAgents.rows.length,
    transactions: transactions.rows.length
  });

  SpreadsheetApp.flush();
  ss.toast('Base ESPN atualizada para a Semana ' + currentWeek + '.', 'ESPN Data Export', 8);
}


function refreshESPNFreeAgents() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cfg = espnReadConfig_(ss);
  const status = espnFetchLeague_(cfg, ['mStatus'], {});
  const week = Number(
    (status.status && (status.status.currentMatchupPeriod || status.status.latestScoringPeriod)) ||
    status.scoringPeriodId ||
    1
  );

  const freeAgents = espnGetFreeAgents_(cfg, week);
  espnWriteTable_(ss, 'Data_Free_Agents', freeAgents.headers, freeAgents.rows);
  espnSetStatus_(ss, 'Free Agents', 'ATUALIZADO', new Date());
  ss.toast('Free Agents atualizados: ' + freeAgents.rows.length, 'ESPN Data Export', 6);
}


function refreshESPNTransactions() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cfg = espnReadConfig_(ss);
  const core = espnFetchLeague_(cfg, ['mTeam', 'mRoster', 'mStatus'], {});
  const maps = espnBuildMaps_(core);
  const week = Number(
    (core.status && (core.status.currentMatchupPeriod || core.status.latestScoringPeriod)) ||
    core.scoringPeriodId ||
    1
  );

  const transactions = espnGetTransactions_(cfg, week, maps, {});
  espnWriteTable_(ss, 'Data_Transactions', transactions.headers, transactions.rows);
  espnSetStatus_(ss, 'Transactions', 'ATUALIZADO', new Date());
  ss.toast('Transações atualizadas: ' + transactions.rows.length, 'ESPN Data Export', 6);
}


/* ============================================================================
 * API
 * ========================================================================== */

function espnReadConfig_(ss) {
  const sh = ss.getSheetByName(ESPN_EXPORT.leagueSettingsSheet);
  if (!sh) throw new Error('Aba "League Settings" não encontrada.');

  const season = Number(sh.getRange(ESPN_EXPORT.seasonCell).getValue());
  const leagueId = String(sh.getRange(ESPN_EXPORT.leagueIdCell).getValue()).trim();

  if (!season || !leagueId) {
    throw new Error('Preencha Year em C1 e ESPN League ID em C2 na aba League Settings.');
  }

  return { season: season, leagueId: leagueId };
}


function espnFetchLeague_(cfg, views, params, fantasyFilter) {
  const query = [];

  (views || []).forEach(v => query.push('view=' + encodeURIComponent(v)));

  Object.keys(params || {}).forEach(k => {
    if (params[k] !== null && params[k] !== undefined && params[k] !== '') {
      query.push(encodeURIComponent(k) + '=' + encodeURIComponent(params[k]));
    }
  });

  const url =
    ESPN_EXPORT.base + cfg.season +
    '/segments/0/leagues/' + cfg.leagueId +
    '?' + query.join('&');

  const headers = {};
  if (fantasyFilter) {
    headers['X-Fantasy-Filter'] = JSON.stringify(fantasyFilter);
  }

  // Optional support for private leagues WITHOUT putting cookies in spreadsheet cells.
  // If you never configure the Script Properties ESPN_SWID and ESPN_S2, this does nothing.
  const props = PropertiesService.getScriptProperties();
  const swid = props.getProperty('ESPN_SWID');
  const s2 = props.getProperty('ESPN_S2');
  if (swid && s2) {
    headers['Cookie'] = 'SWID=' + swid + '; espn_s2=' + s2;
  }

  const response = UrlFetchApp.fetch(url, {
    method: 'get',
    headers: headers,
    muteHttpExceptions: true,
    followRedirects: true
  });

  const code = response.getResponseCode();
  const body = response.getContentText();

  if (code < 200 || code >= 300) {
    throw new Error('ESPN API HTTP ' + code + ': ' + body.substring(0, 500));
  }

  return JSON.parse(body);
}


/* ============================================================================
 * MAPS / NORMALIZATION
 * ========================================================================== */

function espnBuildMaps_(core) {
  const memberMap = {};
  (core.members || []).forEach(m => {
    memberMap[m.id] = m.displayName || m.firstName || m.id;
  });

  const teamMap = {};
  const teamOwner = {};
  const playerIndex = {};

  (core.teams || []).forEach(t => {
    teamMap[t.id] = t.name || t.location || ('Team ' + t.id);

    const ownerId = (t.owners && t.owners.length) ? t.owners[0] : '';
    teamOwner[t.id] = memberMap[ownerId] || ownerId || teamMap[t.id];

    (((t.roster || {}).entries) || []).forEach(entry => {
      const ppe = entry.playerPoolEntry || {};
      const player = ppe.player || {};
      const pid = Number(entry.playerId || ppe.id || player.id || 0);
      if (pid) {
        playerIndex[pid] = {
          id: pid,
          name: player.fullName || String(pid),
          position: ESPN_EXPORT.defaultPosition[player.defaultPositionId] || '',
          nfl: ESPN_EXPORT.proTeam[player.proTeamId] || '',
          player: player,
          ppe: ppe
        };
      }
    });
  });

  return {
    memberMap: memberMap,
    teamMap: teamMap,
    teamOwner: teamOwner,
    playerIndex: playerIndex
  };
}


function espnRosterSlot_(lineupSlotId) {
  if (Number(lineupSlotId) === 20) return 'Bench';
  if (Number(lineupSlotId) === 21) return 'Reserve';
  return 'Starter';
}


function espnSlotLabel_(lineupSlotId) {
  return ESPN_EXPORT.lineupSlot[Number(lineupSlotId)] || String(lineupSlotId || '');
}


function espnPrimaryPosition_(player) {
  return ESPN_EXPORT.defaultPosition[Number((player || {}).defaultPositionId)] || '';
}


function espnFantasyPositions_(player) {
  const slots = (player && player.eligibleSlots) ? player.eligibleSlots : [];
  const labels = [];
  slots.forEach(id => {
    const label = ESPN_EXPORT.lineupSlot[Number(id)];
    if (label && !['BN', 'IR', 'OP'].includes(label) && labels.indexOf(label) === -1) {
      labels.push(label);
    }
  });
  if (!labels.length) {
    const primary = espnPrimaryPosition_(player);
    if (primary) labels.push(primary);
  }
  return labels.join(',');
}


function espnFindWeekStat_(stats, week, sourceId) {
  const candidates = (stats || []).filter(s => {
    const src = (s.statSourceId !== undefined) ? Number(s.statSourceId) :
                ((s.statTypeId !== undefined) ? Number(s.statTypeId) : -1);
    const split = (s.statSplitTypeId !== undefined) ? Number(s.statSplitTypeId) : 1;
    return Number(s.scoringPeriodId) === Number(week) &&
           src === Number(sourceId) &&
           split === 1;
  });

  if (candidates.length) return candidates[0];

  return (stats || []).find(s => {
    const src = (s.statSourceId !== undefined) ? Number(s.statSourceId) :
                ((s.statTypeId !== undefined) ? Number(s.statTypeId) : -1);
    return Number(s.scoringPeriodId) === Number(week) && src === Number(sourceId);
  }) || null;
}


function espnStatValue_(statObj, id, fallbackId) {
  if (!statObj) return 0;
  const raw = statObj.stats || statObj.appliedStats || {};
  if (raw[id] !== undefined) return Number(raw[id]) || 0;
  if (fallbackId !== undefined && raw[fallbackId] !== undefined) {
    return Number(raw[fallbackId]) || 0;
  }
  return 0;
}


function espnAppliedTotal_(statObj, fallback) {
  if (statObj && statObj.appliedTotal !== undefined) return Number(statObj.appliedTotal) || 0;
  if (statObj && statObj.appliedStatTotal !== undefined) return Number(statObj.appliedStatTotal) || 0;
  return Number(fallback) || 0;
}


/* ============================================================================
 * INFO / USERS / ROSTERS
 * ========================================================================== */

function espnWriteInfo_(ss, cfg, core, currentWeek) {
  const settings = core.settings || {};
  const status = core.status || {};

  const rows = [
    ['Source', 'ESPN'],
    ['League ID', cfg.leagueId],
    ['League', settings.name || ''],
    ['Year', cfg.season],
    ['Analysis Week', currentWeek],
    ['Latest Scoring Period', status.latestScoringPeriod || core.scoringPeriodId || ''],
    ['Teams', settings.size || (core.teams || []).length],
    ['Public', settings.isPublic],
    ['Updated At', new Date()]
  ];

  espnWriteTable_(ss, 'Data_Info', ['Field', 'Value'], rows);
}


function espnWriteUsers_(ss, core) {
  const headers = ['User ID', 'Display Name', 'First Name', 'Last Name', 'League Manager'];
  const rows = (core.members || []).map(m => [
    m.id || '',
    m.displayName || '',
    m.firstName || '',
    m.lastName || '',
    !!m.isLeagueManager
  ]);

  espnWriteTable_(ss, 'Data_Users', headers, rows);
}


function espnWriteRosters_(ss, core, maps) {
  const headers = [
    'Roster ID', 'Owner', 'Team Name', 'Roster Slot', 'Starter Slot',
    'Player ID', 'Player', 'Position', 'Fantasy Positions', 'NFL Team', 'Age',
    'Injury Status', 'Acquisition Type', 'Percent Owned', 'Percent Started'
  ];

  const rows = [];

  (core.teams || []).forEach(team => {
    const roster = ((team.roster || {}).entries) || [];
    roster.forEach(entry => {
      const ppe = entry.playerPoolEntry || {};
      const p = ppe.player || {};
      const owner = maps.teamOwner[team.id] || '';

      rows.push([
        team.id,
        owner,
        maps.teamMap[team.id] || '',
        espnRosterSlot_(entry.lineupSlotId),
        espnSlotLabel_(entry.lineupSlotId),
        entry.playerId || ppe.id || p.id || '',
        p.fullName || '',
        espnPrimaryPosition_(p),
        espnFantasyPositions_(p),
        ESPN_EXPORT.proTeam[Number(p.proTeamId)] || '',
        p.age || '',
        p.injuryStatus || entry.injuryStatus || '',
        entry.acquisitionType || ppe.acquisitionType || '',
        (ppe.percentOwned !== undefined ? ppe.percentOwned :
         ((ppe.ownership || {}).percentOwned !== undefined ? ppe.ownership.percentOwned : '')),
        (ppe.percentStarted !== undefined ? ppe.percentStarted :
         ((ppe.ownership || {}).percentStarted !== undefined ? ppe.ownership.percentStarted : ''))
      ]);
    });
  });

  espnWriteTable_(ss, 'Data_Rosters', headers, rows);
}


function espnBuildRosterSummary_(core, maps) {
  const headers = [
    'Roster ID', 'Owner', 'Team Name', 'Total Players', 'Active Players',
    'Starters', 'Bench', 'Reserve', 'Taxi', 'Open Active Spots',
    'Open Reserve Spots', 'Open Taxi Spots', 'QB', 'RB', 'WR', 'TE',
    'K', 'DEF', 'Other', 'Average Age', 'Under 25',
    'FAAB Remaining', 'Waiver Position', 'Current Year Picks', 'Next Year Picks'
  ];

  const slotCounts = (((core.settings || {}).rosterSettings || {}).lineupSlotCounts) || {};
  const reserveLimit = Number(slotCounts['21'] || 0);
  let activeSlotLimit = 0;

  Object.keys(slotCounts).forEach(k => {
    if (Number(k) !== 21) activeSlotLimit += Number(slotCounts[k] || 0);
  });

  const rows = (core.teams || []).map(team => {
    const entries = (((team.roster || {}).entries) || []);
    const pos = { QB:0, RB:0, WR:0, TE:0, K:0, 'D/ST':0, Other:0 };
    const ages = [];
    let starters = 0, bench = 0, reserve = 0, under25 = 0;

    entries.forEach(e => {
      const p = ((e.playerPoolEntry || {}).player) || {};
      const primary = espnPrimaryPosition_(p);
      if (pos[primary] !== undefined) pos[primary]++; else pos.Other++;

      const slot = espnRosterSlot_(e.lineupSlotId);
      if (slot === 'Starter') starters++;
      else if (slot === 'Bench') bench++;
      else if (slot === 'Reserve') reserve++;

      if (p.age !== undefined && p.age !== null && p.age !== '') {
        ages.push(Number(p.age));
        if (Number(p.age) < 25) under25++;
      }
    });

    const activePlayers = entries.length - reserve;
    const avgAge = ages.length ? ages.reduce((a,b)=>a+b,0) / ages.length : '';

    return [
      team.id,
      maps.teamOwner[team.id] || '',
      maps.teamMap[team.id] || '',
      entries.length,
      activePlayers,
      starters,
      bench,
      reserve,
      0,
      Math.max(0, activeSlotLimit - activePlayers),
      Math.max(0, reserveLimit - reserve),
      0,
      pos.QB, pos.RB, pos.WR, pos.TE, pos.K, pos['D/ST'], pos.Other,
      avgAge === '' ? '' : Math.round(avgAge * 10) / 10,
      under25,
      '',
      team.waiverRank || '',
      '',
      ''
    ];
  });

  return { headers: headers, rows: rows };
}


/* ============================================================================
 * WEEKLY RESULTS / PLAYER RESULTS / STANDINGS
 * ========================================================================== */

function espnBuildWeeklyAndPlayerResults_(cfg, core, weekData, maps) {
  const weeklyHeaders = [
    'Week', 'User', 'Team Score', 'Rank', 'Opponent',
    'Opp Score', 'Opp Rank', 'Result', 'Margin', 'Margin Rank', 'Team ID'
  ];

  const playerHeaders = [
    'Owner', 'League', 'Year', 'Week', 'Player_ID', 'Player', 'Position',
    'NFL', 'Fantasy', 'Points', 'Projected', 'Opponent', 'Age',
    'Passing Yards', 'Passing TD', '2-Pt Passing', 'Pass Intercepted',
    'Rushing Attempts', 'Rushing Yards', 'Rushing TD', '2-Pt Rushing',
    'Targets', 'Reception', 'Receiving Yards', 'Receiving TD', '2-Pt Receiving',
    'FG Made 50+', 'FG Made 40-49', 'FG Made Under 40',
    'FG Made', 'PAT Made', 'FG Missed', 'PAT Missed', 'Fumble Lost',
    'Injury Status'
  ];

  const weeklyRows = [];
  const playerRows = [];
  const leagueName = ((core.settings || {}).name) || '';

  weekData.forEach(wd => {
    const week = wd.week;
    const data = wd.data || {};
    const matchups = (data.schedule || []).filter(m => Number(m.matchupPeriodId) === Number(week));

    const weekScores = {};
    matchups.forEach(m => {
      if (m.home && m.home.teamId) weekScores[m.home.teamId] = Number(m.home.totalPoints || 0);
      if (m.away && m.away.teamId) weekScores[m.away.teamId] = Number(m.away.totalPoints || 0);
    });

    const sorted = Object.keys(weekScores)
      .map(id => ({ id: Number(id), score: weekScores[id] }))
      .sort((a,b) => b.score - a.score);

    const rankMap = {};
    sorted.forEach((x,i) => rankMap[x.id] = i + 1);

    const weekRowsTemp = [];

    matchups.forEach(m => {
      const sides = [
        { team: m.home, opp: m.away },
        { team: m.away, opp: m.home }
      ];

      sides.forEach(side => {
        if (!side.team || !side.team.teamId) return;

        const teamId = Number(side.team.teamId);
        const oppId = side.opp ? Number(side.opp.teamId || 0) : 0;
        const score = Number(side.team.totalPoints || 0);
        const oppScore = side.opp ? Number(side.opp.totalPoints || 0) : 0;
        const margin = score - oppScore;

        let result = '';
        if (score > 0 || oppScore > 0) {
          result = score > oppScore ? 'W' : (score < oppScore ? 'L' : 'T');
        }

        weekRowsTemp.push({
          row: [
            week,
            maps.teamOwner[teamId] || maps.teamMap[teamId] || '',
            score,
            rankMap[teamId] || '',
            maps.teamOwner[oppId] || maps.teamMap[oppId] || '',
            oppScore,
            rankMap[oppId] || '',
            result,
            margin,
            '',
            teamId
          ],
          margin: margin
        });

        const roster = (((side.team || {}).rosterForCurrentScoringPeriod || {}).entries) || [];

        roster.forEach(entry => {
          const ppe = entry.playerPoolEntry || {};
          const p = ppe.player || {};
          const stats = p.stats || ppe.stats || [];

          const actual = espnFindWeekStat_(stats, week, 0);
          const projection = espnFindWeekStat_(stats, week, 1);

          const points = espnAppliedTotal_(actual, ppe.appliedStatTotal);
          const projected = espnAppliedTotal_(projection, 0);

          const s = ESPN_EXPORT.stat;

          playerRows.push([
            maps.teamOwner[teamId] || maps.teamMap[teamId] || '',
            leagueName,
            cfg.season,
            week,
            entry.playerId || ppe.id || p.id || '',
            p.fullName || '',
            espnPrimaryPosition_(p),
            ESPN_EXPORT.proTeam[Number(p.proTeamId)] || '',
            espnSlotLabel_(entry.lineupSlotId),
            points,
            projected,
            maps.teamOwner[oppId] || maps.teamMap[oppId] || '',
            p.age || '',
            espnStatValue_(actual, s.passYds),
            espnStatValue_(actual, s.passTD),
            espnStatValue_(actual, s.pass2pt),
            espnStatValue_(actual, s.passInt),
            espnStatValue_(actual, s.rushAtt),
            espnStatValue_(actual, s.rushYds),
            espnStatValue_(actual, s.rushTD),
            espnStatValue_(actual, s.rush2pt),
            espnStatValue_(actual, s.targets),
            espnStatValue_(actual, s.rec, s.recAlt),
            espnStatValue_(actual, s.recYds),
            espnStatValue_(actual, s.recTD),
            espnStatValue_(actual, s.rec2pt),
            espnStatValue_(actual, s.fg50p),
            espnStatValue_(actual, s.fg40_49),
            espnStatValue_(actual, s.fgUnder40),
            espnStatValue_(actual, s.fgMade),
            espnStatValue_(actual, s.patMade),
            espnStatValue_(actual, s.fgMiss),
            espnStatValue_(actual, s.patMiss),
            espnStatValue_(actual, s.fumLost),
            p.injuryStatus || entry.injuryStatus || ''
          ]);
        });
      });
    });

    const marginSorted = weekRowsTemp
      .slice()
      .sort((a,b) => b.margin - a.margin);

    const marginRank = {};
    marginSorted.forEach((x,i) => {
      marginRank[x.row[10]] = i + 1;
    });

    weekRowsTemp.forEach(x => {
      x.row[9] = marginRank[x.row[10]] || '';
      weeklyRows.push(x.row);
    });
  });

  return {
    weekly: { headers: weeklyHeaders, rows: weeklyRows },
    players: { headers: playerHeaders, rows: playerRows }
  };
}


function espnBuildStandings_(core, maps, weeklyRows) {
  const headers = [
    'User', 'Wins', 'Losses', 'Games', 'Win %', 'Total Points',
    'Points Against', 'High Scores', 'vs League W', 'vs League L', 'vs League %',
    'Team ID'
  ];

  const byWeek = {};
  weeklyRows.forEach(r => {
    const week = Number(r[0]);
    const teamId = Number(r[10]);
    const score = Number(r[2] || 0);
    if (!byWeek[week]) byWeek[week] = [];
    byWeek[week].push({ teamId: teamId, score: score });
  });

  const allPlay = {};
  const highScores = {};

  Object.keys(byWeek).forEach(week => {
    const arr = byWeek[week].filter(x => x.score > 0);
    if (!arr.length) return;
    const maxScore = Math.max.apply(null, arr.map(x => x.score));

    arr.forEach(a => {
      if (!allPlay[a.teamId]) allPlay[a.teamId] = { w:0, l:0 };
      if (!highScores[a.teamId]) highScores[a.teamId] = 0;
      if (a.score === maxScore) highScores[a.teamId]++;

      arr.forEach(b => {
        if (a.teamId === b.teamId) return;
        if (a.score > b.score) allPlay[a.teamId].w++;
        else if (a.score < b.score) allPlay[a.teamId].l++;
      });
    });
  });

  const rows = (core.teams || []).map(t => {
    const rec = (t.record || {}).overall || {};
    const wins = Number(rec.wins || 0);
    const losses = Number(rec.losses || 0);
    const ties = Number(rec.ties || 0);
    const games = wins + losses + ties;
    const ap = allPlay[t.id] || { w:0, l:0 };
    const apGames = ap.w + ap.l;

    return [
      maps.teamOwner[t.id] || maps.teamMap[t.id] || '',
      wins,
      losses,
      games,
      games ? wins / games : 0,
      Number(rec.pointsFor || t.points || 0),
      Number(rec.pointsAgainst || 0),
      highScores[t.id] || 0,
      ap.w,
      ap.l,
      apGames ? ap.w / apGames : 0,
      t.id
    ];
  });

  rows.sort((a,b) => {
    if (b[4] !== a[4]) return b[4] - a[4];
    return b[5] - a[5];
  });

  return { headers: headers, rows: rows };
}


/* ============================================================================
 * FREE AGENTS
 * ========================================================================== */

function espnGetFreeAgents_(cfg, currentWeek) {
  const filter = {
    players: {
      filterStatus: { value: ['FREEAGENT', 'WAIVERS'] },
      filterSlotIds: { value: [0, 2, 4, 6, 17, 16] },
      limit: ESPN_EXPORT.maxFreeAgents,
      sortPercOwned: { sortPriority: 1, sortAsc: false },
      filterStatsForTopScoringPeriodIds: {
        value: currentWeek,
        additionalValue: ['00' + cfg.season, '10' + cfg.season]
      }
    }
  };

  const data = espnFetchLeague_(
    cfg,
    ['kona_player_info'],
    { scoringPeriodId: currentWeek },
    filter
  );

  const headers = [
    'Week', 'Player_ID', 'Player', 'Position', 'NFL Team',
    'Fantasy Points', 'Projected',
    'Passing Yards', 'Passing TD', '2-Pt Passing', 'Pass Intercepted',
    'Rushing Attempts', 'Rushing Yards', 'Rushing TD', '2-Pt Rushing',
    'Targets', 'Reception', 'Receiving Yards', 'Receiving TD', '2-Pt Receiving',
    'FG Made 50+', 'FG Made 40-49', 'FG Made Under 40',
    'FG Made', 'PAT Made', 'FG Missed', 'PAT Missed', 'Fumble Lost',
    'Availability', 'Injury Status', 'Percent Owned', 'Percent Started'
  ];

  const rows = [];
  const playerIndex = {};
  const s = ESPN_EXPORT.stat;

  (data.players || []).forEach(item => {
    const ppe = item.playerPoolEntry || item;
    const p = ppe.player || item.player || {};
    const id = Number(item.id || ppe.id || p.id || 0);
    const stats = p.stats || ppe.stats || [];

    const actual = espnFindWeekStat_(stats, currentWeek, 0);
    const projection = espnFindWeekStat_(stats, currentWeek, 1);

    const name = p.fullName || item.fullName || String(id || '');
    const position = espnPrimaryPosition_(p);
    const nfl = ESPN_EXPORT.proTeam[Number(p.proTeamId)] || '';

    playerIndex[id] = { id:id, name:name, position:position, nfl:nfl, player:p, ppe:ppe };

    rows.push([
      currentWeek,
      id || '',
      name,
      position,
      nfl,
      espnAppliedTotal_(actual, ppe.appliedStatTotal),
      espnAppliedTotal_(projection, 0),
      espnStatValue_(actual, s.passYds),
      espnStatValue_(actual, s.passTD),
      espnStatValue_(actual, s.pass2pt),
      espnStatValue_(actual, s.passInt),
      espnStatValue_(actual, s.rushAtt),
      espnStatValue_(actual, s.rushYds),
      espnStatValue_(actual, s.rushTD),
      espnStatValue_(actual, s.rush2pt),
      espnStatValue_(actual, s.targets),
      espnStatValue_(actual, s.rec, s.recAlt),
      espnStatValue_(actual, s.recYds),
      espnStatValue_(actual, s.recTD),
      espnStatValue_(actual, s.rec2pt),
      espnStatValue_(actual, s.fg50p),
      espnStatValue_(actual, s.fg40_49),
      espnStatValue_(actual, s.fgUnder40),
      espnStatValue_(actual, s.fgMade),
      espnStatValue_(actual, s.patMade),
      espnStatValue_(actual, s.fgMiss),
      espnStatValue_(actual, s.patMiss),
      espnStatValue_(actual, s.fumLost),
      item.status || ppe.status || '',
      p.injuryStatus || '',
      (ppe.percentOwned !== undefined ? ppe.percentOwned :
        ((ppe.ownership || {}).percentOwned !== undefined ? ppe.ownership.percentOwned : '')),
      (ppe.percentStarted !== undefined ? ppe.percentStarted :
        ((ppe.ownership || {}).percentStarted !== undefined ? ppe.ownership.percentStarted : ''))
    ]);
  });

  return { headers: headers, rows: rows, playerIndex: playerIndex };
}


/* ============================================================================
 * TRANSACTIONS
 * ========================================================================== */

function espnGetTransactions_(cfg, currentWeek, maps, extraPlayerIndex) {
  const headers = [
    'Week', 'Transaction ID', 'Type', 'Date', 'User',
    'Action', 'Player ID', 'Player', 'Position', 'Waiver Bid',
    'From Team ID', 'To Team ID'
  ];

  const rows = [];
  const playerIndex = Object.assign({}, maps.playerIndex || {}, extraPlayerIndex || {});

  for (let week = 1; week <= currentWeek; week++) {
    let data;

    try {
      data = espnFetchLeague_(
        cfg,
        ['mTransactions2'],
        { scoringPeriodId: week },
        {
          transactions: {
            filterType: { value: ['WAIVER', 'FREEAGENT', 'TRADE_ACCEPTED'] }
          }
        }
      );
    } catch (err) {
      // ESPN can occasionally omit/deny transaction history for a period.
      continue;
    }

    (data.transactions || []).forEach(tx => {
      const teamId = Number(tx.teamId || 0);
      const user = maps.teamOwner[teamId] || maps.teamMap[teamId] || '';

      (tx.items || []).forEach(item => {
        const pid = Number(item.playerId || 0);
        const p = playerIndex[pid] || {};

        rows.push([
          Number(tx.scoringPeriodId || week),
          tx.id || '',
          tx.type || '',
          tx.processDate ? new Date(Number(tx.processDate)) : '',
          user,
          item.type || '',
          pid || '',
          p.name || String(pid || ''),
          p.position || '',
          (tx.bidAmount !== undefined ? tx.bidAmount : ''),
          item.fromTeamId || '',
          item.toTeamId || ''
        ]);
      });
    });
  }

  rows.sort((a,b) => {
    const da = a[3] instanceof Date ? a[3].getTime() : 0;
    const db = b[3] instanceof Date ? b[3].getTime() : 0;
    return db - da;
  });

  return { headers: headers, rows: rows };
}


/* ============================================================================
 * SCHEDULE / SETTINGS / SCORING / DRAFT
 * ========================================================================== */

function espnWriteSchedule_(ss, core, maps) {
  const count = Number((((core.settings || {}).scheduleSettings || {}).matchupPeriodCount) || 18);
  const headers = ['Roster ID'];
  for (let w = 1; w <= count; w++) headers.push('Week ' + w);

  const opponents = {};
  (core.teams || []).forEach(t => opponents[t.id] = {});

  (core.schedule || []).forEach(m => {
    const w = Number(m.matchupPeriodId || 0);
    if (!w || w > count) return;

    const home = m.home ? Number(m.home.teamId || 0) : 0;
    const away = m.away ? Number(m.away.teamId || 0) : 0;
    if (home && away) {
      if (!opponents[home]) opponents[home] = {};
      if (!opponents[away]) opponents[away] = {};
      opponents[home][w] = away;
      opponents[away][w] = home;
    }
  });

  const rows = (core.teams || []).map(t => {
    const row = [t.id];
    for (let w = 1; w <= count; w++) row.push(opponents[t.id][w] || '');
    return row;
  });

  espnWriteTable_(ss, 'Data_Schedule', headers, rows);
}


function espnWriteSettings_(ss, core) {
  const rows = [];
  espnFlatten_('settings', core.settings || {}, rows);
  espnFlatten_('status', core.status || {}, rows);

  espnWriteTable_(ss, 'Data_Settings', ['Path', 'Value'], rows);
}


function espnFlatten_(path, value, out) {
  if (value === null || value === undefined) {
    out.push([path, '']);
    return;
  }

  if (Array.isArray(value)) {
    if (!value.length) {
      out.push([path, '[]']);
      return;
    }

    value.forEach((v,i) => espnFlatten_(path + '/' + i, v, out));
    return;
  }

  if (typeof value === 'object') {
    const keys = Object.keys(value);
    if (!keys.length) {
      out.push([path, '{}']);
      return;
    }

    keys.forEach(k => espnFlatten_(path + '/' + k, value[k], out));
    return;
  }

  out.push([path, value]);
}


function espnWriteScoring_(ss, core) {
  const items =
    ((((core.settings || {}).scoringSettings || {}).scoringItems)) ||
    [];

  const headers = ['Stat ID', 'Stat', 'Points', 'Active', 'Reverse', 'Overrides'];
  const rows = items.map(item => [
    item.statId !== undefined ? item.statId : '',
    espnStatName_(item.statId),
    item.points !== undefined ? item.points : '',
    item.points !== 0,
    !!item.isReverseItem,
    item.pointsOverrides ? JSON.stringify(item.pointsOverrides) : ''
  ]);

  espnWriteTable_(ss, 'Data_Scoring', headers, rows);
}


function espnStatName_(statId) {
  const map = {
    0:'Passing Attempts',1:'Pass Completions',2:'Incomplete Passes',3:'Passing Yards',
    4:'Passing TD',15:'Passing TD 40+',16:'Passing TD 50+',17:'Passing 300-399',
    18:'Passing 400+',19:'Passing 2PT',20:'Pass Interceptions',
    23:'Rushing Attempts',24:'Rushing Yards',25:'Rushing TD',26:'Rushing 2PT',
    35:'Rushing TD 40+',36:'Rushing TD 50+',37:'Rushing 100-199',38:'Rushing 200+',
    41:'Receptions',42:'Receiving Yards',43:'Receiving TD',44:'Receiving 2PT',
    45:'Receiving TD 40+',46:'Receiving TD 50+',53:'Receptions',56:'Receiving 100-199',
    57:'Receiving 200+',58:'Targets',68:'Fumbles',72:'Fumbles Lost',
    74:'FG Made 50+',77:'FG Made 40-49',80:'FG Made Under 40',
    83:'FG Made',85:'FG Missed',86:'PAT Made',88:'PAT Missed'
  };
  return map[Number(statId)] || ('Stat ' + statId);
}


function espnWriteDraft_(ss, core, maps) {
  const headers = [
    'Round', 'Overall Pick', 'Player ID', 'Player', 'Position',
    'NFL Team', 'Drafted By', 'Team ID', 'Keeper', 'Bid'
  ];

  const rows = [];
  const picks = (((core.draftDetail || {}).picks) || []);

  picks.forEach(pick => {
    const p = maps.playerIndex[Number(pick.playerId)] || {};
    rows.push([
      pick.roundId || '',
      pick.overallPickNumber || '',
      pick.playerId || '',
      p.name || String(pick.playerId || ''),
      p.position || '',
      p.nfl || '',
      maps.teamOwner[Number(pick.teamId)] || maps.teamMap[Number(pick.teamId)] || '',
      pick.teamId || '',
      pick.keeper || pick.keeperValue || '',
      pick.bidAmount || ''
    ]);
  });

  espnWriteTable_(ss, 'Data_Draft_Result', headers, rows);
}


/* ============================================================================
 * STATUS / SHEET WRITING
 * ========================================================================== */

function espnWriteStatus_(ss, cfg, currentWeek, counts) {
  const rows = [
    ['League ID', cfg.leagueId, 'League Settings!C2'],
    ['Season', cfg.season, 'League Settings!C1'],
    ['Analysis Week', currentWeek, 'Current ESPN scoring/matchup period'],
    ['Rosters', 'OK', 'mRoster'],
    ['Roster Summary', 'OK', 'Derived from mRoster + mSettings'],
    ['Standings', 'OK', 'mTeam/mStandings + all-play derived'],
    ['Weekly Results', 'OK', 'mMatchupScore'],
    ['Player Results', 'OK', 'mBoxscore; actual + projected points'],
    ['Transactions', 'OK', 'mTransactions2'],
    ['Free Agents', 'OK', 'kona_player_info: FREEAGENT + WAIVERS'],
    ['Schedule', 'OK', 'mSchedule'],
    ['Settings', 'OK', 'mSettings'],
    ['Scoring', 'OK', 'mSettings.scoringSettings.scoringItems'],
    ['Users', 'OK', 'mTeam.members'],
    ['Draft Result', 'OK', 'mDraftDetail'],
    ['Roster player rows', counts.rosters || 0, 'Data_Player_Results rows'],
    ['Free-agent rows', counts.freeAgents || 0, 'Data_Free_Agents rows'],
    ['Transaction rows', counts.transactions || 0, 'Data_Transactions rows'],
    ['Last Update', new Date(), 'Local spreadsheet timezone']
  ];

  espnWriteTable_(ss, 'Data_Status', ['Campo', 'Valor', 'Observação'], rows);
}


function espnSetStatus_(ss, field, value, when) {
  const sh = espnGetOrCreateSheet_(ss, 'Data_Status');
  if (sh.getLastRow() < 1) {
    sh.getRange(1,1,1,3).setValues([['Campo','Valor','Observação']]);
  }
  sh.appendRow([field, value, when || '']);
}


function espnGetOrCreateSheet_(ss, name) {
  return ss.getSheetByName(name) || ss.insertSheet(name);
}


function espnWriteTable_(ss, sheetName, headers, rows) {
  const sh = espnGetOrCreateSheet_(ss, sheetName);
  sh.clearContents();

  const width = Math.max(headers.length, 1);
  sh.getRange(1, 1, 1, width).setValues([headers]);

  if (rows && rows.length) {
    const normalized = rows.map(r => {
      const out = r.slice(0, width);
      while (out.length < width) out.push('');
      return out;
    });
    sh.getRange(2, 1, normalized.length, width).setValues(normalized);
  }

  sh.setFrozenRows(1);

  const header = sh.getRange(1,1,1,width);
  header.setFontWeight('bold')
        .setBackground('#1E2D4D')
        .setFontColor('#FFFFFF');

  sh.autoResizeColumns(1, Math.min(width, 20));

  // Keep very wide stat tables readable.
  if (width > 20) {
    for (let c = 21; c <= width; c++) sh.setColumnWidth(c, 105);
  }
}
