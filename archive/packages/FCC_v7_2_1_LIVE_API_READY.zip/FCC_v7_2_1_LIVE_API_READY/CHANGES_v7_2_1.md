# Fantasy Command Center 2026 — v7.2.1

Revisão aplicada diretamente sobre a v7.2 Live API Ready.

## Interface e estado
- Central de decisões agora respeita a liga selecionada e não exibe mais a versão técnica ao lado do título.
- Alertas urgentes/importantes ganharam destaque visual permanente por gravidade.
- Confrontos em andamento exibem selo **AO VIVO** durante toda a ocorrência do jogo.
- Notícias passam a ser ordenadas pela publicação mais recente primeiro; criticidade continua destacada visualmente.
- `Hoje no Fantasy` não repete sugestão de escalação depois que o confronto da liga já começou/encerrou.
- KPIs da Home respeitam a liga selecionada e destacam Alertas/Notícias relevantes.
- Disponibilidade da ficha/watchlist usa estados explícitos: roster próprio, livre/waiver, roster de outro time ou sem dado de disponibilidade.
- Quando a ESPN não fornece `restantes`, o app tenta derivar a contagem a partir dos titulares + estado conhecido dos jogos NFL.

## Elencos
- Removido o botão **Exportar CSV filtrado** da tela de Elencos.

## Trocas
- Jogadores em pacotes 2×1/1×2 agora são renderizados em blocos individuais; no mobile o campo deixa de misturar o segundo jogador com o rótulo/coluna.

## Notificações
- Adicionado `app/src/main/res/drawable-nodpi/ic_stat_fcc.png`, derivado do ícone oficial FCC (letras + bola) e convertido para máscara monocromática apropriada ao Android.
- `FantasyNotificationReceiver` usa `R.drawable.ic_stat_fcc` como `smallIcon` no lugar de `R.mipmap.ic_launcher`.
- Patch de Manifest inclui o mesmo recurso como ícone padrão de notificação para eventual uso por Firebase/FCM.
