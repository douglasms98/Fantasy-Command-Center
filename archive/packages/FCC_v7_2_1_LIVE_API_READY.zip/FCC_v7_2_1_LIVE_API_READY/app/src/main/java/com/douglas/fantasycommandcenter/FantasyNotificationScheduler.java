package com.douglas.fantasycommandcenter;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

public final class FantasyNotificationScheduler {
    private static final String PREFS = "fcc_notifications_v7";
    private static final String KEY_IDS = "scheduled_ids";
    private static final String KEY_JSON = "scheduled_json";
    public static final String CHANNEL_ID = "fantasy_alerts_v7";

    private FantasyNotificationScheduler() {}

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Fantasy Football",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Alertas de rodada, waivers e mudanças importantes do Fantasy Command Center");
            nm.createNotificationChannel(channel);
        }
    }

    public static void schedule(Context context, String json) {
        SharedPreferences appPrefs = context.getSharedPreferences(SyncRepository.PREFS, Context.MODE_PRIVATE);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = json == null ? "[]" : json;
        prefs.edit().putString(KEY_JSON, raw).apply();

        cancelAll(context, false);
        if (!appPrefs.getBoolean("notifications_enabled", true)) return;

        ensureChannel(context);
        JSONArray array;
        try {
            array = new JSONArray(raw);
        } catch (Exception e) {
            return;
        }

        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        Set<String> ids = new HashSet<>();
        long now = System.currentTimeMillis();

        for (int i = 0; i < array.length(); i++) {
            JSONObject e = array.optJSONObject(i);
            if (e == null) continue;

            String id = e.optString("id", "fcc-" + i);
            if (id.trim().isEmpty()) id = "fcc-" + i;
            Long whenMs = parseInstant(e.optString("at", ""));
            if (whenMs == null || whenMs <= now) continue;

            Intent intent = new Intent(context, FantasyNotificationReceiver.class)
                    .putExtra("event_id", id)
                    .putExtra("title", e.optString("title", "Fantasy Command Center"))
                    .putExtra("body", e.optString("body", "Há uma atualização importante no fantasy."))
                    .putExtra("type", e.optString("type", ""))
                    .putExtra("league_id", e.optString("leagueId", ""));

            PendingIntent pi = PendingIntent.getBroadcast(
                    context,
                    id.hashCode(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            scheduleAlarm(alarm, whenMs, pi);
            ids.add(id);
        }

        prefs.edit().putStringSet(KEY_IDS, ids).apply();
    }

    public static void rescheduleSaved(Context context) {
        SharedPreferences appPrefs = context.getSharedPreferences(SyncRepository.PREFS, Context.MODE_PRIVATE);
        if (!appPrefs.getBoolean("notifications_enabled", true)) return;
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_JSON, "");
        if (raw != null && !raw.trim().isEmpty()) schedule(context, raw);
    }

    public static void cancelAll(Context context, boolean clearSaved) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> ids = prefs.getStringSet(KEY_IDS, new HashSet<>());
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        if (alarm != null && ids != null) {
            for (String id : new HashSet<>(ids)) {
                PendingIntent pi = PendingIntent.getBroadcast(
                        context,
                        id.hashCode(),
                        new Intent(context, FantasyNotificationReceiver.class),
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                );
                if (pi != null) alarm.cancel(pi);
            }
        }

        SharedPreferences.Editor ed = prefs.edit().remove(KEY_IDS);
        if (clearSaved) ed.remove(KEY_JSON);
        ed.apply();
    }

    public static void scheduleTest(Context context, long delayMs) {
        ensureChannel(context);
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        String id = "fcc-notification-test";
        Intent intent = new Intent(context, FantasyNotificationReceiver.class)
                .putExtra("event_id", id)
                .putExtra("title", "Fantasy Command Center")
                .putExtra("body", "Notificações funcionando corretamente.")
                .putExtra("type", "test");
        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                id.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        scheduleAlarm(alarm, System.currentTimeMillis() + Math.max(2000L, delayMs), pi);
    }

    public static String diagnostics(Context context) {
        try {
            SharedPreferences appPrefs = context.getSharedPreferences(SyncRepository.PREFS, Context.MODE_PRIVATE);
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            boolean permission = Build.VERSION.SDK_INT < 33 ||
                    context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            boolean exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                    (alarm != null && alarm.canScheduleExactAlarms());
            boolean notificationsAllowed = nm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N || nm.areNotificationsEnabled();
            Set<String> ids = prefs.getStringSet(KEY_IDS, new HashSet<>());

            JSONObject o = new JSONObject();
            o.put("enabled", appPrefs.getBoolean("notifications_enabled", true));
            o.put("notificationPermission", permission && notificationsAllowed);
            o.put("exactAlarmAllowed", exactAllowed);
            o.put("scheduledCount", ids == null ? 0 : ids.size());
            o.put("channel", CHANNEL_ID);
            o.put("hasSavedSchedule", !prefs.getString(KEY_JSON, "").trim().isEmpty());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    private static void scheduleAlarm(AlarmManager alarm, long whenMs, PendingIntent pi) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarm.canScheduleExactAlarms()) {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi);
            } else {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi);
        } else {
            alarm.setExact(AlarmManager.RTC_WAKEUP, whenMs, pi);
        }
    }

    private static Long parseInstant(String raw) {
        try {
            return Instant.parse(raw).toEpochMilli();
        } catch (Exception e) {
            return null;
        }
    }
}
