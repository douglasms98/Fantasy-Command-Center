# Status da atualização geral

## Pronto no pacote Android v7.2
- API Cloud Run tratada como operacional, não como teste visual.
- refresh automático da API.
- fallback Sync API preservado.
- strings antigas/preview/W4 removidas da UI visível.
- W4-only matchup fallback removido.
- player modal usa janela móvel das últimas 3 semanas.
- NewsRepository resiliente.
- scheduler de notificações persistente + reboot/update recovery + fallback de alarme.
- diagnóstico e teste de notificação em 8 segundos.

## Backend ainda precisa concluir antes do APK final
- validar `season_engine.py` contra as 3 ligas;
- conectar `season` ao `SyncService`/Firestore;
- implementar snapshot semanal retry-safe no Firestore;
- simular rollover W4→W5;
- só depois avaliar `FCC_ENABLE_APP_CUTOVER=true` para `/v1/app-payload`.

## Decisão de segurança arquitetural
Não foi habilitado o cutover global apenas porque o overlay funcionou. O Cloud Run já pode operar normalmente no app pelos endpoints `/v1/leagues/{id}`; ligar o cutover único antes de migrar todos os campos poderia apagar dados que hoje ainda chegam pelo Sync API.
