# Fantasy Command Center 2026 — v7.2.1 Live API Ready

Pacote preparado sobre a base v7.1 LIVE_DYNAMIC.

## O que foi implementado

- Cloud Run deixa de aparecer como "Shadow/homologação" na interface e passa a ser tratado como API FCC operacional.
- Atualização da API continua automática ao abrir/retomar o app e periodicamente enquanto a WebView está ativa.
- Após uma atualização do Sync API de compatibilidade, o app força nova atualização da API FCC para manter o Cloud Run com prioridade nos campos validados.
- O cliente Android usa `backendNow()` como contrato normal; `backendShadowNow()` permanece apenas como alias de compatibilidade com builds antigas.
- O cache/chave antigos (`backend_shadow_*`) foram mantidos internamente para não perder a configuração já salva no aparelho.
- Preparado para receber `data.season` e `data.currentWeek` do backend assim que o Season Engine for conectado ao sync.
- Removidos textos visíveis de W4, preview antiga, homologação e horários fixos de planilha.
- Removidos fallbacks executáveis exclusivos da W4 para confronto/projeção.
- A ficha do jogador usa as três semanas concluídas mais recentes em vez de ficar presa a W1/W2/W3.
- NewsRepository v7.1 resiliente incluído: falha em um lote de Google News não derruba os demais nem apaga o cache válido.

## Notificações

A implementação foi refeita para corrigir as causas mais prováveis de ausência de alertas:

- agenda persistida em SharedPreferences, não apenas IDs de PendingIntent;
- reagendamento ao reabrir o app;
- reagendamento após BOOT_COMPLETED e MY_PACKAGE_REPLACED;
- Android 12+: usa alarme exato quando permitido e cai automaticamente para `setAndAllowWhileIdle()` quando não for;
- Android 13+: respeita `POST_NOTIFICATIONS`;
- diagnóstico nativo disponível para a interface;
- botão "Testar notificação (8 s)" para validar canal/permissão/AlarmManager no aparelho.

Não é necessário adicionar `SCHEDULE_EXACT_ALARM`: o fallback evita depender dessa permissão especial.

## Arquivos para substituir/adicionar no projeto Android

Substituir:
- `app/src/main/assets/fcc/index.html`
- `app/src/main/java/com/douglas/fantasycommandcenter/MainActivity.java`
- `app/src/main/java/com/douglas/fantasycommandcenter/BackendApiRepository.java`
- `app/src/main/java/com/douglas/fantasycommandcenter/NewsRepository.java`

Adicionar/substituir o scheduler antigo:
- `app/src/main/java/com/douglas/fantasycommandcenter/FantasyNotificationScheduler.java`
- `app/src/main/java/com/douglas/fantasycommandcenter/FantasyNotificationReceiver.java`
- `app/src/main/java/com/douglas/fantasycommandcenter/FantasyNotificationBootReceiver.java`

Mesclar:
- `manifest/AndroidManifest_v7_2_patch.xml`

Se ainda existir `FantasyNotificationScheduler.kt`, remova-o após adicionar os três arquivos Java acima para evitar duas classes com o mesmo nome/pacote.

## Importante sobre o cutover

Este pacote torna a API Cloud Run uma integração operacional automática no app, mas **não exige ligar `FCC_ENABLE_APP_CUTOVER` ainda**. O app continua usando o Sync API como fallback para campos que ainda não foram migrados integralmente (rosters/free agents/alguns cálculos). Isso evita perder funcionalidade durante a conclusão do backend Season/History.

Depois que Season + History + paridade dos dados estiverem comprovados, o endpoint único `/v1/app-payload` pode ser liberado e o fallback reduzido gradualmente.


## Complemento v7.2.1
Além dos arquivos listados acima, copie também:
- `app/src/main/res/drawable-nodpi/ic_stat_fcc.png`

Esta revisão também atualiza `index.html`, `FantasyNotificationReceiver.java` e o patch de Manifest conforme `CHANGES_v7_2_1.md`.
