# Fantasy Command Center 2026 — v7.3.1

## Objetivo
Retirar Google Sheets do caminho crítico das informações atuais. Sleeper/ESPN → Cloud Run → Firestore passa a ter prioridade operacional; Sheets/Sync API permanecem para backup, compatibilidade e histórico ainda não migrado.

## Android
- FCC Cloud inicia primeiro ao abrir o app.
- Cloud é relido a cada ~4 min enquanto o app está em uso.
- Sync API/planilhas passa a ciclo de compatibilidade de ~30 min.
- Depois de qualquer Sync API, o último snapshot Cloud válido é reaplicado, impedindo que planilha atrasada sobrescreva roster/rodada/matchup já mais novos.
- Saúde online considera provider + backend; atraso da planilha não rebaixa uma fonte online funcional.
- Freshness visível prioriza `providerUpdatedAt`.
- IDs de jogadores ocupados vindos diretamente do provider bloqueiam falsos Free Agents/Waivers.
- Standings/record atual passam a ser reconstruídos diretamente do provider quando o payload permite.
- Roster atual é reconciliado pelos IDs do provider usando os metadados já conhecidos no app; Sheets deixa de decidir ownership atual.
- Notícias/status são solicitados em ciclo menor (~10 min).

## Cloud Run
O patch `cloud_run/apply_v7_3_1_cloud.sh`:
1. persiste o snapshot direto do provider imediatamente após `adapter.fetch()`;
2. só depois continua enriquecimentos/backup via Sheets;
3. executa compileall + pytest antes do deploy;
4. redeploya apenas `fcc-worker`;
5. altera o Scheduler existente para 5 minutos;
6. força uma sincronização após o deploy.

## Limite ainda existente
O histórico/Season Engine ainda pode usar planilhas para partes que não foram migradas ao provider. A v7.3.1 impede que essa lentidão determine o estado operacional atual, mas não remove Sheets completamente do backend.

## Rollback
`cloud_run/rollback_v7_3_1_cloud.sh` restaura o último `sync_service.py.pre_v731_*`, redeploya o worker e retorna o Scheduler a 15 minutos.
