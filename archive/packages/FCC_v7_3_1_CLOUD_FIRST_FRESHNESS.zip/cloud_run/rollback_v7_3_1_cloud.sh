#!/usr/bin/env bash
set -euo pipefail
PROJECT_ID="${PROJECT_ID:-fantasy-command-center-2026}"
REGION="${REGION:-southamerica-east1}"
BACKEND_DIR="${BACKEND_DIR:-$HOME/FCC_Backend_v0_1/backend}"
SCHEDULER_JOB="${SCHEDULER_JOB:-fcc-sync-15m}"
cd "$BACKEND_DIR"
BACKUP="$(ls -1t app/sync_service.py.pre_v731_* 2>/dev/null | head -1 || true)"
if [[ -z "$BACKUP" ]]; then
  echo "Nenhum backup pre_v731 encontrado. Abortando."
  exit 1
fi
cp "$BACKUP" app/sync_service.py
python3 -m compileall -q app tests
python3 -m pytest -q
gcloud run deploy fcc-worker --source . --region="$REGION" --project="$PROJECT_ID" --quiet
gcloud scheduler jobs update http "$SCHEDULER_JOB" --location="$REGION" --project="$PROJECT_ID" --schedule="*/15 * * * *" --time-zone="America/Sao_Paulo" --quiet
echo "Rollback Cloud v7.3.1 concluido; scheduler voltou para 15 min."
