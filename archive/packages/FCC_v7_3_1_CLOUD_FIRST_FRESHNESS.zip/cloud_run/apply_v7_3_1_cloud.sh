#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-fantasy-command-center-2026}"
REGION="${REGION:-southamerica-east1}"
BACKEND_DIR="${BACKEND_DIR:-$HOME/FCC_Backend_v0_1/backend}"
SCHEDULER_JOB="${SCHEDULER_JOB:-fcc-sync-15m}"

cd "$BACKEND_DIR"
TS="$(date +%Y%m%d_%H%M%S)"
cp app/sync_service.py "app/sync_service.py.pre_v731_${TS}"

echo "[1/5] Aplicando persistencia provider-first..."
python3 - <<'PY'
from pathlib import Path

p = Path("app/sync_service.py")
s = p.read_text()
marker = "# FCC_V731_PROVIDER_FIRST"
if marker not in s:
    needle = "                league = await adapter.fetch(cfg)\n"
    if needle not in s:
        raise SystemExit("ERRO: ponto 'league = await adapter.fetch(cfg)' nao encontrado em app/sync_service.py")
    patch = needle + """\
                # FCC_V731_PROVIDER_FIRST
                # Persiste o snapshot direto do provider antes de qualquer leitura de Sheets.
                # Assim, uma planilha lenta nao bloqueia roster/matchup/transacoes atuais no FCC.
                try:
                    self.repo.save_league(league, run.runId)
                except Exception as early_save_error:
                    league.source.notes.append(
                        f'Provider-first save failed: {early_save_error}'
                    )
"""
    s = s.replace(needle, patch, 1)
    p.write_text(s)
    print("FCC_V731_PROVIDER_FIRST_APPLIED")
else:
    print("FCC_V731_PROVIDER_FIRST_ALREADY_PRESENT")
PY

echo "[2/5] Validando Python e testes..."
python3 -m compileall -q app tests
python3 -m pytest -q

echo "[3/5] Deploy do worker..."
gcloud run deploy fcc-worker \
  --source . \
  --region="$REGION" \
  --project="$PROJECT_ID" \
  --quiet

echo "[4/5] Alterando Scheduler de 15 min para 5 min..."
gcloud scheduler jobs update http "$SCHEDULER_JOB" \
  --location="$REGION" \
  --project="$PROJECT_ID" \
  --schedule="*/5 * * * *" \
  --time-zone="America/Sao_Paulo" \
  --quiet

echo "[5/5] Executando uma sincronizacao agora..."
gcloud scheduler jobs run "$SCHEDULER_JOB" \
  --location="$REGION" \
  --project="$PROJECT_ID"

echo
echo "v7.3.1 CLOUD PATCH APLICADO."
echo "O fcc-api nao precisa de deploy: ele continua lendo os snapshots do Firestore."
echo "Aguarde alguns segundos e rode cloud_run/verify_v7_3_1_cloud.sh."
