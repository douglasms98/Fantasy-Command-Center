#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-fantasy-command-center-2026}"
REGION="${REGION:-southamerica-east1}"
BACKEND_DIR="${BACKEND_DIR:-$HOME/FCC_Backend_v0_1/backend}"
SCHEDULER_JOB="${SCHEDULER_JOB:-fcc-sync-15m}"

cd "$BACKEND_DIR"

echo "=== PATCH ==="
grep -n "FCC_V731_PROVIDER_FIRST" app/sync_service.py || true

echo
echo "=== WORKER ==="
gcloud run services describe fcc-worker \
  --region="$REGION" \
  --project="$PROJECT_ID" \
  --format="table(metadata.name,status.latestReadyRevisionName,status.url)"

echo
echo "=== SCHEDULER ==="
gcloud scheduler jobs describe "$SCHEDULER_JOB" \
  --location="$REGION" \
  --project="$PROJECT_ID" \
  --format="yaml(name,schedule,timeZone,state,httpTarget.uri)"

echo
echo "=== FIRESTORE ==="
python3 - <<'PY'
from app.repositories.firestore import FirestoreRepo
from app.league_config import league_configs

repo = FirestoreRepo()
for cfg in league_configs():
    root = repo.get_league_root(cfg.id) or {}
    src = root.get('source') or {}
    print()
    print('====', cfg.id, cfg.platform, '====')
    print('analysisWeek      =', root.get('analysisWeek'))
    print('completedWeeks    =', root.get('completedWeeks'))
    print('providerUpdatedAt =', src.get('providerUpdatedAt'))
    print('backendUpdatedAt  =', src.get('backendUpdatedAt'))
    print('sheetUpdatedAt    =', src.get('sheetUpdatedAt'))
    print('providerStatus    =', src.get('providerStatus'))
    print('backendStatus     =', src.get('backendStatus'))
    print('sheetStatus       =', src.get('sheetStatus'))
PY
