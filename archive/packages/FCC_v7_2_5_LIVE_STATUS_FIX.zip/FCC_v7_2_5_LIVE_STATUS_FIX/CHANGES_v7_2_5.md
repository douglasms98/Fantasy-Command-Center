# Fantasy Command Center — v7.2.5 Live Status Fix

## Correção principal

- Corrige falso **AO VIVO** depois do encerramento da rodada.
- O app não considera mais a simples existência de placar como prova de partida ao vivo.
- Prioridade de estado: `FINAL` explícito/flag > jogadores restantes = 0 > convergência placar/projeção > `LIVE` explícito/flag > jogadores restantes > estado de atualização.
- Quando há placar mas nenhuma evidência confiável de live/final, mostra **Aguardando fechamento** em vez de **AO VIVO**.
- Central de decisões, cards de confronto e otimizador passam a usar a mesma regra de estado.

## Preservado

- Tema Semi-dark corrigido da v7.2.4.
- Full Dark AMOLED.
- Cloud Run + Sync API fallback.
- Notificações e scheduler.
- Manifest completo da v7.2.4.
- Recursos de launcher/notificação da v7.2.4.
