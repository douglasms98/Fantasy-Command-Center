# Fantasy Command Center 2026 — v6.0.1

Projeto Android Studio completo para o package existente:

`com.douglas.fantasycommandcenter`

## O que esta versão entrega

- Dashboard v6.0.1 mobile-first, tema claro/escuro e cache offline.
- Sincronização online via Google Apps Script + Google Sheets.
- Sincronização automática ao abrir o app.
- Sincronização periódica em segundo plano (WorkManager, a cada ~6 h quando houver rede).
- Cache do último payload válido para uso sem internet.
- Persistência de configuração e estado da interface.
- Notificações Android mesmo com o app fechado:
  - pré-rodada: aproximadamente 2 h antes do primeiro jogo de quinta;
  - pós-rodada: após o Monday Night Football;
  - início da janela de waivers por liga;
  - fim/processamento dos waivers por liga.
- Reagendamento das notificações após reinício do aparelho / atualização do APK.
- Fallback de alarmes quando o Android não autoriza alarmes exatos.
- Hotfix de confrontos v6.0.1:
  - Sleeper: tenta `Week N` e, se necessário, `Weekly Results`, Matchups/Schedule e aliases.
  - ESPN: tenta `Data_Matchups` e, se necessário, `Data_Weekly_Results` / Schedule.
  - o card informa a origem do confronto (`Planilha • ...`).

## Confrontos validados nas planilhas em 03/10/2026

- Paga PPR, W4: RJ Outlaws × PatsNation.
- Sunday Night Fumble, W4: Guarus Outlaws × MarcusMarques.
- ESPN Cartola VK, RJ Outlaws: Roster ID 3; `Data_Matchups` contém a agenda da liga.

Isto confirma que o antigo `SEM DADOS` era falha de leitura/parser e não ausência dos dados nas planilhas.

## Ferramentas do projeto

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- Java: 17
- compileSdk / targetSdk: 37
- minSdk: 26
- WorkManager: 2.12.0
- versionCode: 601
- versionName: 6.0.1

## Para compilar no Android Studio

1. Extraia a pasta inteira do ZIP.
2. Android Studio > **Open** > selecione a pasta `FantasyCommandCenter_v6_0_AndroidStudio`.
3. Aguarde o Gradle Sync e a instalação do SDK 37, caso o Android Studio solicite.
4. Para teste: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Para atualizar o APK que já está no celular, gere/assine com a **mesma keystore/chave** usada na versão instalada. O package foi mantido.

## Etapa necessária do servidor (uma vez para este hotfix)

O APK conversa com o Google Apps Script. Como o defeito de confrontos estava também no parser do servidor, o arquivo abaixo precisa substituir a versão atual do Web App:

`apps-script/Fantasy_Command_Center_Sync_API_v6_0_1.gs`

No Google Apps Script:

1. Substitua o código pelo conteúdo desse arquivo.
2. Preserve a propriedade `FCC_SYNC_KEY` já existente. Não é necessário gerar uma chave nova se você já usa uma.
3. **Deploy > Manage deployments > Edit > New version > Deploy**.
4. Mantenha a mesma URL `/exec`. Assim o endpoint salvo no app continua funcionando.

Sem essa republicação, o APK ainda consegue usar cache/recursos locais, mas continuará recebendo o payload antigo do servidor e o hotfix de confronto não será plenamente aplicado.

## Primeira abertura / atualização

- Se a instalação anterior já tinha URL e token salvos e a atualização for instalada por cima, as SharedPreferences normalmente são preservadas.
- Abra **Sincronização** e toque em **Atualizar dados agora** para confirmar.
- Nos cards de confronto, procure a origem, por exemplo `Planilha • Weekly Results` ou `Planilha • Data_Matchups`.
- No Android 13+, autorize notificações quando solicitado.

## Arquivos principais

- `app/src/main/assets/fcc/index.html` — dashboard v6.0.1.
- `MainActivity.java` — WebView e ponte `AndroidSync`.
- `SyncRepository.java` — cliente HTTP, cache e aplicação do payload.
- `PeriodicSyncWorker.java` — sincronização periódica.
- `FantasyNotificationScheduler.java` — alarmes/notificações.
- `FantasyNotificationReceiver.java` — exibição do alerta.
- `BootReceiver.java` — reagendamento após boot/atualização.
- `apps-script/Fantasy_Command_Center_Sync_API_v6_0_1.gs` — API/sincronização e parser de confrontos.

## Validações realizadas nesta entrega

- Sintaxe JavaScript do dashboard: OK (`node --check`).
- Sintaxe JavaScript do Apps Script: OK (`node --check` no código compatível JS).
- Estrutura real das planilhas Sleeper e ESPN inspecionada e usada no hotfix de confrontos.
- O ambiente de geração deste pacote não possui acesso de rede ao `services.gradle.org` nem Android SDK, portanto o `assembleDebug` completo não pôde ser executado aqui. O Android Studio fará o download do Gradle/dependências e executará a compilação no seu PC.

