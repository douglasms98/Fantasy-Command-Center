package com.douglas.fantasycommandcenter;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public final class SyncRepository {
    public static final String PREFS="fcc_native", KEY_ENDPOINT="sync_endpoint", KEY_TOKEN="sync_token", KEY_CACHE="cached_payload", KEY_LAST="last_sync";
    private SyncRepository(){}
    public static String sync(Context context) throws Exception {
        SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        String endpoint=p.getString(KEY_ENDPOINT,""); String token=p.getString(KEY_TOKEN,"");
        if(endpoint==null||endpoint.trim().isEmpty()) throw new IllegalStateException("Endpoint de sincronização não configurado.");
        String sep=endpoint.contains("?")?"&":"?";
        URL url=new URL(endpoint+sep+"key="+URLEncoder.encode(token==null?"":token,StandardCharsets.UTF_8.name())+"&t="+System.currentTimeMillis());
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("GET"); c.setUseCaches(false); c.setRequestProperty("Accept","application/json");
        int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        String body=read(in); c.disconnect();
        if(code<200||code>=300) throw new IOException("HTTP "+code+": "+body);
        JSONObject j=new JSONObject(body); if(!j.optBoolean("ok",false)) throw new IOException(j.optString("error","Resposta inválida do servidor"));
        String now=j.optString("generatedAt",java.time.Instant.now().toString());
        p.edit().putString(KEY_CACHE,body).putString(KEY_LAST,now).apply();
        FantasyNotificationScheduler.scheduleFromPayload(context,j);
        return body;
    }
    private static String read(InputStream in)throws IOException{if(in==null)return"";BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();return sb.toString();}
}
