package com.douglas.fantasycommandcenter;

import android.app.*;
import android.content.*;
import android.os.Build;
import org.json.*;
import java.time.Instant;

public final class FantasyNotificationScheduler {
    public static final String CHANNEL_ID="fcc_fantasy_alerts";
    private static final String PREFS="fcc_native", KEY_EVENTS="notification_events_json";
    private FantasyNotificationScheduler(){}
    public static void ensureChannel(Context c){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"Fantasy Football",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Rodada, confrontos e waivers do Fantasy Command Center");((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
    public static void scheduleFromPayload(Context c,JSONObject payload){schedule(c,payload.optJSONArray("notificationEvents"));}
    public static void schedule(Context c,String json){try{schedule(c,new JSONArray(json));}catch(Exception ignored){}}
    public static void schedule(Context c,JSONArray events){ensureChannel(c);cancelAll(c,false);if(events==null)events=new JSONArray();c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY_EVENTS,events.toString()).apply();
        boolean enabled=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getBoolean("notifications_enabled",true);if(!enabled)return;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);long now=System.currentTimeMillis();
        for(int i=0;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;String id=e.optString("id","fcc-"+i),at=e.optString("at","");long when;try{when=Instant.parse(at).toEpochMilli();}catch(Exception ex){continue;}if(when<=now)continue;
            Intent intent=new Intent(c,FantasyNotificationReceiver.class).putExtra("event_id",id).putExtra("title",e.optString("title","Fantasy Command Center")).putExtra("body",e.optString("body","Há uma atualização importante.")).putExtra("type",e.optString("type","")).putExtra("league_id",e.optString("leagueId",""));
            PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=31){if(am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);}else if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
        }
    }
    public static void rescheduleSaved(Context c){String raw=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY_EVENTS,"[]");schedule(c,raw);}
    public static void cancelAll(Context c,boolean erase){String raw=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY_EVENTS,"[]");AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject e=a.optJSONObject(i);if(e==null)continue;String id=e.optString("id","fcc-"+i);PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),new Intent(c,FantasyNotificationReceiver.class),PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null)am.cancel(pi);}}catch(Exception ignored){}if(erase)c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().remove(KEY_EVENTS).apply();}
}
