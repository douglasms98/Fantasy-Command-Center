package com.douglas.fantasycommandcenter;

import android.Manifest;import android.app.*;import android.os.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.net.Uri;import android.provider.Settings;import android.util.Base64;import android.view.*;import android.webkit.*;import java.nio.charset.StandardCharsets;import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView web; private final ExecutorService executor=Executors.newSingleThreadExecutor(); private android.content.SharedPreferences prefs;
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(SyncRepository.PREFS,MODE_PRIVATE);getWindow().setStatusBarColor(Color.rgb(7,16,31));getWindow().setNavigationBarColor(Color.rgb(7,16,31));
        web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setCacheMode(WebSettings.LOAD_DEFAULT);s.setMediaPlaybackRequiresUserGesture(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new AndroidSyncBridge(),"AndroidSync");web.setWebChromeClient(new WebChromeClient());web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){Uri u=r.getUrl();if("file".equals(u.getScheme()))return false;startActivity(new Intent(Intent.ACTION_VIEW,u));return true;} @Override public void onPageFinished(WebView v,String url){super.onPageFinished(v,url);}});
        if(b!=null)web.restoreState(b);else web.loadUrl("file:///android_asset/fcc/index.html");FantasyNotificationScheduler.ensureChannel(this);PeriodicSyncWorker.ensure(this);requestNotificationPermission();}
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1001);}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);} @Override protected void onDestroy(){executor.shutdownNow();web.destroy();super.onDestroy();}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    private void js(String code){runOnUiThread(()->web.evaluateJavascript(code,null));}
    private void callbackPayload(String payload){String b64=Base64.encodeToString(payload.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);js("window.FCCNative&&FCCNative.onSyncSuccessFromBase64('"+b64+"')");}
    public final class AndroidSyncBridge {
        @JavascriptInterface public String getEndpoint(){return prefs.getString(SyncRepository.KEY_ENDPOINT,"");}
        @JavascriptInterface public String getToken(){return prefs.getString(SyncRepository.KEY_TOKEN,"");}
        @JavascriptInterface public void saveConfig(String endpoint,String token){prefs.edit().putString(SyncRepository.KEY_ENDPOINT,endpoint==null?"":endpoint.trim()).putString(SyncRepository.KEY_TOKEN,token==null?"":token.trim()).apply();PeriodicSyncWorker.ensure(MainActivity.this);js("window.FCCNative&&FCCNative.onConfigSaved&&FCCNative.onConfigSaved()");}
        @JavascriptInterface public String getCachedPayload(){return prefs.getString(SyncRepository.KEY_CACHE,"");}
        @JavascriptInterface public String getLastSync(){return prefs.getString(SyncRepository.KEY_LAST,"");}
        @JavascriptInterface public void clearCache(){prefs.edit().remove(SyncRepository.KEY_CACHE).remove(SyncRepository.KEY_LAST).apply();js("window.FCCNative&&FCCNative.onCacheCleared&&FCCNative.onCacheCleared()");}
        @JavascriptInterface public String getUiState(){return prefs.getString("ui_state","");}
        @JavascriptInterface public void saveUiState(String raw){prefs.edit().putString("ui_state",raw==null?"":raw).apply();}
        @JavascriptInterface public void setLightTheme(boolean light){prefs.edit().putBoolean("light_theme",light).apply();runOnUiThread(()->{if(Build.VERSION.SDK_INT>=23){int f=getWindow().getDecorView().getSystemUiVisibility();if(light)f|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;else f&=~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;getWindow().getDecorView().setSystemUiVisibility(f);}});}
        @JavascriptInterface public boolean notificationsEnabled(){return prefs.getBoolean("notifications_enabled",true);}
        @JavascriptInterface public void setNotificationsEnabled(boolean enabled){prefs.edit().putBoolean("notifications_enabled",enabled).apply();if(enabled){FantasyNotificationScheduler.rescheduleSaved(MainActivity.this);runOnUiThread(()->requestNotificationPermission());}else FantasyNotificationScheduler.cancelAll(MainActivity.this,false);}
        @JavascriptInterface public void scheduleNotifications(String json){FantasyNotificationScheduler.schedule(MainActivity.this,json);}
        @JavascriptInterface public void scheduleNotificationEvents(String json){scheduleNotifications(json);}
        @JavascriptInterface public void syncNow(){js("window.FCCNative&&FCCNative.onSyncStarted('Atualizando dados online...')");executor.execute(()->{try{String body=SyncRepository.sync(MainActivity.this);callbackPayload(body);}catch(Exception e){String msg=e.getMessage()==null?e.toString():e.getMessage();String enc=Base64.encodeToString(msg.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);js("window.FCCNative&&FCCNative.onSyncError(new TextDecoder().decode(Uint8Array.from(atob('"+enc+"'),c=>c.charCodeAt(0))))");}});}
    }
}
