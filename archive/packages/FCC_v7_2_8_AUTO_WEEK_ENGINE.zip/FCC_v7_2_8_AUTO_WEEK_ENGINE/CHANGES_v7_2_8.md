# FCC v7.2.8 — Automatic Week Engine

Esta versão faz uma auditoria estrutural da virada semana a semana e remove a necessidade de patch semanal.

## Regras
- **Semana operacional** do app avança automaticamente por agenda NFL/calendário.
- **Semana confirmada da fonte** continua independente por liga.
- O calendário nunca cria vitória, derrota, empate ou placar.
- Histórico só avança quando há resultado confirmado (`W`, `L` ou empate real).
- Linhas futuras `T 0×0` não são tratadas como empate.
- Standings podem ser reconciliados com `Weekly Results` quando a própria fonte já publicou W/L e a tabela de classificação ainda não acompanhou.
- Se ESPN permanecer atrasada, o app mostra a W operacional nova, mas mantém record/resultado ESPN no último estado confirmado.
- Quando a fonte finalmente vira, o app incorpora automaticamente na próxima sincronização.
- Planner sempre usa W atual operacional + 2 semanas.
- Agenda NFL busca a semana anterior + atual + 3 seguintes para detectar fechamento e BYEs.
- Ao detectar virada operacional, o app força nova leitura Sync/API/agenda sem inventar dados.

## Atualização automática já existente e preservada
- Sync principal ao abrir e a cada 15 min com app visível.
- API FCC a cada ~12 min.
- Agenda NFL a cada ~90 s.
- Notícias a cada ~20 min.
