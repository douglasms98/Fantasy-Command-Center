$ErrorActionPreference = "Stop"
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-JavaHome([string]$Path) {
  return ($Path -and (Test-Path (Join-Path $Path "bin\java.exe")))
}

function Test-AndroidSdk([string]$Path) {
  if (-not $Path) { return $false }
  $p = $Path.Trim().Trim('"')
  if (-not (Test-Path $p)) { return $false }
  $androidJar = Join-Path $p "platforms\android-36\android.jar"
  $buildTools = Join-Path $p "build-tools"
  return ((Test-Path $androidJar) -and (Test-Path $buildTools))
}

# 1) Java / JDK
$JavaCandidates = @()
if ($env:JAVA_HOME) { $JavaCandidates += $env:JAVA_HOME }
$JavaCandidates += @(
  "$env:ProgramFiles\Android\Android Studio\jbr",
  "$env:ProgramFiles\Android\Android Studio\jre",
  "${env:ProgramFiles(x86)}\Android\Android Studio\jbr",
  "$env:LOCALAPPDATA\Programs\Android Studio\jbr",
  "$env:LOCALAPPDATA\Android\Android Studio\jbr"
)

$JavaHome = $null
foreach ($Candidate in $JavaCandidates) {
  if (Test-JavaHome $Candidate) { $JavaHome = $Candidate; break }
}
if (-not $JavaHome) {
  $JavaCommand = Get-Command java.exe -ErrorAction SilentlyContinue
  if ($JavaCommand) {
    $JavaBin = Split-Path -Parent $JavaCommand.Source
    $Guess = Split-Path -Parent $JavaBin
    if (Test-JavaHome $Guess) { $JavaHome = $Guess }
  }
}
if (-not $JavaHome) {
  Write-Host "Java/JDK nao encontrado." -ForegroundColor Red
  Write-Host "Abra o Android Studio e confirme o Gradle JDK em Settings > Build Tools > Gradle."
  exit 3
}
$env:JAVA_HOME = $JavaHome
$env:Path = (Join-Path $JavaHome "bin") + ";" + $env:Path
Write-Host "Java encontrado:" -ForegroundColor Green
Write-Host $JavaHome -ForegroundColor Green
& (Join-Path $JavaHome "bin\java.exe") -version
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

# 2) Android SDK 36 - validacao real, nao apenas existencia da pasta
$SdkCandidates = New-Object System.Collections.Generic.List[string]
foreach ($c in @($env:ANDROID_SDK_ROOT, $env:ANDROID_HOME, "$env:LOCALAPPDATA\Android\Sdk")) {
  if ($c -and -not $SdkCandidates.Contains($c)) { $SdkCandidates.Add($c) }
}

# Tenta descobrir SDKs de outros perfis locais comuns
try {
  Get-ChildItem "C:\Users" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $c = Join-Path $_.FullName "AppData\Local\Android\Sdk"
    if (-not $SdkCandidates.Contains($c)) { $SdkCandidates.Add($c) }
  }
} catch {}

$Sdk = $null
foreach ($Candidate in $SdkCandidates) {
  if (Test-AndroidSdk $Candidate) { $Sdk = $Candidate.Trim().Trim('"'); break }
}

if (-not $Sdk) {
  Write-Host "" 
  Write-Host "Nao encontrei automaticamente um Android SDK 36 valido." -ForegroundColor Yellow
  Write-Host "No Android Studio abra: Tools > SDK Manager" -ForegroundColor Yellow
  Write-Host "Copie exatamente o campo 'Android SDK Location' e cole abaixo." -ForegroundColor Yellow
  Write-Host "Exemplo: C:\Users\Douglas M\AppData\Local\Android\Sdk" -ForegroundColor DarkGray
  Write-Host ""
  $ManualSdk = Read-Host "Android SDK Location"
  $ManualSdk = $ManualSdk.Trim().Trim('"')
  if (Test-AndroidSdk $ManualSdk) {
    $Sdk = $ManualSdk
  } else {
    Write-Host "" 
    Write-Host "O caminho informado nao contem um SDK 36 completo." -ForegroundColor Red
    Write-Host "Preciso encontrar este arquivo:" -ForegroundColor Red
    Write-Host "  <SDK>\platforms\android-36\android.jar" -ForegroundColor Red
    Write-Host "E a pasta:" -ForegroundColor Red
    Write-Host "  <SDK>\build-tools" -ForegroundColor Red
    Write-Host ""
    Write-Host "Volte ao SDK Manager, instale Android SDK Platform 36 e Android SDK Build-Tools 36.x, e rode novamente." -ForegroundColor Yellow
    exit 2
  }
}

$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk
Write-Host "Android SDK encontrado:" -ForegroundColor Green
Write-Host $Sdk -ForegroundColor Green
Write-Host "android.jar:" -ForegroundColor Green
Write-Host (Join-Path $Sdk "platforms\android-36\android.jar") -ForegroundColor Green

$LocalProps = Join-Path $Project "local.properties"
# Em Java .properties, barras '/' evitam problemas de escape no Windows.
$SdkForProps = $Sdk -replace '\\','/'
Set-Content -Path $LocalProps -Value ("sdk.dir=" + $SdkForProps) -Encoding ASCII
Write-Host "local.properties criado:" -ForegroundColor Green
Get-Content $LocalProps | Write-Host

# 3) Gradle e build
$GradleVersion = "9.6.0"
$ToolsDir = Join-Path $Project ".build-tools"
$GradleHome = Join-Path $ToolsDir "gradle-$GradleVersion"
$GradleExe = Join-Path $GradleHome "bin\gradle.bat"

if (-not (Test-Path $GradleExe)) {
  New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
  $Zip = Join-Path $ToolsDir "gradle-$GradleVersion-bin.zip"
  Write-Host "Baixando Gradle $GradleVersion..." -ForegroundColor Cyan
  Invoke-WebRequest -UseBasicParsing "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $Zip
  Expand-Archive -Force $Zip $ToolsDir
  Remove-Item $Zip -Force
}

Write-Host ""
Write-Host "Compilando Fantasy Command Center..." -ForegroundColor Cyan
& $GradleExe -p $Project --no-daemon assembleDebug
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$Apk = Join-Path $Project "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $Apk) {
  $Out = Join-Path $Project "Fantasy_Command_Center_2026_v5_6.apk"
  Copy-Item -Force $Apk $Out
  Write-Host ""
  Write-Host "APK GERADO:" -ForegroundColor Green
  Write-Host $Out -ForegroundColor Green
  Start-Process explorer.exe "/select,`"$Out`""
} else {
  Write-Host "Build terminou, mas o APK nao foi localizado no caminho esperado." -ForegroundColor Yellow
  exit 4
}
