# FCC v7.2.6 — Week Rollover Fix

## Corrigido
- Season/Week Engine passa a virar a semana de fantasy na terça-feira após o Monday Night.
- Em 06/10/2026 o app passa automaticamente de W4 para W5.
- Uma fonte atrasada em W4 não mantém a Home, Central de decisões ou confrontos presos em W4.
- Matchup W4 encerrado deixa de aparecer como confronto atual; fica apenas como histórico.
- Central de decisões entra em estado `PRÉ-W5` enquanto matchup/projeções W5 ainda não chegaram.
- Otimizador não reaproveita recomendações W4 na W5.
- Projeções W4 não são exibidas como se fossem W5 em Roster, ficha de jogador ou Trade Finder.
- Waivers antigos continuam consultáveis, mas ficam identificados como referência W4 e recomendações W5 aguardam atualização.
- Comparação posicional e candidatos de drop da semana anterior deixam de ser apresentados como análise atual.
- Power Ranking anterior permanece visível como `Último ranking: ... W4` até chegar o novo.
- Tela de Sincronização diferencia `ATUALIZADA` de `W5 PENDENTE` quando a fonte ainda não virou.
- KPI da rodada usa `pré-rodada / aguardando dados W5` em vez de afirmar sempre `em andamento`.

## Mantido
- Tema Semi Dark corrigido da v7.2.4.
- Full Dark AMOLED.
- Ícones/Manifest/notificações da base v7.2.5.
- Lógica de API, cache e sincronização existente.
