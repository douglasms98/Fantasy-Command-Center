# Fantasy Command Center 2026 — v7.0

## Direção recuperada do roadmap
A v7.0 passa a ser o início da evolução arquitetural do app, e não apenas um hotfix da linha 6.x.

Base visual mantida da Preview 5 AMOLED:
- preto AMOLED + cards grafite;
- ícone oficial do Fantasy Command Center;
- Home agrupada por Sleeper/ESPN;
- confrontos em carrossel horizontal;
- planejamento semanal em carrossel, filtrado pela liga selecionada;
- filtro/comparação recolhido no ícone ao lado da liga;
- logos NFL e identificação da plataforma.

## Implementado nesta revisão da 7.0

### 1. W4 preliminar realmente online
- O Sync API deixa de cortar `Weekly Results` em `completedWeeks`.
- A semana em andamento é enviada até `analysisWeek` e marcada como `Preliminary`.
- O app usa a maior semana efetivamente recebida, sem esconder W4 porque a metadata ainda diz W3 concluída.

### 2. Contrato normalizado Sleeper + ESPN
O payload agora expõe `normalizedLeagues` com contrato `fcc-normalized-v1`.

Ele padroniza por liga:
- leagueId / plataforma / time;
- rodada analisada e semanas concluídas;
- atualização da fonte;
- contagem de rosters, standings, weekly, free agents e transactions;
- capacidades da fonte (live weekly, waivers, trades e power rankings).

Isso é a primeira etapa para desacoplar o motor analítico do formato específico de cada planilha.

### 3. Central de decisões na Home
Novo carrossel por liga com:
- melhor movimento ADD → DROP disponível;
- melhor trade equilibrada encontrada pelo Trade Finder;
- maior carência posicional da liga;
- Power Ranking quando a fonte ESPN possui esse dado;
- atalhos diretos para Waivers e Trade Finder.

As recomendações continuam respeitando scoring, profundidade, roster, lesões, contexto de QB e disponibilidade específica de cada liga.

### 4. Power Rankings ESPN dentro do app
- O Sync API lê a aba `Power Rankings` da `ESPN Data Export 2026 - Adaptada`.
- O ranking passa a compor a Central de decisões da liga ESPN.
- O app não mistura esse ranking com ligas Sleeper de scoring diferente.

### 5. Sincronização e notificações
- sincronização ao abrir;
- nova tentativa ao retornar ao app;
- atualização periódica enquanto o app estiver visível;
- scheduler com fallback quando alarmes exatos não estão disponíveis;
- reagendamento após reboot/atualização do APK;
- canal novo `fantasy_alerts_v7`.

## Próximas etapas da linha 7.x
Ainda não considero implementado até existir de verdade:
- banco online persistente próprio;
- histórico de snapshots independente das planilhas;
- backend de recomendações executado fora do WebView;
- fila de eventos/push independente de abrir o aplicativo;
- comparação longitudinal de decisão tomada x resultado;
- motor remoto configurável por pesos sem rebuild do APK.

A arquitetura atual já prepara essas etapas com o contrato normalizado, mas continua em modo híbrido Google Sheets + Apps Script + cache Android.
