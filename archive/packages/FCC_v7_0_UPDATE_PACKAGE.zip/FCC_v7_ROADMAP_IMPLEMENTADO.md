# FCC 7.x — Roadmap consolidado

## Já incorporado na base 7.0
- Preview AMOLED como identidade principal.
- Home por plataforma Sleeper/ESPN.
- Cards e carrosséis mobile-first.
- Confrontos da rodada em carrossel.
- Planejamento de 3 semanas filtrado por liga, com BYE/logos NFL.
- Filtro/comparação pelo ícone ao lado da seleção de liga.
- W1–W18 e semana analisada dinâmica na interface.
- Waivers com K/DEF separados do ranking ofensivo.
- Trade Finder 1x1, 2x1 e 1x2 com simulação de vaga/drop.
- ADD/DROP conjunto na Central de decisões.
- Resultados preliminares da semana corrente.
- Power Ranking ESPN integrado.
- Contrato normalizado Sleeper/ESPN (`fcc-normalized-v1`).
- Sync/cache/notificações resilientes.

## Em evolução durante a 7.x
1. Backend online persistente e snapshots por rodada.
2. Normalização total de jogadores, ligas e transações por IDs canônicos.
3. Motor analítico remoto com pesos configuráveis por liga.
4. Recomendações automáticas com histórico e avaliação pós-decisão.
5. Push/eventos independentes de abertura do aplicativo.
6. Comparador pré/pós para waiver, drop e trade.
7. Painel de qualidade/freshness por fonte e por conjunto de dados.

## Regra de produto
A prioridade da 7.x é agregar ligas de plataformas diferentes sem misturar scoring bruto e transformar os dados em decisões contextuais: quem adicionar, quem dropar, onde o roster está fraco e quais trades melhoram os dois lados.
