package com.douglas.fantasycommandcenter

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.annotation.Keep
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import kotlin.math.absoluteValue

object FantasyNotificationScheduler {
    private const val PREFS = "fcc_notifications"
    private const val KEY_IDS = "scheduled_ids"
    private const val KEY_JSON = "last_schedule_json"
    const val CHANNEL_ID = "fantasy_alerts_v7"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Fantasy Football",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertas de rodada, placares, waivers e atualização do Fantasy Command Center"
                enableVibration(true)
            }
            nm.createNotificationChannel(channel)
        }
    }

    fun schedule(context: Context, json: String, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_JSON, json).apply()
        cancelAll(context)
        if (!enabled) return
        ensureChannel(context)

        val array = runCatching { JSONArray(json) }.getOrNull() ?: return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val saved = mutableSetOf<String>()
        val now = System.currentTimeMillis()

        for (i in 0 until array.length()) {
            val e = array.optJSONObject(i) ?: continue
            val id = e.optString("id").ifBlank { "fcc-$i" }
            val at = e.optString("at")
            val whenMs = runCatching { java.time.Instant.parse(at).toEpochMilli() }.getOrNull() ?: continue
            if (whenMs <= now) continue

            val intent = Intent(context, FantasyNotificationReceiver::class.java).apply {
                putExtra("event_id", id)
                putExtra("title", e.optString("title", "Fantasy Command Center"))
                putExtra("body", e.optString("body", "Há uma atualização importante no fantasy."))
                putExtra("type", e.optString("type"))
                putExtra("league_id", e.optString("leagueId"))
            }
            val pi = PendingIntent.getBroadcast(
                context,
                id.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
                    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
                } else {
                    alarm.setExact(AlarmManager.RTC_WAKEUP, whenMs, pi)
                }
                saved.add(id)
            } catch (_: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
                    saved.add(id)
                }
            }
        }
        prefs.edit().putStringSet(KEY_IDS, saved).apply()
    }

    fun reschedule(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_JSON, null) ?: return
        val enabled = context.getSharedPreferences("fcc_native", Context.MODE_PRIVATE)
            .getBoolean("notifications_enabled", true)
        schedule(context, json, enabled)
    }

    fun cancelAll(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val ids = prefs.getStringSet(KEY_IDS, emptySet()) ?: emptySet()
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        ids.forEach { id ->
            val pi = PendingIntent.getBroadcast(
                context,
                id.hashCode(),
                Intent(context, FantasyNotificationReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) alarm.cancel(pi)
        }
        prefs.edit().remove(KEY_IDS).apply()
    }
}

class FantasyNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        FantasyNotificationScheduler.ensureChannel(context)
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val eventId = intent.getStringExtra("event_id") ?: "fcc-alert"
        val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val contentIntent = launchIntent?.let {
            PendingIntent.getActivity(context, eventId.hashCode(), it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val body = intent.getStringExtra("body") ?: "Há uma atualização importante."
        val notification = NotificationCompat.Builder(context, FantasyNotificationScheduler.CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(intent.getStringExtra("title") ?: "Fantasy Command Center")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()
        NotificationManagerCompat.from(context).notify(eventId.hashCode().absoluteValue, notification)
    }
}

class FantasyBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            FantasyNotificationScheduler.reschedule(context)
        }
    }
}

@Keep
class FantasyNotificationBridge(private val context: Context) {
    private val prefs = context.getSharedPreferences("fcc_native", Context.MODE_PRIVATE)

    @android.webkit.JavascriptInterface
    fun notificationsEnabled(): Boolean = prefs.getBoolean("notifications_enabled", true)

    @android.webkit.JavascriptInterface
    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("notifications_enabled", enabled).apply()
        if (!enabled) FantasyNotificationScheduler.cancelAll(context)
        else FantasyNotificationScheduler.reschedule(context)
    }

    @android.webkit.JavascriptInterface
    fun scheduleNotifications(json: String) {
        FantasyNotificationScheduler.schedule(context, json, notificationsEnabled())
    }
}
