# Fantasy Command Center Android v5.8.1

Atualização sobre a v5.7 existente. O package permanece:

`com.douglas.fantasycommandcenter`

Instale o APK **por cima da versão atual**, sem desinstalar, para preservar URL/chave de sincronização, cache e preferências.

## Principais mudanças da v5.8.1

- sincronização automática em segundo plano ao abrir o app;
- o cache local aparece imediatamente enquanto a atualização online ocorre;
- botão **Atualizar dados agora** e informações técnicas movidos para **Mais → Sincronização**;
- status de sincronização separado por liga, com preservação do cache quando uma fonte falha;
- suporte dinâmico às semanas W1–W18, sem interface presa à W4;
- fim da temporada limitado à W18, sem criação de W19;
- filtros históricos de temporada, últimas 3, faixas e semana individual;
- gráficos semanais com eixo dinâmico;
- valores ausentes exibidos como `— / dados insuficientes`, sem converter ausência em zero;
- melhoria no casamento de nomes de jogadores (pontuação, acentos e sufixos);
- correção da indicação “acima/abaixo da média” por posição;
- ranking de waivers ofensivos separado de streamers K/DEF;
- waivers mais compactos no celular;
- projeções ESPN lidas dinamicamente de W1 a W18;
- informações de atualização/fonte concentradas em Sincronização e Fontes.

Leia `ATUALIZAR_V5_8_1.txt` para instalar e `SINCRONIZACAO_GOOGLE_SHEETS.txt` para atualizar o Web App existente.
