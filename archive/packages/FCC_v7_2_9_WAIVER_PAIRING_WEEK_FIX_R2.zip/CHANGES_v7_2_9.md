# Fantasy Command Center v7.2.9 — Waiver Pairing + Week Fix

## Waivers
- O motor deixa de tratar o candidato de drop como uma escolha praticamente independente do jogador que chega.
- Novo `dropOptionsFor()` compara todos os cortes elegíveis do banco para cada ADD.
- A avaliação considera valor perdido, risco de drop, compatibilidade posicional, excesso de profundidade, necessidade da posição e impacto estrutural.
- `waiverMove()` agora guarda até 2 cortes alternativos quando existem opções aceitáveis.
- O plano de waivers agrupa recomendações que usam o mesmo corte.
- Repetições legítimas do mesmo drop passam a ser marcadas como **alternativa ao movimento principal**, em vez de parecerem várias ordens independentes para cortar o mesmo jogador.
- A lista de prioridades tenta mostrar primeiro movimentos com cortes distintos; só depois inclui alternativas que usam o mesmo corte.
- Não é criada variedade artificial: se um jogador realmente continuar sendo o corte de menor custo, ele pode permanecer como drop de mais de uma alternativa.

## Semana automática
- Mantido o Automatic Week Engine da v7.2.8.
- Cabeçalhos e textos de waivers usam `fccAnalysisWeek()`; não ficam presos em W4.
- Se a fonte ainda não publicou a nova rodada, a base anterior é mostrada apenas como referência e a recomendação nova não é forçada.

## Android / sincronização
- Inclui `SyncRepository.java` compatível com `FantasyNotificationScheduler.schedule(Context, String)`.
- Remove a chamada antiga/inexistente `scheduleFromPayload(Context, JSONObject)`.
- Mantém cache, endpoint legado e agenda de `notificationEvents`.

## Não alterado
- Cloud Run / Firestore não precisam de novo deploy para esta correção de waivers.
- Liga 4 (`espn2`) continua pendente até a liberação do manager e o teste server-only específico.
