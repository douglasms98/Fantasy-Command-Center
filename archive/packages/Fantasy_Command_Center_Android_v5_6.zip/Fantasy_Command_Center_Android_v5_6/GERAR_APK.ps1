$ErrorActionPreference = "Stop"
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
$SdkCandidates = @(
  $env:ANDROID_SDK_ROOT,
  $env:ANDROID_HOME,
  "$env:LOCALAPPDATA\Android\Sdk"
) | Where-Object { $_ -and (Test-Path $_) }

if (-not $SdkCandidates) {
  Write-Host "Android SDK nao encontrado." -ForegroundColor Yellow
  Write-Host "Instale/abra o Android Studio uma vez e instale Android SDK 36. Depois execute este arquivo novamente."
  exit 2
}
$Sdk = $SdkCandidates[0]
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk

$LocalProps = Join-Path $Project "local.properties"
("sdk.dir=" + ($Sdk -replace '\\','\\\\')) | Set-Content -Encoding ASCII $LocalProps

$GradleVersion = "9.6.0"
$ToolsDir = Join-Path $Project ".build-tools"
$GradleHome = Join-Path $ToolsDir "gradle-$GradleVersion"
$GradleExe = Join-Path $GradleHome "bin\gradle.bat"

if (-not (Test-Path $GradleExe)) {
  New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
  $Zip = Join-Path $ToolsDir "gradle-$GradleVersion-bin.zip"
  Write-Host "Baixando Gradle $GradleVersion..."
  Invoke-WebRequest -UseBasicParsing "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $Zip
  Expand-Archive -Force $Zip $ToolsDir
  Remove-Item $Zip -Force
}

Write-Host "Compilando Fantasy Command Center..." -ForegroundColor Cyan
& $GradleExe -p $Project assembleDebug
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$Apk = Join-Path $Project "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $Apk) {
  $Out = Join-Path $Project "Fantasy_Command_Center_2026_v5_6.apk"
  Copy-Item -Force $Apk $Out
  Write-Host "";
  Write-Host "APK GERADO:" -ForegroundColor Green
  Write-Host $Out -ForegroundColor Green
  Start-Process explorer.exe "/select,`"$Out`""
} else {
  Write-Host "Build terminou, mas o APK nao foi localizado no caminho esperado." -ForegroundColor Yellow
}
