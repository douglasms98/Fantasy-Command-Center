const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(require('path').join(__dirname,'../app/src/main/assets/fcc/index.html'),'utf8');
for(const m of html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi))new vm.Script(m[1]);
function fn(name){const start=html.indexOf('function '+name+'(');assert(start>=0,name);const end=html.indexOf('\nfunction ',start+10);return html.slice(start,end<0?undefined:end);}
const elements={lineupOptimizer:{},threeWeekPlanner:{}};
const context={console,Date,Map,Set,JSON,Number,String,window:{},DATA:{notificationEvents:[]},state:{league:'ALL'},
 FCC_OFFENSE:new Set(['RB','WR','TE','QB']),fccLeagueIsStaleWeek:()=>false,fccAnalysisWeek:()=>5,
 fccCurrentProjection:p=>p.proj,fccPlayerOnBye:p=>!!p.bye,fccStatusUnavailable:()=>false,
 fccNflCode:t=>t,FCC_NFL_TEAM_META:{BUF:{},JAX:{},PHI:{}},fccScheduleOpponent:()=>null,fccNflLogoOnly:t=>t,
 fccSafe:t=>t,fmt:n=>String(n),$:s=>elements[s.slice(1)],selectedLoaded:()=>[],fccLoadedLeagues:()=>[],
 fccScheduleWeeks:()=>[],fccScheduleGameForTeam:()=>null,fccKickoffLabel:()=> 'dom. 10:30'};
vm.createContext(context);
for(const name of ['fccPlayerCanChangeLineup','fccOptimizerHasLiveGame','fccLineupSuggestionsFor','fccNotificationEvents','fccRenderPlanner'])vm.runInContext(fn(name),context);
let live=false;
context.fccGameStateForNflTeam=t=>t==='DONE'?{started:true,live:false}:t==='UNKNOWN'?null:{started:live,live};
const league={name:'TEST_ONLY',roster:[{player:'starter',pos:'RB',slot:'Starter',nfl:'FUTURE',proj:4},{player:'bench',pos:'RB',slot:'Bench',nfl:'FUTURE',proj:9},{player:'locked',pos:'RB',slot:'Bench',nfl:'DONE',proj:40}]};
let rows=context.fccLineupSuggestionsFor([league]);assert.equal(rows.length,1);assert.equal(rows[0].in.player,'bench');
live=true;assert.equal(context.fccLineupSuggestionsFor([league]).length,0);live=false;
league.roster[1].nfl='UNKNOWN';assert.equal(context.fccLineupSuggestionsFor([league]).length,0);
const future=Date.now()+7200000;
context.fccLoadedLeagues=()=>[{id:'TEST_ONLY',name:'TEST_ONLY',waiverConfig:{nextProcessAt:new Date(future).toISOString()}}];
context.fccScheduleWeeks=()=>[{week:5,games:[{home:'JAX',away:'PHI',country:'United Kingdom',international:true,venue:'Test stadium',startTime:new Date(future).toISOString()}]}];
let events=context.fccNotificationEvents();assert.equal(events.length,3);assert(events.every(e=>new Date(e.at)>new Date()));
context.DATA.notificationEvents=events;assert.equal(context.fccNotificationEvents().length,3);
context.fccScheduleGameForTeam=t=>t==='JAX'?context.fccScheduleWeeks()[0].games[0]:null;
context.selectedLoaded=()=>[{name:'TEST_ONLY',roster:[{player:'starter',slot:'Starter',nfl:'BUF'}]}];
context.fccRenderPlanner();assert(!elements.threeWeekPlanner.innerHTML.includes('Internacional'));assert(elements.threeWeekPlanner.innerHTML.includes('PHI'));assert(elements.threeWeekPlanner.innerHTML.includes('JAX'));assert(elements.threeWeekPlanner.innerHTML.includes('dom. 10:30'));
let count=0,envelope=null;context.window.FCCAccount={user:{uid:'TEST_ONLY_UID'}};context.window.AndroidSync={scheduleNotifications:json=>{count++;envelope=JSON.parse(json);}};context.AndroidSync=context.window.AndroidSync;
vm.runInContext(fn('fccPushNotificationScheduleNative'),context);context.fccPushNotificationScheduleNative();assert.equal(count,1);
assert.equal(envelope.userId,'TEST_ONLY_UID');assert.equal(envelope.events.length,3,'Native reminder transport includes its source account');
context.fccLoadedLeagues=()=>[];context.fccScheduleWeeks=()=>[];context.DATA.notificationEvents=[];
context.fccPushNotificationScheduleNative();assert.equal(count,1,'Empty event list must not replace schedule');
assert(html.includes('#allLeaguesBtn{display:block!important;background:#58d2f2!important;color:#06131e!important'));
assert(html.includes('#rosterHealth .kpis{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important'));
vm.runInContext(fn('fccClampWeek'),context);vm.runInContext(fn('fccCalendarFantasyWeek'),context);
context.DATA={season:2027,online:{nflWeeks:[{week:8,complete:true,games:[{startTime:new Date(Date.now()-86400000).toISOString(),completed:true}]}]}};
assert.equal(context.fccCalendarFantasyWeek(),9,'Confirmed calendar advances without a fixed 2026 anchor');
context.DATA.online.nflWeeks=[];assert.equal(context.fccCalendarFantasyWeek(),0,'Missing calendar never invents a week');
console.log(JSON.stringify({passed:['all JS syntax','lineup available between games','live-game pause','started-player lock','unknown kickoff guard','provider-timestamp reminder generation','event deduplication','international games without roster player','empty list does not clear schedule','mobile layout/contrast rules','calendar without a fixed season/date'],note:'Fixtures are isolated tests; no league data was created or modified.'},null,2));
