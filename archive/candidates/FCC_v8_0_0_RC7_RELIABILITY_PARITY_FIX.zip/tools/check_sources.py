"""Source/asset checks; Java parsing does not substitute for an Android build."""
from pathlib import Path
import ast
import xml.etree.ElementTree as ET
import javalang
import json

root=Path(__file__).resolve().parents[1]
android=root/'app/src/main'
html=android/'assets/fcc/index.html'
assert html.read_bytes()==(root/'backend/static/index.html').read_bytes(),'Android and web HTML differ'
language=(root/'backend/static/news_language.json').read_bytes()
assert language==(android/'assets/fcc/news_language.json').read_bytes(),'NFL language rules differ'
rules=json.loads(language)
assert 'const FCC_NEWS_LANGUAGE='+json.dumps(rules,ensure_ascii=False,separators=(',',':'))+';' in html.read_text(),'Embedded language rules differ'
fragment=(root/'tools/google_ui.js').read_text()
assert '// BEGIN FCC GOOGLE AUTH\n'+fragment+'// END FCC GOOGLE AUTH\n' in html.read_text(),'Google source fragment differs from HTML'
python_files=list((root/'backend/app').glob('*.py'))+list((root/'tools').glob('*.py'))
for path in python_files:ast.parse(path.read_text(),filename=str(path))
java_files=list((android/'java').rglob('*.java'))
for path in java_files:javalang.parse.parse(path.read_text())
xml_files=list(android.rglob('*.xml'))
for path in xml_files:ET.parse(path)
print(f'PASS: {len(python_files)} Python, {len(java_files)} Java and {len(xml_files)} XML files parse; Android/web assets match.')
print('Not run here: Gradle/Android compilation, device delivery, real Firebase/Firestore integration, Cloud deployment and visual render. Provider read checks are documented separately.')
